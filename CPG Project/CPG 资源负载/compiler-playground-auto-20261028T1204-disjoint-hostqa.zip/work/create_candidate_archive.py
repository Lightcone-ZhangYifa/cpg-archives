#!/usr/bin/env python3
"""Deterministically package this round's *new* code and evidence, not old payloads."""
from __future__ import annotations
import hashlib,json,os,pathlib,stat,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
ARCHIVE=OUT/'compiler-playground-auto-20261028T1204-disjoint-hostqa.zip'
FILES=[ROOT/'README.zh.md']+sorted((ROOT/'work').glob('*.py'))+sorted((ROOT/'evidence').glob('*.json'))+sorted(p for p in OUT.glob('*.json') if p.name not in ('candidate-archive-binding.json','public-restore-qa.json','final-handoff.json','download-catalog.json'))
if (OUT/'public-restore-qa.json').exists():FILES.append(OUT/'public-restore-qa.json')
assert all(f.is_file() and f.resolve().is_relative_to(ROOT.resolve()) for f in FILES)
assert all(f.parent in (ROOT,ROOT/'work',ROOT/'evidence',OUT) for f in FILES)
def h(b):return hashlib.sha256(b).hexdigest()
manifest=[]
for f in FILES:
 rel=f.relative_to(ROOT).as_posix(); mode=0o755 if f.suffix=='.py' else 0o644
 if f.suffix=='.py':os.chmod(f,mode)
 data=f.read_bytes();manifest.append({'path':rel,'sha256':h(data),'bytes':len(data),'mode':oct(mode)})
header={'format':'cpg-disjoint-candidate-incremental-manifest-v1','canonical_version_unchanged':'0.21.4',
 'base_delivery_sha256':'ae05c647aee40a672cb01b64e1e10c46a8de2b586ab7e0a0feb1d966caf210bd',
 'candidate_original_ID_count':7,'candidate_package_payloads':0,
 'base_raw_original_volumes_required':['001','003','004','005','006','008'],
 'original_apt_packages_repacked':0,'canonical_coverage_delta':0,
 'entries':manifest}
manifest_bytes=(json.dumps(header,sort_keys=True,ensure_ascii=False,indent=2)+'\n').encode()
with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7,strict_timestamps=True) as z:
 for rel,data,mode in [(f.relative_to(ROOT).as_posix(),f.read_bytes(),0o755 if f.suffix=='.py' else 0o644) for f in FILES]+[('INCREMENTAL-MANIFEST.json',manifest_bytes,0o644)]:
  info=zipfile.ZipInfo(rel,date_time=(2026,10,28,12,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  info.create_system=3;info.external_attr=(stat.S_IFREG|mode)<<16
  z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=7)
with zipfile.ZipFile(ARCHIVE) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={i['path'] for i in manifest}|{'INCREMENTAL-MANIFEST.json'}
 assert z.read('INCREMENTAL-MANIFEST.json')==manifest_bytes
 for d in manifest:
  data=z.read(d['path']);zi=z.getinfo(d['path'])
  assert h(data)==d['sha256'] and len(data)==d['bytes']
  assert ((zi.external_attr>>16)&0o777)==int(d['mode'],8)
sha=h(ARCHIVE.read_bytes());s=ARCHIVE.stat()
binding={'format':'cpg-disjoint-hostqa-archive-binding-v1','archive':ARCHIVE.name,
 'sha256':sha,'bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),
 'entry_count':len(manifest)+1,'canonical_release_delta':0,
 'public_incremental_restore_requires_original_v0.21.4_volumes':True}
(OUT/'candidate-archive-binding.json').write_text(json.dumps(binding,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(binding,indent=2))
