#!/usr/bin/env python3
"""Verify 2 historical saved ready volumes and one NEW-SHA-only Dataset delta.

All original source materials stay inherited. Only whole, exact, fresh ordinary
file trees can be published. No builds, downloads, model inference, or SQL execution.
"""
from __future__ import annotations
import argparse,hashlib,io,json,os,pathlib,re,shutil,stat,sys,tarfile,tempfile,zipfile
HEX=re.compile(r'[a-f0-9]{64}\Z')
ORIGINAL={
 'join-order-benchmark':{
  'sha':'c8bebf47cfaa51756a60f84a350df319384178244c7bc30bdea54e50a629ff1b',
  'bytes':116259475,'source_sha':'6a57357a67950dbd507f8a7cebdbed1d0a3806b3de445b8dd20f82f0d4aa7593',
  'source_bytes':12313,'prefix':'join-order-benchmark-a39603662e023e449cb2121997a5034df9e02ebf','files':116},
 'deepfuzz':{
  'sha':'3cfa06d68223d45fef179b9e037eff2e5f49c4229d22b869a2aecbffac3148c9',
  'bytes':258168292,'source_sha':'1b051cf91e31f15a5415a7e377a6f8047f920fa9a9939fa71baed181babb5f25',
  'source_bytes':4762,'prefix':'DeepFuzz-6079bef655b471b82c70e51024d3d4824092f396','files':8}}
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha_file(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def json_strict(raw):
 def pairs(items):
  out={}
  for k,v in items:
   if k in out:raise ValueError('Duplicate JSON key: '+k)
   out[k]=v
  return out
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Not finite numeric JSON')))
def safe_path(s):
 if not isinstance(s,str) or not s or '\\' in s or any(ord(c)<32 for c in s):raise ValueError('Invalid source path')
 p=pathlib.PurePosixPath(s)
 if p.is_absolute() or p.as_posix()!=s or any(x in ('','.','..') for x in p.parts):raise ValueError('Unsafe path: '+s)
 return s
def validate_row(rec):
 p=safe_path(rec.get('path'))
 if len(p)>512 or not isinstance(rec.get('sha256'),str) or not HEX.fullmatch(rec['sha256']):raise ValueError('Bad object identity')
 if type(rec.get('bytes')) is not int or rec['bytes']<0 or rec['bytes']>5_000_000:raise ValueError('Unreviewed object size')
 if type(rec.get('mode')) is not int or rec['mode'] not in (0o444,0o555,0o600,0o644,0o755):raise ValueError('Unreviewed logical file mode')
 if rec['source_card'] not in ORIGINAL:raise ValueError('Unknown canonical source card')
 if not p.startswith(rec['source_card']+'/'):raise ValueError('Card/material path mismatch')
 return p
def build(bundle,job_volume,deep_volume,stage):
 with zipfile.ZipFile(bundle,'r') as z:
  names=z.namelist()
  if len(names)!=len(set(names)) or 'manifest.json' not in names:raise ValueError('Incomplete or duplicate ZIP entries')
  manifest=json_strict(z.read('manifest.json'))
  if manifest.get('format')!='cpg-job-deepfuzz-original-source-only-newSHA-v1' or manifest.get('formal_baseline')!='0.21.13':
   raise ValueError('Not the audited CPG original source-only delta format')
  new=manifest['new_entries'];old=manifest['inherited_entries']
  if len(new)!=4 or len(old)!=124:raise ValueError('New/old identities are not complete')
  expected={'manifest.json'}|{'objects/'+str(r.get('sha256','')) for r in new}
  if len(expected)!=5 or set(names)!=expected:raise ValueError('Unexpected or missing new-only object')
  all_rows={}
  for r in [*new,*old]:
   path=validate_row(r)
   if path in all_rows:raise ValueError('Duplicate logical restoration path')
   all_rows[path]=r
  for r in new:
   if r['path'].split('/')[-1] not in ('dataset.json','prepared.json'):raise ValueError('Data bytes repacked or unexpected metadata file')
   if r.get('source')!='new_Dataset_metadata_SHA':raise ValueError('Misrepresented new object')
   body=z.read('objects/'+r['sha256'])
   if len(body)!=r['bytes'] or sha_bytes(body)!=r['sha256']:raise ValueError('New content SHA mismatch')
   dst=stage/r['path'];dst.parent.mkdir(parents=True,exist_ok=True)
   with dst.open('xb') as f:f.write(body)
   dst.chmod(r['mode'])
  vols={'join-order-benchmark':job_volume,'deepfuzz':deep_volume}
  for card,volume in vols.items():
   pinned=ORIGINAL[card]
   if volume.stat().st_size!=pinned['bytes'] or sha_file(volume)!=pinned['sha']:raise ValueError('Historical ready volume mismatch: '+card)
   if manifest['actual_input_volumes'][card]['sha256']!=pinned['sha']:raise ValueError('Manifest mismatches original volume contract')
   with zipfile.ZipFile(volume) as zold:
    if len(zold.namelist())!=len(set(zold.namelist())):raise ValueError('Duplicate old ZIP entries')
    content=zold.read('objects/'+pinned['source_sha'])
    if len(content)!=pinned['source_bytes'] or sha_bytes(content)!=pinned['source_sha']:raise ValueError('Original locked tarball checksum mismatch: '+card)
    with tarfile.open(fileobj=io.BytesIO(content),mode='r:gz') as tar:
     found=set()
     for tarinfo in tar.getmembers():
      safe_path(tarinfo.name)
      parts=pathlib.PurePosixPath(tarinfo.name).parts
      if not parts or parts[0]!=pinned['prefix']:raise ValueError('Noncanonical upstream Git root')
      if not (tarinfo.isfile() or tarinfo.isdir()):raise ValueError('Original unhandled link/device')
      if not tarinfo.isfile():continue
      if len(parts)<2:raise ValueError('Original empty file name')
      dest=card+'/'+'/'.join(parts[1:]);safe_path(dest)
      if dest in found:raise ValueError('Duplicate original member')
      found.add(dest);row=all_rows.get(dest)
      if row is None or row.get('source')!='inherited_upstream_source_original':raise ValueError('Unrecognized historical source file: '+dest)
      with tar.extractfile(tarinfo) as f:body=f.read()
      if sha_bytes(body)!=row['sha256'] or len(body)!=row['bytes']:raise ValueError('Historical full material changed: '+dest)
      p=stage/dest;p.parent.mkdir(parents=True,exist_ok=True)
      with p.open('xb') as f:f.write(body)
      p.chmod(row['mode'])
     if len(found)!=pinned['files'] or found!={r['path'] for r in old if r['source_card']==card}:
      raise ValueError('Missing/extra original source material for '+card)
  actual={p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file()}
  if actual!=set(all_rows) or len(actual)!=128:raise ValueError('Restoration inventory incomplete')
  for path,row in all_rows.items():
   p=stage/path
   if not stat.S_ISREG(p.lstat().st_mode) or p.is_symlink() or p.stat().st_size!=row['bytes'] or sha_file(p)!=row['sha256'] or (p.stat().st_mode&0o777)!=row['mode']:
    raise ValueError('Checksum, size, physical type or logical mode differs: '+path)
  return manifest

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--new-only-zip',required=True,type=pathlib.Path)
 ap.add_argument('--inherited-job-volume',required=True,type=pathlib.Path)
 ap.add_argument('--inherited-deepfuzz-volume',required=True,type=pathlib.Path)
 ap.add_argument('--output',required=True,type=pathlib.Path)
 ap.add_argument('--report',required=True,type=pathlib.Path)
 a=ap.parse_args()
 zip_path=a.new_only_zip.resolve(strict=True);j=a.inherited_job_volume.resolve(strict=True);d=a.inherited_deepfuzz_volume.resolve(strict=True)
 root=a.output.absolute();report=a.report.absolute()
 if root.exists() or root.is_symlink() or report.exists() or report.is_symlink():raise ValueError('Output and report must be fresh absent paths')
 if root==report or root in report.parents or report in root.parents or root in zip_path.parents or root in j.parents or root in d.parents:
  raise ValueError('Output location overlaps report or immutable inputs')
 root.parent.mkdir(parents=True,exist_ok=True);report.parent.mkdir(parents=True,exist_ok=True)
 stage=pathlib.Path(tempfile.mkdtemp(prefix='.cpg-job-deep-newonly-stage-',dir=root.parent))
 try:
  mf=build(zip_path,j,d,stage)
  if root.exists() or root.is_symlink():raise ValueError('Restore output appeared during validation')
  os.rename(stage,root)
 except BaseException:
  shutil.rmtree(stage,ignore_errors=True)
  raise
 obj={'format':'cpg-job-deepfuzz-new-only-restoration-v1','success':True,'formally_published':False,
  'baseline':'0.21.13','new_layer_sha256':sha_file(zip_path),'job_legacy_volume_sha256':ORIGINAL['join-order-benchmark']['sha'],
  'deepfuzz_legacy_volume_sha256':ORIGINAL['deepfuzz']['sha'],
  'restored_new_metadata_SHA_objects':4,'restored_inherited_unmodified_original_files':124,
  'sample_source_counts':{'join-order-benchmark':113,'deepfuzz':6},
  'official_JOB_query_executions':0,'DeepFuzz_training_or_generation_executions':0,
  'source_original_data_repacked':0,'new_original_resource_ids_qualified':0,'new_formal_dataset_cards_qualified':0,
  'file_count_physically_verified':128,'manifest_cards_fingerprints':mf['dataset_fingerprints'],
  'offline':True,'network_used':False,'output':str(root)}
 with report.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps(obj,sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as exc:
  print('JOB/DeepFuzz restoration rejected: '+type(exc).__name__+': '+str(exc),file=sys.stderr);sys.exit(1)
