#!/usr/bin/env python3
import zipfile,io,os,pathlib,subprocess,json,hashlib,re,sys
root=pathlib.Path(__file__).resolve().parent
outer=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.13-cpg-continuation-20261030.zip')
extract=root/'regression-isolated-official-tests';extract.mkdir(exist_ok=True)
with zipfile.ZipFile(outer) as outerzip:
 with zipfile.ZipFile(io.BytesIO(outerzip.read('wheel/compiler_playground-0.21.13-py3-none-any.whl'))) as wheel:
  tests=[name for name in wheel.namelist() if name.startswith('compiler_playground/_support/tests/') and not name.endswith('/')]
  for name in tests:
   p=pathlib.PurePosixPath(name)
   assert all(v not in ('.','..') for v in p.parts)
   rel=pathlib.Path(*p.parts[3:]); dst=extract/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(wheel.read(name))
  example='compiler_playground/_support/examples/research_infra.py'
  original_example=wheel.read(example)
  example_target=root/'examples/research_infra.py'
  example_target.parent.mkdir(exist_ok=True)
  if example_target.exists():assert example_target.read_bytes()==original_example
  else:example_target.write_bytes(original_example)
  include=['test_dataset_registry_materials.py','test_dataset_loader_extended.py','test_dataset_mixtures.py','test_dataset_operations.py','test_dataset_storage_sources.py','test_dataset_training.py','test_dataset_composition_pipeline.py','test_dataset_generators.py','test_dataset_catalog_api.py','test_dataset_admission.py']
  exact={x.name for x in extract.iterdir() if x.is_file()}
  assert set(include)<=exact
  binding={'version':'0.21.13','wheel_sha256':hashlib.sha256(outerzip.read('wheel/compiler_playground-0.21.13-py3-none-any.whl')).hexdigest(),'tests_extracted':len(tests),'selected_tests':include}
sel=[extract/x for x in include]
venvsite=root/'venv/lib/python3.13/site-packages'
env=dict(os.environ, PYTHONPATH=str(venvsite),PYTHONNOUSERSITE='1')
args=[sys.executable,'-m','pytest','-q','-ra','--disable-warnings',*map(str,sel)]
p=subprocess.run(args,text=True,capture_output=True,env=env,timeout=240,cwd=str(extract))
report={'format':'cpg-original-0.21.13-wheel-dataset-focused-regressions-v1','command':args,'source_binding':binding,'returncode':p.returncode,'passed':p.returncode==0,'runtime_scope':'Python3.13 system pytest with exact isolated 0.21.13 venv wheel on PYTHONPATH; no remote calls/Ubuntu target','stdout_tail':p.stdout[-15000:],'stderr_tail':p.stderr[-8000:]}
(root/'release/official-wheel-focused-dataset-regression.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(root/'release/official-wheel-focused-dataset-regression.log').write_text(p.stdout+'\n--- STDERR ---\n'+p.stderr)
print('return',p.returncode,'\n',p.stdout[-3000:],'\n',p.stderr[-1500:]);sys.exit(p.returncode)
