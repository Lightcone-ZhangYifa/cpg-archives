#!/usr/bin/env python3
"""Try the complete upstream RemCCG configure and its explicitly separate embedded CCG component."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'dataset-lane/remccg';SRC=next((BASE/'source').iterdir())
def run(argv,working,limit=80):
 t=time.time()
 try:
  p=subprocess.run(argv,cwd=working,capture_output=True,text=True,timeout=limit)
  return {'argv':list(map(str,argv)),'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'elapsed_sec':round(time.time()-t,3)}
 except subprocess.TimeoutExpired as e:
  return {'argv':list(map(str,argv)),'returncode':124,'stdout':str(e.stdout),'stderr':str(e.stderr)+' [TIMEOUT]','elapsed_sec':round(time.time()-t,3)}
conf=run(['cmake','-S',str(SRC),'-B',str(BASE/'canonical-build'),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release'],BASE)
for kind in ('A','B'):
 comp=BASE/('isolated-embedded-'+kind);comp.mkdir(exist_ok=False)
 shutil.copytree(SRC/'lib/ccg',comp/'lib-ccg')
 p=run(['make','-j4','CC=clang'],comp/'lib-ccg',90)
 (BASE/f'embedded-ccg-{kind}-build-stdout.log').write_text(p['stdout']);(BASE/f'embedded-ccg-{kind}-build-stderr.log').write_text(p['stderr'])
 if kind=='A':a=p
 else:b=p
 if p['returncode']==0:
  binary=comp/'lib-ccg/ccg';prefix=BASE/('prefix-embedded-'+kind)/'bin';prefix.mkdir(parents=True,exist_ok=False)
  shutil.copy2(binary,prefix/'ccg')
  p['sha256']=hashlib.sha256((prefix/'ccg').read_bytes()).hexdigest()
  p['version']=run([str(prefix/'ccg'),'--version'],prefix,15)
result={'format':'cpg-remccg-source-actual-build-preflight-v1','source_id':'dataset-ref.remccg',
        'original_repository_version':'e181f6525ef83ff332130deacf5e8df062c44ee3',
        'original_archive_sha256':'6c57247dde51b1ea24fc5433f57b11cbb6e8cd6bb065515496a98a9c28a824ca',
        'complete_source_configure':conf,'embedded_ccg_independent_A':a,'embedded_ccg_independent_B':b,
        'may_claim_full_RemCCG_generator':False,'this_is_embedded_library_only':True,
        'original_target_ubuntu2404_qualified':False,'independent_host_execution_qualified':False}
(BASE/'remccg-source-preflight.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'root_configure_exit':conf['returncode'],'embedded_build_A':a['returncode'],'embedded_build_B':b['returncode'],'embedded_argv':a['argv'],
'root_configure_tail':conf['stderr'][-1000:], 'embedded_error_tail':a['stderr'][-1500:]},indent=2))
