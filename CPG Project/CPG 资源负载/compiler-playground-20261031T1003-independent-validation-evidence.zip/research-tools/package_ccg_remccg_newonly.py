#!/usr/bin/env python3
"""Create the exact SHA-object incremental bundle; NO original upstream archive bytes repacked."""
from pathlib import Path
import hashlib,io,json,os,stat,zipfile
ROOT=Path(__file__).resolve().parent
RELEASE=ROOT/'release';RELEASE.mkdir(exist_ok=True)
PRE=ROOT/'dataset-lane'
C=PRE/'ccg/dataset-candidate/prepared'
R=PRE/'remccg/dataset-candidate/prepared'
B=PRE/'ccg/prefix-B/bin/ccg'
IN=Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.4-objects-001.zip')
PREFIX='compiler-playground-20261031T1003-independent-ccg-remccg'
ZIP=RELEASE/(PREFIX+'-new-only-sha-objects.zip')
INDEX=RELEASE/(PREFIX+'-new-only-manifest.json')

def sha_file(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def desc(target,p,**extra):
 return {'path':target,'sha256':sha_file(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),**extra}

new=[];inherited=[];source_files={}
for id,prefix,source_root,ready in (
 ('ccg','ccg','upstream',C),('remccg','remccg','',R)):
 for p in sorted(ready.rglob('*')):
  if not p.is_file():continue
  r=p.relative_to(ready).as_posix()
  dst=f'{prefix}/{r}'
  orig=(r.startswith('upstream/') if id=='ccg' else r not in ('dataset.json','prepared.json'))
  if orig:
   inherited.append(desc(dst,p,source='inherited_exact_original',source_id=id))
   source_files[id]=source_files.get(id,0)+1
  else:
   kind='dataset_manifest_or_receipt' if r in ('dataset.json','prepared.json') else 'new_seeded_dataset_material'
   new.append((desc(dst,p,source='new_derived_SHA',kind=kind),p))
assert source_files=={'ccg':19,'remccg':35},source_files
assert len(new)==29,len(new) # 24 generated C files + 1 generation index + 4 dataset metadata files
new.append((desc('native/bin/ccg',B,source='new_host_native_prebuilt',kind='host-only-binary'),B))
expected_objs={r['sha256']:str(path) for r,path in new}
if len(expected_objs)!=len(new):raise ValueError('Duplicated newly generated SHA object; reference old identity instead')
ccg=json.loads((PRE/'ccg/dataset-candidate/dataset-card-validation.json').read_text())
rem=json.loads((PRE/'remccg/dataset-candidate/dataset-card-validation.json').read_text())
assert ccg['prepared_material_files']==44 and rem['prepared_material_files']==35
manifest={
 'format':'cpg-ccg-remccg-new-only-layer-v1','created_utc':'2026-10-31T02:16:00Z',
 'owner_round':'20261031T1003Z-independent-native-generators','formal_baseline':'0.21.13',
 'formally_published':False,'qualification_increment':{'original_resources':0,'dataset_cards':0,'official_benchmark':0,'OCI':0,'hardware':0},
 'fixed_denominator':{'resources':1862,'trusted_apt':1247,'non_apt':615,'dataset_cards':195},
 'inherited_formal_counts':{'managed_resource_ids':1700,'pending_original_resource_ids':162,'dataset_cards_verified':88,'dataset_card_pending_ids':107,'dataset_primary_samples':2238},
 'source_packages':{
    'ccg':{'original_resource_id':'dataset-ref.ccg','original_dataset_id':'ccg','upstream_url':'https://codeload.github.com/Mrktn/ccg/tar.gz/108f4304f9b2f187173a44749b56b3eb64dd4590',
           'revision':'108f4304f9b2f187173a44749b56b3eb64dd4590','archive_sha256':'5ce850a78f49665919ccdcb0fe759827c039e49632695f35b4a47d59c6c915b9','archive_bytes':12898,
           'unmodified_original_file_count':19,'license_expression':'NOASSERTION','license_review_required':True,'source_build_native_host_only':True,'host_prebuilt_isolation':True,'main_generated_program_execution':False},
    'remccg':{'original_resource_id':'dataset-ref.remccg','original_dataset_id':'remccg','upstream_url':'https://codeload.github.com/haoxintu/RemCCG/tar.gz/e181f6525ef83ff332130deacf5e8df062c44ee3',
           'revision':'e181f6525ef83ff332130deacf5e8df062c44ee3','archive_sha256':'6c57247dde51b1ea24fc5433f57b11cbb6e8cd6bb065515496a98a9c28a824ca','archive_bytes':137841,
           'unmodified_original_file_count':35,'license_expression':'NOASSERTION','license_review_required':True,'source_build_native_host_only':False,'original_generator_not_executed':True}},
 'inherited_source_volume':{'exact_library_file_id':'libfile_20afc30d50908191b47f998ed2d2ce5c','name':IN.name,
   'sha256':'3cfa06d68223d45fef179b9e037eff2e5f49c4229d22b869a2aecbffac3148c9','bytes':258168292,
   'old_original_tar_objects_redelivered':0,'complete_original_trees_must_be_recovered':True},
 'new_entries':[r for r,_ in new],'inherited_entries':inherited,
 'expected_dataset_fingerprints':{'ccg':ccg['fingerprint'],'remccg':rem['dataset_fingerprint']},
 'independent_candidate_counts':{'dataset_cards':2,'unique_primary_samples':42,'generated_programs':24,'remccg_original_source_units':18,
   'replacement_mixture_draws_not_extra_original_samples':60},
 'lineage_group_policy':'ccg-remccg-shared-ancestry-v1; variants across these two adapters must not leak train->test',
 'host_qualification':'Debian13 Linux x86_64 only; Ubuntu24.04 target not verified',
 'generated_programs_run':False,'network_access_during_preparation':False,
 'download_without_baseline_not_supported':'Original source bytes are inherited by exact previous volume identity; use strict restorer and saved volume.'}
assert len(new)==30 and len(inherited)==54
assert sha_file(IN)==manifest['inherited_source_volume']['sha256'] and IN.stat().st_size==258168292
assert all(x['path'] not in {r['path'] for r,_ in new} for x in inherited)
INDEX.write_text(json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    def store(name,content):
        info=zipfile.ZipInfo(name)
        info.date_time=(2026,10,31,2,0,0)
        info.external_attr=(0o100644<<16)
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,content,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
    store('manifest.json',json.dumps(manifest,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
    for row,p in sorted(new,key=lambda x:x[0]['sha256']):
        store('objects/'+row['sha256'],p.read_bytes())
with zipfile.ZipFile(ZIP) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(new)+1
    assert all(hashlib.sha256(z.read('objects/'+row['sha256'])).hexdigest()==row['sha256'] for row,_ in new)
release_record={'artifact':ZIP.name,'sha256':sha_file(ZIP),'bytes':ZIP.stat().st_size,
   'new_sha_objects':len(new),'original_previously_delivered_payload_objects_repacked':0,
   'exact_historical_source_volume_library_id':'libfile_20afc30d50908191b47f998ed2d2ce5c',
   'manifest_file':INDEX.name,'manifest_sha256':sha_file(INDEX),'target_modes_declared_and_restore_enforced':True,
   'original_inputs':source_files,'formally_promoted':False}
(RELEASE/(PREFIX+'-bundle-construction-report.json')).write_text(json.dumps(release_record,indent=2,sort_keys=True)+'\n')
print(json.dumps(release_record,indent=2,sort_keys=True))
