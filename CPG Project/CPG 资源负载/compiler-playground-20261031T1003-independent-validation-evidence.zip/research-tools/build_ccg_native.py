#!/usr/bin/env python3
"""Verify host-only reproducible CCG source generator dual builds from exact cached source.

Generated programs may contain UB, so NEVER execute them. Validate C syntax only.
"""
from __future__ import annotations
import concurrent.futures,hashlib,json,os,pathlib,platform,shutil,subprocess,time
from collections import Counter
ROOT=pathlib.Path(__file__).resolve().parent
ORIGIN=next((ROOT/'dataset-lane/ccg/source').iterdir())
BASE=ROOT/'dataset-lane/ccg'
N=24
CFLAGS=['--max-functions','3','--max-localvars','3','--max-function-parameters','3','--min-statements-per-block','1','--max-statements-per-block','3','--max-expression-nesting','3','--max-block-nesting','3','--max-pointer-depth','2','--no-omitted-operand-conditional']
def sha(path):return hashlib.file_digest(open(path,'rb'),'sha256').hexdigest()
def cmd(argv,cwd=None,timeout=60):
 start=time.time()
 try:
  p=subprocess.run(argv,cwd=cwd,capture_output=True,timeout=timeout)
  return {'argv':list(map(str,argv)),'cwd':str(cwd) if cwd else None,'returncode':p.returncode,'elapsed':round(time.time()-start,4),'stdout':p.stdout.decode('utf-8','replace'),'stderr':p.stderr.decode('utf-8','replace')}
 except subprocess.TimeoutExpired as e:
  return {'argv':list(map(str,argv)),'cwd':str(cwd) if cwd else None,'returncode':124,'elapsed':round(time.time()-start,4),'stdout':(e.stdout or b'').decode('utf-8','replace'),'stderr':(e.stderr or b'').decode('utf-8','replace')+'\nTIMEOUT'}

def build(kind):
 workspace=BASE/('build-'+kind);source=workspace/'upstream';prefix=BASE/('prefix-'+kind)
 
 if not source.exists():
  shutil.copytree(ORIGIN,source,symlinks=False)
 p=cmd(['make','-j4'],cwd=source,timeout=180)
 (workspace/'make-stdout.log').write_text(p['stdout']);(workspace/'make-stderr.log').write_text(p['stderr'])
 if p['returncode']==0:
  (prefix/'bin').mkdir(parents=True,exist_ok=True);shutil.copy2(source/'ccg',prefix/'bin/ccg')
  os.chmod(prefix/'bin/ccg',0o755)
  p.update({'binary_sha256':sha(prefix/'bin/ccg'),'binary_bytes':(prefix/'bin/ccg').stat().st_size,
            'bin_mode':oct((prefix/'bin/ccg').stat().st_mode&0o777)})
  p['version']=cmd([prefix/'bin/ccg','--version'],timeout=15)
 return {'kind':kind,'build':p,'prefix':str(prefix),'source':str(source)}

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:built=list(ex.map(build,['A','B']))
assert all(x['build']['returncode']==0 for x in built), 'CCG original native build failed: '+repr(built)
binary_bit_identical = built[0]['build']['binary_sha256']==built[1]['build']['binary_sha256']
# Upstream's -g embeds absolute build paths; functional A/B equivalence is still checked below.
assert all(x['build']['version']['returncode']==0 for x in built),'CCG version smoke failed'

out=BASE/'generated-compile-only';out.mkdir(exist_ok=True)
def seed_run(seed):
 name=f'seed-{seed:05d}';path=out/(name+'.c')
 a=BASE/'prefix-A/bin/ccg';b=BASE/'prefix-B/bin/ccg'
 argv=['--seed',str(seed),*CFLAGS]
 pa=cmd([a,*argv],timeout=45);pb=cmd([b,*argv],timeout=45)
 if pa['returncode'] or pb['returncode']:
  return {'seed':seed,'gen_a':pa,'gen_b':pb,'generation_passed':False}
 expected=pa['stdout'].encode();observed=pb['stdout'].encode()
 assert expected==observed, f'Dual-prefix deterministic generation differs at seed {seed}'
 path.write_bytes(expected)
 gcc=cmd(['gcc','-std=c11','-fsyntax-only','-w',str(path)],timeout=30)
 clang=cmd(['clang','-std=c11','-fsyntax-only','-w',str(path)],timeout=30) if shutil.which('clang') else {'returncode':127,'stdout':'','stderr':'clang not installed'}
 return {'seed':seed,'file':path.name,'sha256':sha(path),'bytes':path.stat().st_size,'generator_argv':argv,
         'generator_a_returncode':pa['returncode'],'generator_b_returncode':pb['returncode'],
         'dual_prefix_identical':True,'gcc_syntax_returncode':gcc['returncode'],'clang_syntax_returncode':clang['returncode'],
         'gcc_error_excerpt':gcc['stderr'][-650:],'clang_error_excerpt':clang['stderr'][-650:],
         'gcc_elapsed':gcc['elapsed'],'clang_elapsed':clang.get('elapsed')}

seeds=[1000+i for i in range(N)]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 results=list(ex.map(seed_run,seeds))
assert len(results)==N and all(x.get('dual_prefix_identical') for x in results), 'Generator run failed/reproducibility mismatch'
assert len(set(x['sha256'] for x in results))==N, 'Generator produced duplicate bytes under distinct seeds'
# Check the exported B prefix remains functional after A prefix retirement: A is not deleted in this script;
# actual destructive isolation is performed by separate only-own-dir test later.
report={'format':'compiler-playground-independent-ccg-native-build-and-dataset-producer-v1','scope':'Linux Debian 13 host; original Ubuntu 24.04 target NOT qualified','upstream_version':'HEAD observed 2026-10-23 pinned 108f4304f9b2f187173a44749b56b3eb64dd4590',
 'original_source_sha256':'5ce850a78f49665919ccdcb0fe759827c039e49632695f35b4a47d59c6c915b9',
 'original_source_bytes':12898,'upstream_url':'https://codeload.github.com/Mrktn/ccg/tar.gz/108f4304f9b2f187173a44749b56b3eb64dd4590',
 'exact_upstream_c_license':'NOASSERTION (existing catalog; source C headers include MIT-style text, but no independent license conclusion asserted)',
 'builds':built,'output_count':len(results),'all_generated_reproducibly':True,'binary_bit_identical':binary_bit_identical,
 'binary_nondeterminism_explanation':'Upstream make -g embeds distinct source paths (DWARF); do not assert byte-identical A/B binaries.',
 'gcc_syntax_ok':sum(r['gcc_syntax_returncode']==0 for r in results),
 'clang_syntax_ok':sum(r['clang_syntax_returncode']==0 for r in results),
 'generated':results,'generated_programs_executed':False,'semantic_correctness_oracle':False,'official_benchmark':False,
 'original_resource_id':'dataset-ref.ccg','original_dataset_card_id':'ccg','new_resource_admission_claim':0,
 'host_compiler':subprocess.run(['gcc','--version'],capture_output=True,text=True).stdout.splitlines()[0],
 'host':platform.platform()}
(BASE/'ccg-host-native-and-generation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('output_count','gcc_syntax_ok','clang_syntax_ok','all_generated_reproducibly')},indent=2))
print('BINARY',built[0]['build']['binary_sha256'],built[0]['build']['binary_bytes'])
