#!/usr/bin/env python3
"""Real isolated consumer probes for selected original Python resource IDs.

The checks are specifically scoped to locally archived, SHA-locked upstream
wheels. They do not claim source compilation, Ubuntu 24.04, Docker or hardware.
"""
from __future__ import annotations
import argparse, importlib, importlib.metadata, json, os, pathlib, subprocess, sys, tempfile, threading, zipfile

def require_local(module, prefix):
    m=importlib.import_module(module)
    resolved=pathlib.Path(m.__file__).resolve()
    expected=pathlib.Path(prefix).resolve()
    assert resolved.is_relative_to(expected),f'leakage: {module} located at {resolved} outside {expected}'
    return m

def urllib3_probe(prefix, wheel_dir):
    require_local('urllib3',prefix)
    import urllib3
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            payload=('GET '+self.path).encode()
            self.send_response(200);self.send_header('Content-Length',str(len(payload)))
            self.end_headers();self.wfile.write(payload)
        def do_POST(self):
            n=int(self.headers['Content-Length']);payload=self.rfile.read(n)
            self.send_response(201);self.send_header('Content-Length',str(len(payload)))
            self.end_headers();self.wfile.write(payload)
        def log_message(self,*a):pass
    s=ThreadingHTTPServer(('127.0.0.1',0),Handler);t=threading.Thread(target=s.serve_forever,daemon=True);t.start()
    try:
        url=f'http://127.0.0.1:{s.server_address[1]}'
        pool=urllib3.PoolManager(retries=False,timeout=urllib3.Timeout(total=4))
        r=pool.request('GET',url+'/hello?case=1')
        assert r.status==200 and r.data==b'GET /hello?case=1',(r.status,r.data)
        r=pool.request('POST',url+'/post',body=b'compiler-playground-test')
        assert r.status==201 and r.data==b'compiler-playground-test'
        try: urllib3.util.parse_url('http://[broken')
        except urllib3.exceptions.LocationParseError: pass
        else: raise AssertionError('malformed URL must be rejected')
        assert importlib.metadata.version('urllib3')=='2.8.0'
        return {'version':'2.8.0','http_get':'passed','http_post':'passed','negative_url':'passed',
                'loopback_server_only':True}
    finally:
        s.shutdown();s.server_close();t.join(timeout=5)

def wheel_probe(prefix, wheel_dir):
    require_local('wheel',prefix);require_local('packaging',prefix)
    assert importlib.metadata.version('wheel')=='0.48.0'
    with tempfile.TemporaryDirectory(prefix='cpg-wheel-test-') as td:
        base=pathlib.Path(td);root=base/'src';lib=root/'probe_pkg';lib.mkdir(parents=True)
        (lib/'__init__.py').write_text('ANSWER = 42\n')
        info=root/'probe_pkg-0.1.dist-info';info.mkdir()
        (info/'METADATA').write_text('Metadata-Version: 2.1\nName: probe-pkg\nVersion: 0.1\n')
        (info/'WHEEL').write_text('Wheel-Version: 1.0\nGenerator: CPG consumer fixture\nRoot-Is-Purelib: true\nTag: py3-none-any\n')
        dest=base/'dist';dest.mkdir()
        proc=subprocess.run([sys.executable,'-I','-m','wheel','pack',str(root),'-d',str(dest)],text=True,capture_output=True,timeout=30)
        assert proc.returncode==0,(proc.stdout,proc.stderr)
        wheels=list(dest.glob('probe_pkg-0.1-*.whl')); assert len(wheels)==1,wheels
        with zipfile.ZipFile(wheels[0]) as z:
            assert z.read('probe_pkg/__init__.py')==b'ANSWER = 42\n'
            assert any(x.endswith('.dist-info/RECORD') for x in z.namelist())
        bad=subprocess.run([sys.executable,'-I','-m','wheel','pack',str(base/'missing'),'-d',str(dest)],text=True,capture_output=True,timeout=30)
        assert bad.returncode!=0
        return {'version':'0.48.0','wheel_pack':'passed','wheel_members':'passed','invalid_source':'rejected'}

def soup_probe(prefix, wheel_dir):
    require_local('soupsieve',prefix)
    require_local('bs4',prefix)
    require_local('typing_extensions',prefix)
    from bs4 import BeautifulSoup
    import soupsieve as sv
    soup=BeautifulSoup('<main><ul><li class="x">A</li><li class="x disabled">B</li><li class="x"><span>C</span></li></ul></main>','html.parser')
    hits=[li.get_text() for li in sv.select('main > ul > li.x:not(.disabled)',soup)]
    assert hits==['A','C'],hits
    assert len(sv.select('li:has(> span)',soup))==1
    assert len(sv.select('li:nth-child(2)',soup))==1
    try:sv.compile('li[')
    except sv.SelectorSyntaxError: pass
    else:raise AssertionError('malformed selector must fail')
    assert importlib.metadata.version('soupsieve')=='3.0.3'
    return {'version':'3.0.3','css_select':'passed','css_has':'passed','nth_child':'passed','invalid_selector':'rejected'}

def pip_probe(prefix,wheel_dir):
    require_local('pip',prefix)
    assert importlib.metadata.version('pip')=='26.2.2'
    env=os.environ.copy();env.update({'PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1','PYTHONNOUSERSITE':'1'})
    target=next(pathlib.Path(wheel_dir).glob('urllib3-2.8.0-*.whl'))
    def run(*args):
        return subprocess.run([sys.executable,'-I','-m','pip',*args],capture_output=True,text=True,env=env,timeout=45)
    v=run('--version'); assert v.returncode==0 and '26.2.2' in v.stdout,(v.stdout,v.stderr)
    install=run('install','--no-index','--no-deps','--disable-pip-version-check',str(target))
    assert install.returncode==0,(install.stdout,install.stderr)
    require_local('urllib3',prefix)
    missing=run('install','--no-index','--no-deps','cpg-impossible-nonexistent-package-2026-qax')
    assert missing.returncode!=0,(missing.stdout,missing.stderr)
    uninstall=run('uninstall','--yes','urllib3');assert uninstall.returncode==0,(uninstall.stdout,uninstall.stderr)
    # In this consumer process, importlib caches urllib3; check physical package files.
    assert not list(pathlib.Path(prefix).glob('urllib3-*.dist-info')), 'uninstall left wheel metadata'
    return {'version':'26.2.2','install_locked_wheel':'passed','no_index_missing_package':'rejected','uninstall':'passed'}

def isoduration_probe(prefix,wheel_dir):
    for m in ['isoduration','arrow','dateutil','six','tzdata']:
        require_local(m,prefix)
    from datetime import datetime,timezone
    import isoduration
    assert importlib.metadata.version('isoduration')=='20.11.0'
    value=isoduration.parse_duration('P1Y2M3DT4H5M6S')
    assert isoduration.format_duration(value)=='P1Y2M3DT4H5M6S'
    base=datetime(2024,1,1,0,0,0,tzinfo=timezone.utc)
    result=base+value
    assert result==datetime(2025,3,4,4,5,6,tzinfo=timezone.utc),result
    try:isoduration.parse_duration('invalid P7 bananas')
    except ValueError:pass
    else:raise AssertionError('invalid duration should fail')
    return {'version':'20.11.0','duration_parse_format':'passed','calendar_date_arithmetic':'passed','invalid_duration':'rejected'}

def narwhals_probe(prefix,wheel_dir):
    for m in ['narwhals','polars','_polars_runtime_32']:
        require_local(m,prefix)
    import narwhals as nw,polars as pl
    assert importlib.metadata.version('narwhals')=='2.27.1'
    assert importlib.metadata.version('polars-runtime-32')=='2.0.0'
    native_binary=list(pathlib.Path(prefix).glob('_polars_runtime_32/*.so'))
    assert len(native_binary)==1 and native_binary[0].stat().st_size>10000,native_binary
    original=pl.DataFrame({'id':[1,1,2],'metric':[2,3,10]})
    frame=nw.from_native(original)
    result=nw.to_native(frame.group_by('id').agg(nw.col('metric').sum().alias('total')).sort('id'))
    assert result.to_dict(as_series=False)=={'id':[1,2],'total':[5,10]},result
    try:frame.select(nw.col('column_not_in_dataset'))
    except Exception as e:
        assert 'column_not_in_dataset' in str(e),str(e)
    else:raise AssertionError('bad column expression should fail')
    return {'version':'2.27.1','polars_version':'2.0.0','native_runtime_abi':'cp310-abi3',
            'native_runtime_binary_load':'passed','polars_native_compute':'passed',
            'narwhals_groupby_aggregation':'passed','nonexistent_column':'rejected'}

def polars_runtime_probe(prefix,wheel_dir):
    for m in ['polars','_polars_runtime_32']:
        require_local(m,prefix)
    import polars as pl
    assert importlib.metadata.version('polars-runtime-32')=='2.0.0'
    libs=list(pathlib.Path(prefix).glob('_polars_runtime_32/*.so'))
    assert len(libs)==1 and libs[0].stat().st_size>10000
    data=pl.DataFrame({'x':[1,2,3,4,5],'key':['a','a','b','b','b']})
    got=data.group_by('key').agg(pl.col('x').sum().alias('sum')).sort('key')
    assert got.to_dict(as_series=False)=={'key':['a','b'],'sum':[3,12]},got
    try:data.select(pl.col('not_a_column'))
    except Exception as e:assert 'not_a_column' in str(e),str(e)
    else:raise AssertionError('polars must reject missing column')
    return {'version':'2.0.0','native_abi3_extension_from_exact_wheel':'loaded',
            'native_groupby_aggregation':'passed','nonexistent_column':'rejected',
            'host_arch':'x86_64','source_compilation':'not_performed'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--package',choices=['urllib3','wheel','soupsieve','pip','isoduration','narwhals','polars_runtime'],required=True)
    p.add_argument('--prefix',required=True);p.add_argument('--wheel-dir',required=True)
    a=p.parse_args()
    probes={'urllib3':urllib3_probe,'wheel':wheel_probe,'soupsieve':soup_probe,'pip':pip_probe,'isoduration':isoduration_probe,'narwhals':narwhals_probe,'polars_runtime':polars_runtime_probe}
    tests=probes[a.package](a.prefix,a.wheel_dir)
    print(json.dumps({'status':'passed','package':a.package,'python':sys.version,'executable':sys.executable,'checks':tests,'module_prefix':a.prefix},sort_keys=True))
if __name__=='__main__':main()
