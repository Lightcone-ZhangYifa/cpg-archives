#!/usr/bin/env python3
"""Independent original-ID coverage auditor + disjoint new-host-QA handoff.

Does not mutate the CPG canonical workspace, active release, or continuation state.
"""
from __future__ import annotations
import collections, datetime, hashlib, json, pathlib, platform, sys

ROOT=pathlib.Path(__file__).resolve().parent.parent
EVID=ROOT/'evidence'; OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
BASE=json.loads((ROOT/'recovery/reports/resource-status.json').read_text())
PRIOR=json.loads((ROOT/'input/compiler-playground-v0.21.4-next-round-priorities.json').read_text())
STATE=json.loads((ROOT/'input/compiler-playground-continuation-state.json').read_text())
COV_BASE=json.loads((ROOT/'recovery/reports/coverage-tables.json').read_text())
QA_FILES=sorted(EVID.glob('*.qa.json'))
CASES={}
for f in QA_FILES:
    x=json.loads(f.read_text());rid=x['original_resource_id']
    assert rid not in CASES and x['status']=='passed' and x['independent_prefix_isolation_verified']
    assert x['original_target_qualification'] is False and x['source_built'] is False
    assert len(x['prefixes'])==2 and len(x['checks'])>=7
    for p in x['prefixes']:
        assert p['functional']['status']=='passed'
    CASES[rid]={'qa_evidence':'evidence/'+f.name,
                'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
                'bytes':f.stat().st_size,
                'host_functionality':'passed',
                'original_target_qualification':False,
                'source_built':False,
                'independent_install_prefixes_verified':2,
                'primary_positive_negative_consumer_checks':True,
                'native_binary_runtime_executed':rid=='py.polars-runtime-32'}
IDS=sorted(CASES)
resources=BASE['resources'];RIDS=[r['id'] for r in resources]
assert BASE['resource_count']==PRIOR['fixed_catalog_denominator']==1862
assert len(RIDS)==len(set(RIDS))==1862
status_fields=['trusted_apt_wrapper','current_functional_profile','current_material_availability_profile']
canonical=set()
qualifier_sets={k:set() for k in ('apt_trusted','functional_current','static_material_current')}
for r in resources:
    rid=r['id'];st=r['stages']
    if st['trusted_apt_wrapper']['status']=='trusted':qualifier_sets['apt_trusted'].add(rid)
    if st['current_functional_profile']['status']=='passed':qualifier_sets['functional_current'].add(rid)
    if st['current_material_availability_profile']['status']=='passed':qualifier_sets['static_material_current'].add(rid)
    if any(st[k]['status']=='passed' for k in ('current_functional_profile','current_material_availability_profile')) or st['trusted_apt_wrapper']['status']=='trusted':canonical.add(rid)
assert all(len(qualifier_sets[k]&qualifier_sets[j])==0 for k in qualifier_sets for j in qualifier_sets if k!=j)
assert {k:len(v) for k,v in qualifier_sets.items()}=={'apt_trusted':1247,'functional_current':145,'static_material_current':101}
assert len(canonical)==1493==COV_BASE['coverage']['managed_resources_union']
pending=set(RIDS)-canonical
assert len(pending)==369==len(PRIOR['complete_pending_resource_ids'])
assert pending==set(PRIOR['complete_pending_resource_ids'])
assert set(IDS)<=pending
assert len(IDS)==7
assert STATE['latest_completed_version']=='0.21.4'
assert STATE['latest_completed_delivery']['library_file_id']=='libfile_a68800413d80819183195b42233aec5e'
assert STATE['active_round']['status']=='active' and STATE['active_round']['owner']!='auto-20261028T1204Z'

def grouped(fn):
    groups=collections.defaultdict(lambda:{'total':0,'canonical':0,'pending':0,'host_qa_candidate':0})
    for r in resources:
        vals=fn(r)
        for value in vals if isinstance(vals,(list,tuple,set)) else [vals]:
            name=str(value or '(missing)')
            a=groups[name];a['total']+=1
            a['canonical']+=(r['id'] in canonical)
            a['pending']+=(r['id'] in pending)
            a['host_qa_candidate']+=(r['id'] in CASES)
    return {k:dict(groups[k],canonical_percent=round(100*groups[k]['canonical']/groups[k]['total'],6)) for k in sorted(groups)}

all_groups={
  'original_catalog_kind':grouped(lambda r:r.get('catalog_kind')),
  'original_baseline_provider':grouped(lambda r:r.get('baseline_provider')),
  'original_primary_category':grouped(lambda r:r.get('resource_category_primary')),
  'original_resource_category':grouped(lambda r:r.get('resource_category')),
  'original_source_origin_group':grouped(lambda r:r.get('source_origin',{}).get('group')),
  'original_source_host':grouped(lambda r: r.get('source_origin',{}).get('hosts') or ['(no host)']),
  'original_source_url':grouped(lambda r:r.get('source_origin',{}).get('urls') or ['(no URL recorded)']),
}
for dim in ['original_catalog_kind','original_baseline_provider','original_primary_category','original_resource_category','original_source_origin_group']:
    assert sum(v['total'] for v in all_groups[dim].values())==1862,(dim,sum(v['total'] for v in all_groups[dim].values()))
    assert sum(v['canonical'] for v in all_groups[dim].values())==1493
    assert sum(v['host_qa_candidate'] for v in all_groups[dim].values())==7

known={r['id']:r for r in resources}
qualifications=[]
for rid in IDS:
    r=known[rid]
    qualifications.append({
      'id':rid,'version':r['version'],
      'original_resource_definition':r['definition'],
      'original_catalog_sha256':r['catalog_sha256'],
      'source_locks_sha256':r['source_locks_sha256'],
      'original_source_origin':r['source_origin'],
      'original_baseline_provider':r['baseline_provider'],
      'original_catalog_kind':r['catalog_kind'],
      'original_resource_category':r['resource_category'],
      'canonical_qualified':False,
      'new_host_qualifications':CASES[rid],
      'preexisting_canonical_functionality_status':r['stages']['current_functional_profile']['status'],
      'preexisting_functionality_evidence':r['stages']['current_functional_profile'],
      'canonical_blocker_cleared':False if rid=='py.soupsieve' else None,
    })

cov={'format':'cpg-disjoint-host-qa-independent-coverage-v1',
     'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'fixed_original_resource_denominator':1862,
     'immutable_canonical_version':'0.21.4',
     'immutable_canonical_delivery_sha256':STATE['latest_completed_delivery']['sha256'],
     'canonical_qualified_original_resource_ids':1493,
     'canonical_percent':round(100*1493/1862,6),
     'canonical_pending_original_resource_ids':369,
     'canonical_delta_in_this_disjoint_run':0,
     'real_host_functional_candidates_this_run':7,
     'candidate_original_resource_ids':IDS,
     'candidate_host_qualification_unique_not_canonical':True,
     'target_distribution':'Ubuntu 24.04 x86_64 (original resource declaration)',
     'tested_distribution':'Debian 13 x86_64 Python 3.13.5 (actual isolated host)',
     'source_compiled_this_round':0,
     'native_precompiled_wheel_runtime_executed':1,
     'native_runtime_primary_original_id':'py.polars-runtime-32',
     'apt_trusted_inherited_no_retest':1247,
     'functional_current_canonical_inherited_no_retest':145,
     'static_material_current_canonical_inherited_no_retest':101,
     'exact_input_integrity_baseline':1720,
     'python_isolated_installations_baseline_not_equal_to_functionality':285,
     'dataset_interface_cards_baseline':25,
     'dataset_cards_total':195,
     'new_official_benchmarks':0,
     'new_OCI_executions':0,
     'new_hardware_executions':0,
     'baseline_faithfulness':'The seven host tests do not modify canonical tally, target, source locks, original definition, official benchmark or datasets.',
     'by_original_dimension':all_groups,
     'candidate_evidence':qualifications,
     'unresolved_peer_dependency_cycle':{'id':'py.soupsieve',
        'reason':'Original upstream SoupSieve wheel imports BeautifulSoup despite declaring no distribution dependency; reverse run edge creates a registry cycle. Isolated joint-peer consumer execution succeeded but original standalone closure and canonical registry SCC policy remain unresolved.',
        'canonical_blocker_resolved':False},
     'full_pending_original_ids':sorted(pending)}
(OUT/'coverage.json').write_text(json.dumps(cov,indent=2,ensure_ascii=False)+'\n')
queue={'format':'cpg-disjoint-host-qa-full-original-pending-queue-v1',
       'fixed_original_count':1862,'canonical_covered':1493,'canonical_pending':369,
       'baseline_immutable_version':'0.21.4','source':'published v0.21.4 next-round-priorities + resource-status JSON',
       'candidate_adjudication':'host QA only, not canonical; original queue preserved',
       'candidate_status_by_original_id':CASES,
       'original_unmodified_pending_resources':PRIOR['pending_resources']}
assert len(queue['original_unmodified_pending_resources'])==369
(OUT/'full-pending-queue.json').write_text(json.dumps(queue,indent=2,ensure_ascii=False)+'\n')
cleanup={'format':'cpg-disjoint-qa-cleanup-v1',
 'original_canonical_release_artifacts_deleted':[],
 'other_active_conversation_files_touched':[],
 'other_canonical_state_mutations':[],
 'new_artifact_payloads_created':[],
 'preexisting_canonical_volumes_repacked':[],
 'local_deleted_qa_prefixes':[str(ROOT/'work/isolated_qa'/rid.replace('.','-')/'prefix-A') for rid in IDS],
 'local_retained_for_readback':[str(ROOT/'work/isolated_qa'/rid.replace('.','-')/'prefix-B') for rid in IDS],
 'local_input_copies_owned_by_this_disjoint_round':'preserve until own archive saved and verified; no external cleanup',
 'data_preservation_note':'The immutable 0.21.4 volumes and other user Library objects were not deleted or rewritten.'}
for v in cleanup['local_deleted_qa_prefixes']:
 assert not pathlib.Path(v).exists(),v
(OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2,ensure_ascii=False)+'\n')
report={'format':'cpg-host-qualifications-run-result-v1',
    'project':'CompilerPlayground',
    'owner':'auto-20261028T1204Z-disjoint-python-host-qa',
    'work_directory':str(ROOT),
    'canonical_version':'0.21.4',
    'canonical_coverage':'1493/1862 (80.182599%)',
    'canonical_resources_new':0,
    'candidate_count':len(IDS),
    'candidate_resource_ids':IDS,
    'two_fresh_independent_prefixes_each':True,
    'negative_consumer_checks_each':True,
    'prefix_B_verified_after_A_removed':True,
    'source_builds_executed':0,
    'native_binary_execution':'precompiled Polars x86_64 ABI3 extension from original immutable wheel',
    'original_target_ubuntu24_04_executed':False,
    'offline_install_and_functional_test':'passed for all original wheel SHA-locked inputs; no runtime downloads',
    'active_foreign_round_conflict_policy':'retain other owner r07, do not alter canonical workspace, original state, release identities, or other session directories',
    'automation_task_id':'6ae0511879ec81919b31f10e974409ad',
    'automation_schedule':'BEGIN:VEVENT\\nDTSTART:20261027T073936Z\\nRRULE:FREQ=HOURLY;INTERVAL=2\\nEND:VEVENT',
    'automation_task_mutated':False,
    'qualifications':qualifications,
    'recovery_material_sha256':hashlib.sha256((ROOT/'input/compiler-playground-recovery-kit-v0.21.4.zip').read_bytes()).hexdigest()}
(OUT/'run-result.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':'PASS','baseline':len(canonical),'pending':len(pending),'candidate_count':len(IDS),'candidates':IDS,'groups':{k:len(v) for k,v in all_groups.items()}},indent=2))
