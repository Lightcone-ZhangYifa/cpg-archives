#!/usr/bin/env python3
"""Verify and stage an immutable CPG resource-check overlay in a new directory.

This is *not* an automatic canonical publication command.  It requires the
exact original package.json files from v0.21.4 and refuses to overwrite any
existing worktree.  No original wheels or other historical payloads are copied.
"""
import argparse,hashlib,json,os,pathlib,shutil,stat,tempfile,zipfile


def sha(b):return hashlib.sha256(b).hexdigest()

def inspect_archive(path):
    z=zipfile.ZipFile(path)
    member_names=z.namelist()
    assert len(member_names)==len(set(member_names)),'duplicate archive entry'
    assert 'manifest.json' in member_names,'missing signed-file-list manifest'
    manifest=json.loads(z.read('manifest.json'))
    assert manifest['format']=='compiler-playground-isolated-functional-overlay-v1'
    assert manifest['canonical_version_unchanged']=='0.21.4'
    expected=set(manifest['entries'])
    assert expected==set(member_names)-{'manifest.json'},'archive member list differs from manifest'
    total=0
    for name,entry in manifest['entries'].items():
        p=pathlib.PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and len(p.parts)>0 and '\\' not in name
        info=z.getinfo(name)
        assert info.file_size==entry['bytes'] and info.file_size <= 20_000_000
        total+=info.file_size
        assert total<=100_000_000,'archive expanded files exceed bound'
        assert sha(z.read(name))==entry['sha256'],'member content hash mismatch '+name
        mode=(info.external_attr>>16)&0o777
        assert mode==entry['mode'],'file mode mismatch '+name
    return z,manifest

def stage(archive,baseline,out):
    z,manifest=inspect_archive(archive)
    base=pathlib.Path(baseline).resolve(strict=True)
    out=pathlib.Path(out).absolute()
    assert not out.exists(),f'output already exists: {out}'
    assert base.is_dir() and out!=base
    if out == base or base in out.parents:raise ValueError('output cannot be beneath baseline')
    target_identities=manifest['resource_identities']
    for rid,identity in target_identities.items():
        path=base/'resources/packages'/rid/'package.json'
        assert path.is_file() and not path.is_symlink(),'missing baseline '+rid
        assert sha(path.read_bytes())==identity['original_package_sha256'],'baseline byte identity mismatch '+rid
        assert identity['id']==rid
        overlay_name=f'overlay/resources/packages/{rid}/package.json'
        updated=json.loads(z.read(overlay_name))
        original=json.loads(path.read_bytes())
        for key in ['id','sources','dependencies','target','recipe']:
            assert original[key]==updated[key],'baseline provenance changed '+rid+'/'+key
        assert original['metadata']['catalog']==updated['metadata']['catalog']
        assert len(updated['checks'])==len(original['checks'])+2
    out.parent.mkdir(parents=True,exist_ok=True)
    tmp=pathlib.Path(tempfile.mkdtemp(prefix='.cpg-overlay-restore-',dir=out.parent))
    try:
        for name,entry in manifest['entries'].items():
            if not name.startswith('overlay/'):continue
            rel=pathlib.PurePosixPath(name).relative_to('overlay')
            target=tmp.joinpath(*rel.parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(z.read(name))
            target.chmod(entry['mode'])
        for rid,identity in target_identities.items():
            target=tmp/'resources/packages'/rid/'package.json'
            assert target.is_file() and sha(target.read_bytes())==identity['overlay_package_sha256']
        tmp.rename(out)
    except BaseException:
        shutil.rmtree(tmp)
        raise
    return {'restored_resource_ids':sorted(target_identities),'restored_file_count':sum(n.startswith('overlay/') for n in manifest['entries']),'output':str(out),'baseline':str(base),'canonical_coverage_delta':0,'promoted':False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive',required=True)
    p.add_argument('--baseline')
    p.add_argument('--out')
    args=p.parse_args()
    if bool(args.baseline)!=bool(args.out):p.error('--baseline and --out must be supplied together')
    if args.baseline:
        result=stage(args.archive,args.baseline,args.out)
    else:
        z,manifest=inspect_archive(args.archive)
        result={'status':'verified_only','resource_ids':sorted(manifest['resource_identities']),'entries':len(manifest['entries']),'canonical_coverage_delta':0}
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__':main()
