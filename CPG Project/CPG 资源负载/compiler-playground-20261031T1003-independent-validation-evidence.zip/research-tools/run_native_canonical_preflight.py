#!/usr/bin/env python3
"""Attempt exact canonical configure steps from the formally delivered v0.21.13 wheel.

Only checks the independent Debian host, NEVER qualifies the original Ubuntu target.
"""
import concurrent.futures, hashlib, io, json, os, pathlib, platform, shutil, subprocess, time, zipfile
HERE=pathlib.Path(__file__).resolve().parent
BUNDLE=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.13-cpg-continuation-20261030.zip')
SRC_IDS=['heaptrack','autofdo','stp']
with zipfile.ZipFile(BUNDLE) as z,zipfile.ZipFile(io.BytesIO(z.read('wheel/compiler_playground-0.21.13-py3-none-any.whl'))) as w:
    recipes={k:json.loads(w.read(f'compiler_playground/_support/resources/packages/{k}/package.json')) for k in SRC_IDS}

def run(k):
    b=HERE/k
    src=next((b/'source').iterdir())
    prefix=b/'installed-host-only'
    build=b/'build'
    build.mkdir(exist_ok=True)
    recipe=recipes[k]['recipe']
    if k=='heaptrack':
        argv=recipe['configure_argv']
    elif k=='autofdo':
        argv=recipe['configure_argv']
    else:
        argv=['cmake','-S','{source}','-B','{build}','-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_INSTALL_PREFIX={prefix}']
    argv=[v.format(source=src,build=build,prefix=prefix) for v in argv]
    t=time.time()
    try:
        proc=subprocess.run(argv,cwd=str(b),capture_output=True,text=True,timeout=90)
        code=proc.returncode
        stdout,stderr=proc.stdout,proc.stderr
    except subprocess.TimeoutExpired as e:
        code=124;stdout=e.stdout.decode(errors='replace') if isinstance(e.stdout,bytes) else (e.stdout or '')
        stderr=(e.stderr.decode(errors='replace') if isinstance(e.stderr,bytes) else (e.stderr or ''))+'\nTIMEOUT\n'
    (b/'cmake-configure-stdout.log').write_text(stdout)
    (b/'cmake-configure-stderr.log').write_text(stderr)
    generated=(build/'CMakeCache.txt').exists()
    missing=[]
    for lines in (stdout,stderr):
        missing.extend([s.strip() for s in lines.splitlines() if any(t in s.lower() for t in ('could not find','not found','required','missing','error'))][-28:])
    return {'id':k,'source_sha256':recipes[k]['sources'][0]['sha256'],'source_url':recipes[k]['sources'][0]['url'], 'original_version':recipes[k]['version'],'original_target':recipes[k]['target'],'canonical_recipe':recipe,'attempted_argv':argv,'executed':True,'exit_code':code,'elapsed_sec':round(time.time()-t,3),'host_only':True,'build_dir':str(build),'install_prefix':str(prefix),'generated_cmake_cache':generated,'stdout_sha256':hashlib.sha256(stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(stderr.encode()).hexdigest(),'blocker_excerpt':missing}

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as exe:
    results=list(exe.map(run,SRC_IDS))
report={'schema':'cpg-autonomous-canonical-source-configure-attempt-v1','host':platform.platform(),'host_os_release':open('/etc/os-release').read(),'on_ubuntu2404_target':False,'round':'20261031T1003Z-isolated','baseline_formal':'0.21.13','attempts':results,'qualification':'no new ID qualified by this host preflight','source_codes_preserved':True}
(HERE/'native_canonical_preflight.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ('id','exit_code','elapsed_sec','blocker_excerpt')} for r in results],ensure_ascii=False,indent=2))
