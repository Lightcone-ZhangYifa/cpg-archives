#!/usr/bin/env python3
"""Produce and verify one independent `ccg` compile-only Dataset card.

Consumes immutable original source tree and reproducible locally generated source.
Does not run generated programs or claim upstream benchmark score.
"""
from __future__ import annotations
import copy,hashlib,json,os,pathlib,shutil,subprocess,time
from compiler_playground import datasets
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'dataset-lane/ccg'
SOURCE=next((BASE/'source').iterdir())
ART=BASE/'dataset-candidate'
MATERIAL=ART/'material-root'
READY=ART/'prepared'
INDEX=ART/'index'

def digest(path):
 with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def write(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False);f.write('\n')

def smoke():
 original=json.loads((BASE/'ccg-host-native-and-generation.json').read_text())
 if original['output_count']!=24 or not original['all_generated_reproducibly']:raise ValueError('Producer is not verified')
 MATERIAL.mkdir(parents=True,exist_ok=False)
 shutil.copytree(SOURCE,MATERIAL/'upstream')
 shutil.copytree(BASE/'generated-compile-only',MATERIAL/'generated')
 meta={'schema_version':1,'identity':'ccg','upstream_url':original['upstream_url'],'upstream_revision':'108f4304f9b2f187173a44749b56b3eb64dd4590',
       'original_source_sha256':original['original_source_sha256'],'original_source_bytes':original['original_source_bytes'],
       'generator_source_builds':[{k:x['build'][k] for k in ('binary_sha256','binary_bytes','bin_mode')} for x in original['builds']],
       'generator_flag_policy':'versioned explicit seeds 1000..1023 and bounded exact flags; no implicit stochastic generators during loading',
       'samples':[ {k:r[k] for k in ('seed','file','sha256','bytes','generator_argv','gcc_syntax_returncode','clang_syntax_returncode')} for r in original['generated']],
       'compiler_facts':'GCC and Clang results are host-only syntax probes, not correctness or official benchmark',
       'all_input_24_included':True,'license_status':'NOASSERTION inherited from original catalog; top-level notice absent; no new license conclusion',
       'all_samples_group':'ccg-remccg/shared-generator-family-v1',
       'generated_programs_executed':False,'external_data_used':False,'native_target_ubuntu2404_qualified':False}
 write(MATERIAL/'generation-metadata.json',meta)
 src_files=sorted(p.relative_to(MATERIAL).as_posix() for p in (MATERIAL/'upstream').rglob('*') if p.is_file())
 assert len(src_files)==19, f'Expected all 19 original files, got {len(src_files)}'
 for f in src_files:
  sha1=digest(MATERIAL/f);sha2=digest(SOURCE/pathlib.Path(f).relative_to('upstream'));assert sha1==sha2
 ds=datasets.from_source_tree(
    MATERIAL,revision=meta['upstream_revision'],url=meta['upstream_url'],
    license_file='upstream/ccg.c',license_expression='NOASSERTION',adapter_file='upstream/Makefile',
    dataset_id='ccg',suite='ccg',patterns=['generated/*.c'],
    group_by=lambda _: 'ccg-remccg/shared-generator-family-v1',
    group_policy_id='ccg-remccg-shared-ancestry-v1',
    extra_files=src_files+['generation-metadata.json'])
 assert ds.purpose=='compile_only' and len(ds)==24
 assert len(set(s.group for s in ds))==1
 raw_ids={s.id for s in ds};assert len(raw_ids)==24
 # Every original source file is carried by every sample's context, rather than silently truncating the source archive.
 for s in ds:
  assert len(s.payload['files'])==20
  assert s.payload['execution']['config']['runtime_qualified'] is False
  assert s.payload['execution']['config']['compile_qualified'] is False
  assert s.payload['license']['expression']=='NOASSERTION'
 prepared=datasets.prepare('ccg',ds,material_root=MATERIAL,output_dir=READY)
 loaded=datasets.load('ccg',root=READY,verify=True)
 assert len(loaded)==24 and loaded.fingerprint==ds.fingerprint
 # Source originals / all generated context retained with exact 19+24+1=44 files.
 receipt=json.loads((READY/'prepared.json').read_text());assert len(receipt['files'])==44
 indexed=datasets.save_to_disk(loaded,INDEX,material_root=READY)
 indexed.close()
 with datasets.load_from_disk(INDEX,verify_files=True) as reloaded:
  assert reloaded.fingerprint==ds.fingerprint and len(reloaded)==24
  def loader():return datasets.DataLoader(reloaded,batch_size=7,seed=334, sampler=datasets.RandomSampler())
  a=loader();a.next_batch();state=a.state_dict();b=loader();b.load_state_dict(state)
  traces=[]
  for i in range(12):
   x=[s.id for s in a.next_batch()];y=[s.id for s in b.next_batch()]
   assert x==y and a.state_dict()==b.state_dict()
   traces.append({'step':i,'samples':x,'epoch':a.epoch})
  assert a.epoch>state['epoch']
 # Negative branch: tampering with one sample's bytes in an independently copied prepared tree must be caught.
 adversarial=ART/'tamper-negative'
 shutil.copytree(READY,adversarial)
 victim=adversarial/'generated/seed-01000.c';victim.chmod(0o644)
 with victim.open('ab') as f:f.write(b'\n/*tamper*/')
 rejected=False;reason=None
 try:datasets.load('ccg',root=adversarial,verify=True)
 except Exception as e:rejected=True;reason=f'{type(e).__name__}: {e}'
 assert rejected,'Tampered prepared source was incorrectly accepted'
 # Invalid source path negative branch: importer refuses traversal before material preparation.
 invalid_rejected=False
 try:
  datasets.from_source_tree(MATERIAL,revision=meta['upstream_revision'],url=meta['upstream_url'],
    license_file='upstream/ccg.c',license_expression='NOASSERTION',adapter_file='upstream/Makefile',
    dataset_id='ccg',suite='ccg',patterns=['../*.c'])
 except (ValueError,TypeError) as e: invalid_rejected=True
 assert invalid_rejected
 # Dataset card metadata MUST remain rooted to original card ID; no new resource admission.
 report={'format':'cpg-independent-prepared-dataset-card-v1','card_id':'ccg','resource_id':'dataset-ref.ccg',
   'previous_formal_dataset_cards':'88/195','proposed_independent_new_card_count':1,'formal_card_admitted_by_this_run':0,
   'sample_count':len(ds),'all_source_original_files':19,'all_generations':24,
   'prepared_material_files':len(receipt['files']),'prepared_material_bytes':receipt['material_bytes'],
   'fingerprint':ds.fingerprint,'prepared_manifest_sha256':digest(READY/'dataset.json'),
   'prepared_receipt_sha256':digest(READY/'prepared.json'),'index_sha256':digest(INDEX/'index.json'),
   'group_policy':'ccg-remccg-shared-ancestry-v1','unique_lineage_groups':1,
   'gcc_syntax_ok':original['gcc_syntax_ok'],'clang_syntax_ok':original['clang_syntax_ok'],
   'data_loader_steps_replayed':len(traces),'data_loader_cross_epoch':True,
   'tamper_rejected':rejected,'tamper_error':reason,'source_traversal_rejected':invalid_rejected,
   'original_archive_sha256':meta['original_source_sha256'],'source_pin':meta['upstream_revision'],
   'license_expression':'NOASSERTION','license_review_required':True,
   'executed_generated_programs':False,'official_benchmark_qualified':False,'native_original_ubuntu_target_qualified':False,
   'source_build_host_only':True,'split_warning':'All 24 generated variants belong to one family: cannot split across train/val/test without family leakage',
   'sample_ids':sorted(raw_ids),'resume_trace':traces}
 write(ART/'dataset-card-validation.json',report)
 print(json.dumps({k:report[k] for k in ('card_id','sample_count','all_source_original_files','prepared_material_files','fingerprint','tamper_rejected','data_loader_cross_epoch')},indent=2))

if __name__=='__main__':smoke()
