#!/usr/bin/env python3
"""DeepFuzz original Python source as compile-only dataset, no trained model, no generated samples."""
import contextlib,hashlib,io,json,pathlib,shutil,warnings
from compiler_playground import datasets
from compiler_playground.datasets.sources import build_sample
R=pathlib.Path(__file__).resolve().parent;B=R/'dataset-lane/deepfuzz';SOURCE=next((B/'source').iterdir());DEST=B/'dataset-candidate'
ORIGSHA='1b051cf91e31f15a5415a7e377a6f8047f920fa9a9939fa71baed181babb5f25'
REV='6079bef655b471b82c70e51024d3d4824092f396'
URL='https://codeload.github.com/s3team/DeepFuzz/tar.gz/'+REV
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def main():
 assert ORIGSHA in (B/'original-archive.meta').read_text()
 assert SOURCE.name.endswith(REV)
 DEST.mkdir(exist_ok=False)
 mat=DEST/'material-root';shutil.copytree(SOURCE,mat)
 files=sorted(p.name for p in mat.iterdir() if p.is_file());assert len(files)==8
 assert all(sha(SOURCE/f)==sha(mat/f) for f in files)
 names=sorted(x for x in files if x.endswith('.py'));assert len(names)==6
 parser_evidence=[];samples=[]
 for name in names:
  src=(mat/name).read_bytes()
  ws=[]
  with warnings.catch_warnings(record=True) as caught:
   warnings.simplefilter('always')
   code=compile(src, f'original-DeepFuzz/{name}','exec',dont_inherit=True)
   ws=[{'warning_kind':x.category.__name__,'message':str(x.message),'lineno':x.lineno} for x in caught]
  assert code.co_name=='<module>'
  parser_evidence.append({'file':name,'input_sha256':sha(mat/name),'input_bytes':len(src),'python3_13_compile_only_pass':True,'warnings':ws})
  sample=build_sample(root=mat,id='deepfuzz/'+name,group='deepfuzz/same-original-trained-generator-source',suite='deepfuzz',
   sources=[name],language='python',revision=REV,url=URL,
   license_file='README',license_expression='NOASSERTION',adapter_file='run.sh',
   extra_files=[x for x in files if x!=name],
   execution_config={'kind':'python_source','compile_qualified':False,'runtime_qualified':False,'model_weights_available':False,
    'original_GCC_training_data_available':False,'generated_deepfuzz_programs':0},
   payload={'admission':'compile_only_python_source_not_trained_generator','syntax_on_Debian13_Python313_only':True})
  samples.append(sample)
 ds=datasets.Dataset(samples,dataset_id='deepfuzz',purpose='compile_only',material_root=mat,
  metadata={'provider':'original_fixed_source_archive','original_repository_sha256':ORIGSHA,
   'generated_programs_available':0,'original_training_data_and_trained_model_missing':True,
   'single_lineage_group_policy':'all_same_DF_generator_model_family'})
 assert len(ds)==6 and len({x.group for x in ds})==1
 prep=DEST/'prepared';pres=datasets.prepare('deepfuzz',ds,material_root=mat,output_dir=prep)
 loaded=datasets.load('deepfuzz',root=prep,verify=True);assert len(loaded)==6 and loaded.fingerprint==ds.fingerprint
 receipt=json.loads((prep/'prepared.json').read_text());assert len(receipt['files'])==8
 index=DEST/'index';indexed=datasets.save_to_disk(loaded,index,material_root=prep);indexed.close()
 with datasets.load_from_disk(index,verify_files=True) as cold:
  assert cold.fingerprint==ds.fingerprint
  a=datasets.DataLoader(cold,batch_size=2,seed=901,sampler=datasets.RandomSampler())
  a.next_batch();ckpt=a.state_dict()
  b=datasets.DataLoader(cold,batch_size=2,seed=901,sampler=datasets.RandomSampler());b.load_state_dict(ckpt)
  for i in range(8):
   assert [x.id for x in a.next_batch()]==[x.id for x in b.next_batch()]
   assert a.state_dict()==b.state_dict()
  assert a.epoch>ckpt['epoch']
 bad=DEST/'tamper-negative';shutil.copytree(prep,bad)
 victim=bad/'generate.py';victim.chmod(0o644);victim.write_bytes(victim.read_bytes()+b'\n# tampered\n')
 reason='';rejected=False
 try:datasets.load('deepfuzz',root=bad,verify=True)
 except Exception as exc:rejected=True;reason=type(exc).__name__+': '+str(exc)
 assert rejected
 report={'format':'cpg-independent-deepfuzz-source-only-dataset-v1','card_id':'deepfuzz','original_resource_id':'dataset-ref.deepfuzz',
  'original_upstream_url':URL,'original_revision':REV,'original_archived_source_sha256':ORIGSHA,
  'original_source_files':8,'original_python_source_samples':6,'original_other_files':['README','run.sh'],
  'input_all_bytes_and_sha_verified':True,'parse_only_passed_six_sources':True,'all_syntax_warnings_preserved':parser_evidence,
  'exact_original_source_materials_in_all_sample_contexts':True,'purpose':'compile_only',
  'trained_model_weights_available':False,'external_GCC_training_corpus_available':False,
  'generated_source_programs':0,'model_inference_executed':False,'Python_source_exec_executed':False,
  'actual_ubuntu_target_qualified':False,'license_expression':'NOASSERTION','license_review_required':True,
  'dataset_fingerprint':ds.fingerprint,'prepared_files':len(receipt['files']),
  'prepared_manifest_sha256':sha(prep/'dataset.json'),'prepared_receipt_sha256':sha(prep/'prepared.json'),
  'cold_index_verified':True,'loader_cross_epoch_resume_verified':True,'tamper_rejected':True,'tamper_error':reason,
  'original_source_and_generator_family_one_group':True,'separate_train_test_group_split_forbidden_without_external_independent_families':True,
  'formal_resource_increment':0,'formal_dataset_card_increment':0}
 (DEST/'dataset-card-validation.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['card_id','original_python_source_samples','prepared_files','dataset_fingerprint','tamper_rejected','trained_model_weights_available']},indent=2))
if __name__=='__main__':main()
