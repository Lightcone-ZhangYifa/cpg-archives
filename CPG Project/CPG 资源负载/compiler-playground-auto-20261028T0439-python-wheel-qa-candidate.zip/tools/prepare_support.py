from pathlib import Path
import zipfile,json,hashlib
base=Path('/mnt/data/cpg-auto-20261028-0439/incoming')
out=base.parent/'branches/python-wheel-qa'
index=json.loads(zipfile.ZipFile(base/'compiler-playground-v0.21.4-resource-indexes.zip').read('resource-inputs/index.json'))['inputs']
ids={'py.sniffio','py.lark'}
records=[]
core=zipfile.ZipFile(base/'compiler-playground-v0.20.0-core-005.zip')
for o in index:
 matches=ids.intersection(o.get('resource_ids',[]))
 if not matches:continue
 rid=sorted(matches)[0]
 original=json.loads(core.read('compiler-playground/resources/packages/'+rid+'/package.json'))
 sha=o['sha256']; src=original['sources'][0]
 assert sha==src['sha256']
 archive=base/o['delivery']['volume'];assert archive.exists()
 data=zipfile.ZipFile(archive).read(o['delivery']['member'])
 assert len(data)==o['bytes'] and hashlib.sha256(data).hexdigest()==sha
 fname=Path(src['material_path']).name
 (out/'wheelhouse'/fname).write_bytes(data)
 records.append({'resource_id':rid,'sha256':sha,'bytes':len(data),'physical_wheel':fname,'source_volume':archive.name,'source_url':src['url'],'used_only_as_dependency':True,'original_qualified_id_not_recategorized':True})
 assert records[-1]['used_only_as_dependency']
(out/'evidence/dependency-inputs.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
print(records)
