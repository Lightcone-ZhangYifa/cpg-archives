#!/usr/bin/env python3
"""Parallel current-host qualification. Writes no canonical CPG release state."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib, json, os, pathlib, shutil, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parent.parent
WHEEL=ROOT/'work/verified_wheels'
QA=ROOT/'work/isolated_qa'
EVID=ROOT/'evidence'
EXTRACT=json.loads((EVID/'locked_wheel_extraction.json').read_text())
CASES={
 'py.urllib3':{'wheel_ids':['py.urllib3'],'test':'urllib3'},
 'py.wheel':{'wheel_ids':['py.wheel','py.packaging'],'test':'wheel'},
 'py.soupsieve':{'wheel_ids':['py.soupsieve','py.beautifulsoup4','py.typing-extensions'],'test':'soupsieve'},
 'py.pip':{'wheel_ids':['py.pip'],'test':'pip'},
 'py.isoduration':{'wheel_ids':['py.isoduration','py.arrow','py.python-dateutil','py.six','py.tzdata'],'test':'isoduration'},
 'py.narwhals':{'wheel_ids':['py.narwhals','py.polars','py.polars-runtime-32'],'test':'narwhals'},
 'py.polars-runtime-32':{'wheel_ids':['py.polars','py.polars-runtime-32'],'test':'polars_runtime'},
}

def run(cmd,env=None,timeout=120):
 t=time.monotonic();p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,timeout=timeout)
 return {'argv':list(map(str,cmd)),'returncode':p.returncode,'stdout':p.stdout[-20000:],
  'stderr':p.stderr[-20000:],'elapsed_seconds':round(time.monotonic()-t,3)}

def files_fingerprint(prefix):
 h=hashlib.sha256(); total=0
 for f in sorted(prefix.rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts or f.suffix=='.pyc':continue
  b=f.read_bytes();p=str(f.relative_to(prefix)).encode()
  h.update(len(p).to_bytes(8,'big')+p+len(b).to_bytes(8,'big')+hashlib.sha256(b).digest());total+=1
 return {'sha256':h.hexdigest(),'files_without_pyc':total}

def qualify(rid,spec):
 slug=rid.replace('.','-');folder=QA/slug
 assert not folder.exists(),f'refuse to overwrite existing QA {folder}'
 folder.mkdir(parents=True)
 receipt={'format':'cpg-host-isolated-original-wheel-qa-v1','original_resource_id':rid,
   'status':'failed','original_target_qualification':False,
   'host_platform':'Debian 13 x86_64 Python 3.13.5 (host-specific, not Ubuntu 24.04)',
   'source_built':False,'package_ids_in_consumer_closure':spec['wheel_ids'],
   'inputs':[EXTRACT['wheels'][id] for id in spec['wheel_ids']],
   'prefixes':[],'checks':[],'independent_prefix_isolation_verified':False}
 try:
  env=os.environ.copy();env.update({'PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1','PYTHONNOUSERSITE':'1'})
  env.pop('PYTHONPATH',None)
  wheel_names=[str(WHEEL/EXTRACT['wheels'][id]['wheel']) for id in spec['wheel_ids']]
  for label in ['A','B']:
   venv=folder/f'prefix-{label}'
   creation=run([sys.executable,'-m','venv','--without-pip',str(venv)],env,timeout=90)
   receipt['checks'].append({'stage':f'venv_create_{label}',**creation});assert creation['returncode']==0
   pp=venv/'lib'/f'python{sys.version_info.major}.{sys.version_info.minor}'/'site-packages'
   pp.mkdir(parents=True,exist_ok=True)
   install=run([sys.executable,'-m','pip','install','--no-index','--no-deps',
                '--no-compile','--disable-pip-version-check','--target',str(pp),*wheel_names],env,timeout=90)
   receipt['checks'].append({'stage':f'locked_offline_install_{label}',**install});assert install['returncode']==0
   exe=venv/'bin/python'
   t=run([str(exe),'-I',str(ROOT/'work/consumer_qualifications.py'),
          '--package',spec['test'],'--prefix',str(pp),'--wheel-dir',str(WHEEL)],env,timeout=90)
   receipt['checks'].append({'stage':f'functional_positive_negative_{label}',**t});assert t['returncode']==0, t['stderr']
   parsed=json.loads(t['stdout'].splitlines()[-1]);assert parsed['status']=='passed'
   receipt['prefixes'].append({'label':label,'install_prefix':str(pp),
        'install_content_fingerprint':files_fingerprint(pp),'functional':parsed})
  # Fingerprint is checked against B before A is deleted: A deletion changes no B file bytes.
  B=folder/'prefix-B';before=files_fingerprint(B)
  shutil.rmtree(folder/'prefix-A')
  assert not (folder/'prefix-A').exists()
  after=files_fingerprint(B);assert before==after
  t=run([str(B/'bin/python'),'-I',str(ROOT/'work/consumer_qualifications.py'),
         '--package',spec['test'],'--prefix',str(B/'lib'/f'python{sys.version_info.major}.{sys.version_info.minor}'/'site-packages'),
         '--wheel-dir',str(WHEEL)],env,timeout=90)
  receipt['checks'].append({'stage':'B_after_A_deleted',**t});assert t['returncode']==0,t['stderr']
  receipt['independent_prefix_isolation_verified']=True
  receipt['status']='passed'
  # No automatic cleanup of the remaining independent prefix before all consumers finish.
 except BaseException as e:
  receipt['failure_type']=type(e).__name__;receipt['failure_detail']=str(e)
 finally:
  name=rid.replace('.','-')+'.qa.json'
  (EVID/name).write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
 return rid,receipt['status'],receipt.get('failure_detail','')

def main():
 QA.mkdir(parents=True,exist_ok=True)
 with ThreadPoolExecutor(max_workers=4) as pool:
  jobs=[pool.submit(qualify,k,v) for k,v in CASES.items() if not (QA/k.replace('.','-')).exists()]
  for f in as_completed(jobs):print(f.result(),flush=True)
if __name__=='__main__':main()
