"""Run *project's actual* package-spec parser and check executor on candidate overlays.
Independently preserved v0.21.4 compiler_playground.packages implementation is imported.
"""
from __future__ import annotations
import hashlib,json,os,pathlib,sys,concurrent.futures
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'manager-preview/src'))
from compiler_playground.packages.spec import validate_spec
from compiler_playground.packages.checks import run_checks
original=json.loads((ROOT/'evidence/original-resource-ledger.json').read_text())
wheels={x['artifact']:x for x in json.loads((ROOT/'evidence/wheels.json').read_text())}
receipts={w:json.loads((ROOT/'evidence'/f'host-{w}.json').read_text()) for w in wheels}
all_candidate=json.loads((ROOT/'evidence/candidate-ids.json').read_text())['host_qa_completed_ids']
ids={x['id'] for x in all_candidate}
audit=[]

def one(item):
    rid=item['resource_id'];artifact=item['artifact'];receipt=receipts[artifact]
    candidate=ROOT/'overlay/resources/packages'/rid/'package.json'
    if rid not in ids:return {'resource_id':rid,'excluded':'failed_or_partial_host_qa'}
    raw=json.loads((ROOT/'definitions'/rid/'package.original.json').read_text())
    new=json.loads(candidate.read_text());out={'resource_id':rid,'artifact':artifact,'checks':[],'source_identity_retained':False}
    assert raw['sources']==new['sources']
    assert raw['metadata']['catalog']==new['metadata']['catalog']
    assert raw['target']==new['target']
    assert raw['dependencies']==new['dependencies']
    assert raw['recipe']==new['recipe']
    assert len(raw['checks'])==0 and len(new['checks'])==2
    assert validate_spec(new)['id']==rid
    out['source_identity_retained']=True
    for side in ['source_install','independent_install']:
        status=receipt['statuses'][side]
        prefix=pathlib.Path(status['sys_prefix'])
        assert prefix.is_dir() and str(prefix).startswith(str(ROOT/'run'/artifact)+'/')
        vals={'prefix':str(prefix),'recipe':str(candidate.parent/'recipe'),'package_name':new['recipe']['package_name'],'version':new['metadata']['catalog']['version'],'python':str(prefix/'bin/python')}
        output=ROOT/'evidence/manager-checks'/rid/side
        outcome=run_checks(new['checks'],values=vals,output_dir=output,environment={'PIP_NO_INDEX':'1','PYTHONNOUSERSITE':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1'})
        # Actual summary keys can differ across versions; inspect rows on failure.
        statuses=[r['status'] for r in outcome.get('checks',outcome.get('results',[]))] if isinstance(outcome,dict) else []
        out['checks'].append({'prefix':side,'output_dir':str(output),'summary':outcome,'reported_check_statuses':statuses})
    return out

with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
    audit=list(pool.map(one,original))
(ROOT/'evidence/manager-overlay-validation.json').write_text(json.dumps({'format':'cpg-actual-manager-v0214-candidate-qa-v1','original_catalog_total':1862,'candidate_ids':sorted(ids),'per_resource':audit},indent=2,sort_keys=True)+'\n')
for r in audit:
 if 'excluded' in r:continue
 stat=[row['summary'].get('status','n/a') for row in r['checks']]
 print(r['resource_id'],stat, 'detail',r['checks'][0]['summary'].get('counts'))
print('validated schemas:',sum('excluded' not in r for r in audit),'checks executed',sum(len(r.get('checks',[])) for r in audit))
