#!/usr/bin/env python3
"""Public, byte-checked incremental replay from new candidate ZIP + inherited immutable base.

No current-session workspace, later candidate artifacts, or external network needed.
"""
from __future__ import annotations
import hashlib,json,os,pathlib,shutil,subprocess,sys,time,zipfile
ROOT=pathlib.Path(__file__).resolve().parent.parent
SRC=ROOT/'deliverables/compiler-playground-auto-20261028T1204-disjoint-hostqa.zip'
DST=ROOT/'public-incremental-replay';EVID=ROOT/'deliverables/public-restore-qa.json'
assert not DST.exists(),f'not destroying an existing independent replay: {DST}'
assert SRC.exists()
report={'format':'cpg-public-incremental-restore-validation-v1','status':'failed',
        'new_archive':{'sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'bytes':SRC.stat().st_size},
        'inherited_baseline':'official v0.21.4, original SHA-locked raw input volumes and index',
        'new_archives_used':[SRC.name],'other_active_owner_artifacts_used':[],
        'baseline_canonical_release_mutated':False,'log':[],
        'original_ids_tested':[], 'positive_and_negative_consumer_tests_in_2_independent_prefixes_each':False}
try:
    DST.mkdir(parents=True)
    with zipfile.ZipFile(SRC) as z:
        manifest=json.loads(z.read('INCREMENTAL-MANIFEST.json'))
        members=z.namelist()
        assert len(members)==len(set(members))==len(manifest['entries'])+1
        for entry in manifest['entries']:
            target=DST/entry['path']
            assert target.resolve().is_relative_to(DST.resolve())
            data=z.read(entry['path']);zi=z.getinfo(entry['path'])
            assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
            assert (zi.external_attr>>16)&0o777==int(entry['mode'],8)
            target.parent.mkdir(parents=True,exist_ok=True)
            with open(target,'xb') as f:f.write(data)
            target.chmod(int(entry['mode'],8))
    # Only use the inherited *published* source-index and raw-input volumes, not
    # other runs' workdirs/candidates. We link a read-only location by path; all
    # writes (extract/wheels/venvs/receipts) remain inside DST.
    (DST/'recovery').symlink_to(ROOT/'recovery',target_is_directory=True)
    (DST/'input').symlink_to(ROOT/'input',target_is_directory=True)
    tests=[
      ['work/extract_locked_wheels.py',120],
      ['work/run_disjoint_wheel_qa.py',280],
      ['work/build_disjoint_reports.py',60],
    ]
    for script,timeout in tests:
        command=[sys.executable,str(DST/script)];t=time.monotonic()
        p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout,
          env={**os.environ,'PIP_NO_INDEX':'1','PYTHONNOUSERSITE':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1'})
        row={'script':script,'exit_code':p.returncode,'stdout':p.stdout[-10000:],'stderr':p.stderr[-10000:],
             'elapsed_seconds':round(time.monotonic()-t,3)}
        report['log'].append(row)
        assert p.returncode==0,(script,row['stderr'])
    ids=[]
    for f in (DST/'evidence').glob('*.qa.json'):
        r=json.loads(f.read_text());assert r['status']=='passed' and r['independent_prefix_isolation_verified']
        ids.append(r['original_resource_id']);assert len(r['prefixes'])==2
        assert len([c for c in r['checks'] if c['stage'].startswith('functional_positive_negative_') and c['returncode']==0])==2
        assert len([c for c in r['checks'] if c['stage']=='B_after_A_deleted' and c['returncode']==0])==1
    assert len(ids)==len(set(ids))==7
    report['original_ids_tested']=sorted(ids)
    cov=json.loads((DST/'deliverables/coverage.json').read_text())
    assert cov['fixed_original_resource_denominator']==1862
    assert cov['canonical_qualified_original_resource_ids']==1493
    assert cov['canonical_delta_in_this_disjoint_run']==0
    assert cov['candidate_original_resource_ids']==sorted(ids)
    report['positive_and_negative_consumer_tests_in_2_independent_prefixes_each']=True
    report['independent_original_coverage_audit_passed']=True
    report['status']='passed'
except BaseException as e:
    report['failure_type']=type(e).__name__;report['failure_detail']=str(e)
finally:
    EVID.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'original_ids':report['original_ids_tested'],
 'consumer_retests':[r['exit_code'] for r in report['log']],
 'error':report.get('failure_detail','')},ensure_ascii=False))
if report['status']!='passed':sys.exit(1)
