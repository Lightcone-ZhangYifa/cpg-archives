"""Narrow patch contract: correct Python/SQL language, original provenance and negative security."""
from __future__ import annotations
import hashlib,json,pathlib,tempfile,unittest
from unittest import mock
from compiler_playground import datasets

REV='0000000000000000000000000000000000000001'
URL='https://example.org/exact-original-locked-source.tar.gz'
class PythonSQLFromSourceTree(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='cpg-sql-python-smoke-');self.addCleanup(self.tmp.cleanup)
  self.root=pathlib.Path(self.tmp.name);self.source=self.root/'frozen-source';self.source.mkdir()
  for name,body in {
    'gen.py':'print("runtime shall not execute!")\n',
    '3a.sql':'SELECT 1;\n','3b.sql':'SELECT 2;\n','minic.c':'int k(void){return 1;}\n',
    'README':'Licence status unresolved; fixture only.\n',
    'schema.sql':'CREATE TABLE fixture(x INTEGER);\n',
    'script.xyz':'Some unknown language text\n',
   }.items(): (self.source/name).write_text(body)
 def make(self,patterns):
  return datasets.from_source_tree(self.source,revision=REV,url=URL,
    license_file='README',license_expression='NOASSERTION',adapter_file='schema.sql',
    dataset_id='source-python-sql-c',suite='source-python-sql-c',patterns=patterns,
    group_by=lambda path:('query-family-3' if path.endswith('.sql') else 'source-family-'+path),
    group_policy_id='explicit-test-sql-family-v1',extra_files=['README','schema.sql'])
 def test_supported_python_sql_c_language_and_no_execution(self):
  with mock.patch('subprocess.run',side_effect=AssertionError('Never execute original sources or download')):
   ds=self.make(['gen.py','3a.sql','3b.sql','minic.c'])
   self.assertEqual(len(ds),4)
   seen={s.id.split('/')[-1]:s for s in ds}
   self.assertEqual({k:v.payload['language'] for k,v in seen.items()},
                    {'gen.py':'python','3a.sql':'sql','3b.sql':'sql','minic.c':'c'})
   self.assertEqual(seen['3a.sql'].group,seen['3b.sql'].group)
   for s in seen.values():
    self.assertEqual(s.payload['provenance']['revision'],REV)
    self.assertEqual(s.payload['provenance']['url'],URL)
    self.assertFalse(s.payload['execution']['config']['runtime_qualified'])
    self.assertFalse(s.payload['execution']['config']['compile_qualified'])
    self.assertEqual(s.payload['license']['expression'],'NOASSERTION')
    self.assertEqual(len(s.payload['files']),2)
    self.assertEqual(len(s.payload['sources']),1)
   prepared=datasets.prepare('source-python-sql-c',ds,material_root=self.source,output_dir=self.root/'prepared')
   loaded=datasets.load('source-python-sql-c',root=prepared.root,verify=True)
   self.assertEqual(ds.fingerprint,loaded.fingerprint)
   self.assertEqual({s.id:s.payload['language'] for s in ds},
                    {s.id:s.payload['language'] for s in loaded})
 def test_unknown_extension_stays_unknown_and_traversal_rejected(self):
  self.assertEqual(self.make(['script.xyz'])[0].payload['language'],'unknown')
  with self.assertRaisesRegex(ValueError,'relative without traversal'):
   self.make(['../*.sql'])
 def test_exact_original_c_languge_preserved(self):
  self.assertEqual(self.make(['minic.c'])[0].payload['language'],'c')
if __name__=='__main__':unittest.main()
