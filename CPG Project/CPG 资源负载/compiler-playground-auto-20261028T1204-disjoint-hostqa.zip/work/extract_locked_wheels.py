#!/usr/bin/env python3
"""Extract explicitly allowed SHA-256 locked original wheels from published CPG volumes.

This is *not* a new package manager or a new resource source: it audits old
immutable release media, retaining exact original input, owner and volume identity.
"""
from __future__ import annotations
import hashlib, json, os, pathlib, tempfile, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
INDEX = ROOT / 'recovery/indexfiles/resource-inputs/index.json'
INPUTS = ROOT / 'input'
DEST = ROOT / 'work/verified_wheels'
ALLOW = {
    'py.urllib3', 'py.wheel', 'py.soupsieve', 'py.pip', 'py.beautifulsoup4',
    'py.packaging', 'py.typing-extensions', 'py.isoduration', 'py.narwhals',
    'py.arrow', 'py.python-dateutil', 'py.six', 'py.tzdata', 'py.polars', 'py.polars-runtime-32',
}

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(1<<20),b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    DEST.mkdir(parents=True,exist_ok=True)
    idx=json.loads(INDEX.read_text())
    entries={row['input_ids'][0]:row for row in idx['inputs'] if len(row.get('input_ids',[]))==1 and row['input_ids'][0] in ALLOW}
    assert set(entries)==ALLOW, set(ALLOW)-set(entries)
    volumes={}
    output={}
    for id,row in sorted(entries.items()):
        d=row['delivery']; v=INPUTS/d['volume']
        if d['volume'] not in volumes:
            actual=digest(v)
            assert actual==d['volume_sha256'],(v,actual,d['volume_sha256'])
            volumes[d['volume']]={'sha256':actual,'bytes':v.stat().st_size}
        with zipfile.ZipFile(v,'r') as z:
            member=d['member'];info=z.getinfo(member)
            assert member=='objects/'+row['sha256']
            data=z.read(info)
            assert hashlib.sha256(data).hexdigest()==row['sha256']
            assert len(data)==row['bytes']
        wheel=pathlib.Path(row['material_paths'][0]).name
        assert wheel.endswith('.whl') and wheel==os.path.basename(wheel)
        output_path=DEST / wheel
        if output_path.exists():
            assert digest(output_path)==row['sha256']
        else:
            fd,tmp=tempfile.mkstemp(prefix='.locked-',dir=DEST)
            try:
                with os.fdopen(fd,'wb') as f:
                    f.write(data);f.flush();os.fsync(f.fileno())
                os.chmod(tmp,0o444)
                os.replace(tmp,output_path)
            finally:
                if os.path.lexists(tmp):os.unlink(tmp)
        output[id]={
            'resource_id':id,'original_input_sha256':row['sha256'],'original_bytes':row['bytes'],
            'original_urls':row.get('original_urls',[]),'published_volume':d['volume'],
            'published_volume_sha256':volumes[d['volume']]['sha256'],
            'published_object_member':d['member'],'wheel':wheel,
            'local_verified_path':str(output_path), 'local_file_mode':oct(output_path.stat().st_mode&0o777),
            'original_index_mode':oct(row['mode']),
        }
    receipt={'format':'cpg-immutable-original-wheel-extraction-v1',
        'source_index':'v0.21.4 resource-inputs/index.json inherited from baseline immutable volumes',
        'volumes':volumes,'wheels':output,'canonical_resource_coverage_delta':0}
    out=ROOT/'evidence/locked_wheel_extraction.json'
    out.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'status':'PASS','wheels':sorted(output),'volumes':list(volumes)},indent=2))
if __name__=='__main__':main()
