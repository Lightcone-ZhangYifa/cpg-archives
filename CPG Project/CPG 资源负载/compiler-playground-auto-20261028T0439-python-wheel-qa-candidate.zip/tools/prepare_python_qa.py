import hashlib,json,os,pathlib,zipfile,shutil,csv
from collections import defaultdict
ROOT=pathlib.Path('/mnt/data/cpg-auto-20261028-0439')
IN=ROOT/'incoming'; OUT=ROOT/'branches'/'python-wheel-qa'; OUT.mkdir(exist_ok=True,parents=True)
(INDEX:=OUT/'evidence').mkdir(exist_ok=True)
(OUT/'wheelhouse').mkdir(exist_ok=True)
(OUT/'definitions').mkdir(exist_ok=True)
(OUT/'scripts').mkdir(exist_ok=True)
index=json.loads(zipfile.ZipFile(IN/'compiler-playground-v0.21.4-resource-indexes.zip').read('resource-inputs/index.json'))['inputs']
pending=set(json.load(open(IN/'compiler-playground-v0.21.4-next-round-priorities.json'))['complete_pending_resource_ids'])
# Each resource ID is retained independently; shared physical wheel blobs are never duplicated in candidate delivery.
SHA_TO_CHECK={
 'attrs':'c647aa4a12dfbad9333ca4e71fe62ddc36f4e63b2d260a37a8b83d2f043ac309',
 'idna':'ab7ae7122974553370f0bdb919e1a960b2cd1bc1ef0276416d896db81c14582c',
 'h11':'63cf8bbe7522de3bf65932fda1d9c2772064ffb3dae62d55932da54b31cb6c86',
 'six':'4721f391ed90541fddacab5acf947aa0d3dc7d27b2e1e8eda2be8970586c3274',
 'typing_extensions':'481caa481374e813c1b176ada14e97f1f67a4539ce9cfeb3f350d78d6370c2e8',
 'certifi':'42d35340cc5b9ba78e818ddbff0c5b1c2b779de448a340fd1b989f5fa8670e1b',
 'iniconfig':'9121e2c1fdb355232495be3194c8dfe87ccc2d5dee45947b78e68f499790d7a7',
 'pluggy':'7dd7b0d8832ba3cb632c306926ded123429211b83641b35dc5c41ad2d34f9bec',
 'threadpoolctl':'cd8b60b5641b45c67bbf73c64c843235fc2d8a480c87389f52f5dbee893b86be',
 'uri_template':'a44a133ea12d44a0c0f06d7d42a52d71282e77e2f937d8abd5655b8d56fc1363',
 'tzdata':'b683bd1b6659ddcd810ff02ad09ba821d4bf1065072805063eb35c49617905ac',
 'packaging':'d7193f7c8e4e93f444fde0262bf90af30e16fa0ad0ad44cb553c87339b23cd1c',
 'narwhals':'d057df13f5852b8e157596e82eb5e955fad267425df5e420e0ee9863da483b31',
 'charset_normalizer':'3d31298449090ab8d47b7b1b2a555ff73cac7ed438a08b7ac160980c7ebed649',
 'pycparser':'51d5a8ba2be0bbe440b99d2112604c95bbbc3c2748a64260186c541e1729cd80',
 'lark':'c629b661023a014c37da873b4ff58a817398d12635d3bbb2c5a03be7fe5d1e12',
 'setuptools':'ca140b45d5325a9478f880e351484f62fef15f336462e449ca0c03c873d589c2',
 'anyio':'6152fdbbf9a77fdec97731721bebf7c4c44f7c29b424b0065826173efc7ed101',
 'typing_inspection':'65b8397ba37ccbce054456aaccddfc91e6e3083c92824df348d96ca832f3f147',
 'rfc3987_syntax':'6c3d97604e4c5ce9f714898e05401a0445a641cfa276432b0a648c80856f6a3f',
}
by_sha={o['sha256']:o for o in index if 'sha256' in o}
zcore=zipfile.ZipFile(IN/'compiler-playground-v0.20.0-core-005.zip')
records=[]; skipped=[]; received=[]
zips={}
for key,sha in SHA_TO_CHECK.items():
 o=by_sha.get(sha)
 if not o:skipped.append({'artifact':key,'reason':'hash_not_found'});continue
 volume=o.get('delivery',{}).get('volume')
 if volume is None or not (IN/volume).exists():skipped.append({'artifact':key,'reason':'missing_exact_volume','volume':volume});continue
 z=zips.setdefault(volume,zipfile.ZipFile(IN/volume))
 member=o['delivery']['member'];data=z.read(member)
 assert len(data)==o['bytes'] and hashlib.sha256(data).hexdigest()==sha
 ids=[x for x in o.get('resource_ids',[]) if x in pending and ('compiler-playground/resources/packages/'+x+'/package.json') in zcore.namelist()]
 if not ids:skipped.append({'artifact':key,'reason':'no_original_pending_resource_id'});continue
 definitions=[]
 for rid in ids:
  mp='compiler-playground/resources/packages/'+rid+'/package.json'
  definition=json.loads(zcore.read(mp))
  source=definition['sources'][0]
  if source['sha256']!=sha:raise RuntimeError(f'sha conflict {rid}: {source["sha256"]} != {sha}')
  if definition['id']!=rid:raise RuntimeError(f'original ID mismatch {rid}')
  basename=pathlib.PurePosixPath(source['material_path']).name
  definitions.append((rid,definition,basename))
 assert len({x[2] for x in definitions})==1, [x[2] for x in definitions]
 basename=definitions[0][2]
 target=OUT/'wheelhouse'/basename
 if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()!=sha:raise RuntimeError('wheel collision')
 target.write_bytes(data)
 whl=zipfile.ZipFile(target)
 metadata=[x for x in whl.namelist() if x.endswith('.dist-info/METADATA') and x.count('/')==1]
 assert len(metadata)==1
 info=whl.read(metadata[0]).decode('utf-8','replace')
 requires=[x.split(':',1)[1].strip() for x in info.splitlines() if x.startswith('Requires-Dist:')]
 for rid,definition,_ in definitions:
  mp='compiler-playground/resources/packages/'+rid+'/package.json'
  folder=OUT/'definitions'/rid
  folder.mkdir(parents=True,exist_ok=True)
  (folder/'package.original.json').write_text(json.dumps(definition,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
  records.append({'resource_id':rid,'artifact':key,'expected_sha256':sha,'original_member':mp,'original_definition_sha256':hashlib.sha256(zcore.read(mp)).hexdigest(),'original_provider':definition['provider'],'original_kind':definition['metadata']['catalog'].get('kind'),'original_category':definition['metadata']['catalog'].get('category'),'original_url':source['url'],'original_version':definition['metadata']['catalog'].get('version'), 'original_target':definition['target'],'physical_wheel':basename, 'source_volume':volume})
 received.append({'artifact':key,'sha256':sha,'bytes':len(data),'url':definitions[0][1]['sources'][0]['url'],'basename':basename,'resource_ids':[x[0] for x in definitions],'requires_dist':requires,'source_volume':volume,'source_member':member})
 (INDEX/'wheels.json').write_text(json.dumps(received,ensure_ascii=False,indent=2)+'\n')
 (INDEX/'original-resource-ledger.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
 (INDEX/'skipped.json').write_text(json.dumps(skipped,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'physical_wheels':len(received),'pending_original_ids':len(records),'names':[x['artifact'] for x in received], 'skipped':skipped,'deps':{x['artifact']:x['requires_dist'] for x in received}},indent=2))
