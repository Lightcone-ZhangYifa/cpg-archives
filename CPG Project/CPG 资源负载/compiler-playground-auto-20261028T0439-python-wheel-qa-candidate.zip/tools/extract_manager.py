"""Restore the actual v0.21.4 Python library source from the saved cumulative core chain,
without touching canonical workspaces or incorporating the old 1,862 resource payloads.
"""
from pathlib import Path
import zipfile,json,hashlib,os
root=Path('/mnt/data/cpg-auto-20261028-0439')
base=root/'incoming'; target=root/'branches/python-wheel-qa/manager-preview'
vols=['compiler-playground-v0.20.0-core-%03d.zip'%i for i in range(1,6)]+['compiler-playground-v0.21.0-core.zip','compiler-playground-v0.21.0-permission-fix-core.zip','compiler-playground-v0.21.1-core.zip','compiler-playground-v0.21.2-core.zip','compiler-playground-v0.21.3-core.zip','compiler-playground-v0.21.4-core.zip']
record={}
for vol in vols:
 z=zipfile.ZipFile(base/vol)
 count=0
 for member in z.infolist():
  path=member.filename
  if not path.startswith('compiler-playground/src/compiler_playground/') or not path.endswith('.py') or path.startswith('compiler-playground/src/compiler_playground/_support/'):
   continue
  short=Path(*Path(path).parts[1:])
  assert not short.is_absolute() and '..' not in short.parts
  dest=target/short;dest.parent.mkdir(parents=True,exist_ok=True)
  data=z.read(member)
  dest.write_bytes(data)
  dest.chmod((member.external_attr>>16)&0o777 or 0o644)
  record[str(short)]={'source_volume':vol,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':oct(dest.stat().st_mode&0o777)}
  count+=1
 print(vol,count)
# Version identity is the last core manifest; never infer qualification from a successful Python import.
(target/'restore-source-manifest.json').write_text(json.dumps({'version':'0.21.4','source_volumes':vols,'files':record},indent=2,sort_keys=True)+'\n')
print('total',len(record))
