#!/usr/bin/env python3
"""Strictly restore only NEW CPG candidate SHA objects + inherited exact original source.

This is an independent, unmerged candidate; original resource IDs and 0.21.13 formal
coverage do not change. No source download, native execution, nor implicit build.
"""
from __future__ import annotations
import argparse,hashlib,io,json,os,pathlib,re,stat,sys,tarfile,tempfile,zipfile,shutil

HEX64=re.compile(r'[0-9a-f]{64}\Z')
EXPECTED_VOLUME_SHA='3cfa06d68223d45fef179b9e037eff2e5f49c4229d22b869a2aecbffac3148c9'
EXPECTED_VOLUME_BYTES=258168292
EXPECTED_INPUTS={
    'ccg':('5ce850a78f49665919ccdcb0fe759827c039e49632695f35b4a47d59c6c915b9',12898,'ccg-108f4304f9b2f187173a44749b56b3eb64dd4590','upstream'),
    'remccg':('6c57247dde51b1ea24fc5433f57b11cbb6e8cd6bb065515496a98a9c28a824ca',137841,'RemCCG-e181f6525ef83ff332130deacf5e8df062c44ee3',''),
}

def sha_file(path):
    with open(path,'rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def sha_bytes(data):return hashlib.sha256(data).hexdigest()

def strict_json(data):
    def pairs(rows):
        out={}
        for key,value in rows:
            if key in out:raise ValueError('Duplicate JSON field: '+key)
            out[key]=value
        return out
    return json.loads(data,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))

def valid_relative(s):
    if not isinstance(s,str) or not s or '\\' in s or any(ord(c)<32 for c in s):raise ValueError('Noncanonical material path')
    p=pathlib.PurePosixPath(s)
    if p.is_absolute() or p.as_posix()!=s or any(x in ('.','..','') for x in p.parts):raise ValueError('Material path is absolute or escaping: '+s)
    return p

def hashes_equal(record,content):
    if type(record.get('bytes')) is not int or record['bytes'] != len(content) or record.get('sha256')!=sha_bytes(content):
        raise ValueError('Exact saved bytes/SHA mismatch for '+str(record.get('path')))

def prepare_files(bundle,prior_volume,stage):
    with zipfile.ZipFile(bundle) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or 'manifest.json' not in names:
            raise ValueError('Duplicate ZIP name or manifest missing')
        manifest=strict_json(z.read('manifest.json'))
        if manifest.get('format')!='cpg-ccg-remccg-new-only-layer-v1' or manifest.get('formal_baseline')!='0.21.13':
            raise ValueError('Not the exact reviewed new-only CPG bundle format')
        declared=manifest.get('new_entries')
        inherited=manifest.get('inherited_entries')
        if not isinstance(declared,list) or not isinstance(inherited,list) or len(declared)<10 or len(inherited)!=54:
            raise ValueError('Incomplete declared exact new and inherited entries')
        object_set={('objects/'+row.get('sha256','')) for row in declared}
        if len(object_set)!=len(declared) or set(names)!={'manifest.json'}|object_set:
            raise ValueError('The bundle must contain only manifest and exact unique new SHA objects')
        for info in z.infolist():
            if info.is_dir() or info.file_size>3_000_000 or info.file_size<0:
                raise ValueError('Unsupported object payload shape')
        original_map={}
        for row in [*declared,*inherited]:
            path=valid_relative(row.get('path'))
            if str(path) in original_map:raise ValueError('Duplicate restored file path')
            if not HEX64.fullmatch(row.get('sha256','')) or type(row.get('bytes')) is not int:
                raise ValueError('Malformed exact hash or size')
            if type(row.get('mode')) is not int or row['mode'] not in (0o444,0o555,0o600,0o644,0o755):
                raise ValueError('Undeclared file mode')
            original_map[str(path)]=row
        for row in declared:
            p=str(valid_relative(row['path']))
            content=z.read('objects/'+row['sha256'])
            hashes_equal(row,content)
            target=stage/p
            target.parent.mkdir(parents=True,exist_ok=True)
            with target.open('xb') as stream:stream.write(content)
            target.chmod(row['mode'])
    if prior_volume.stat().st_size!=EXPECTED_VOLUME_BYTES or sha_file(prior_volume)!=EXPECTED_VOLUME_SHA:
        raise ValueError('Original historical ready payload volume SHA/size differs from immutable baseline')
    with zipfile.ZipFile(prior_volume) as v:
        if len(v.namelist())!=len(set(v.namelist())):raise ValueError('Duplicate historical ZIP entry')
        for name,(sha,bytes_n,prefix,subpath) in EXPECTED_INPUTS.items():
            content=v.read('objects/'+sha)
            if len(content)!=bytes_n or sha_bytes(content)!=sha:raise ValueError('Original upstream object checksum mismatch: '+name)
            with tarfile.open(fileobj=io.BytesIO(content),mode='r:gz') as tf:
                all_file_paths=set();file_ct=0
                for entry in tf.getmembers():
                    path=valid_relative(entry.name)
                    if path.parts[0]!=prefix:raise ValueError('Unexpected original source root: '+entry.name)
                    if not (entry.isfile() or entry.isdir()):
                        raise ValueError('Original full source contains unhandled symlink or device: '+entry.name)
                    if not entry.isfile():continue
                    relative=path.parts[1:]
                    if not relative:raise ValueError('Original source filename empty')
                    dest='/'.join([name]+([subpath] if subpath else [])+list(relative))
                    if dest in all_file_paths:raise ValueError('Original source has duplicate file names')
                    all_file_paths.add(dest)
                    record=original_map.get(dest)
                    if not record or record.get('source')!='inherited_exact_original':raise ValueError('Original source file missing from expected full original inventory: '+dest)
                    with tf.extractfile(entry) as f:body=f.read()
                    hashes_equal(record,body)
                    target=stage/dest
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with target.open('xb') as output:output.write(body)
                    target.chmod(record['mode'])
                    file_ct+=1
                expected_ct=19 if name=='ccg' else 35
                if file_ct!=expected_ct:
                    raise ValueError(f'Incomplete historical source inventory {name}: {file_ct} != {expected_ct}')
                if all_file_paths!={r['path'] for r in inherited if r.get('source_id')==name}:
                    raise ValueError('A full inherited source identity is missing or extra')
    current={p.relative_to(stage).as_posix() for p in stage.rglob('*') if p.is_file()}
    if current!=set(original_map):
        raise ValueError('Restored file inventory mismatches exact union of new and inherited files')
    for relative,row in original_map.items():
        target=stage/relative
        if not stat.S_ISREG(target.lstat().st_mode) or target.is_symlink():raise ValueError('Restored target is not a real regular file')
        if target.stat().st_size!=row['bytes'] or sha_file(target)!=row['sha256']:
            raise ValueError('Restored file content digest mismatch: '+relative)
        if stat.S_IMODE(target.stat().st_mode)!=row['mode']:
            raise ValueError('Restored logical mode mismatch: '+relative)
    return manifest

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--new-only-zip',required=True,type=pathlib.Path)
    parser.add_argument('--inherited-ready-volume',required=True,type=pathlib.Path)
    parser.add_argument('--output',required=True,type=pathlib.Path)
    parser.add_argument('--report',required=True,type=pathlib.Path)
    args=parser.parse_args(argv)
    bundle=args.new_only_zip.resolve(strict=True)
    inherited=args.inherited_ready_volume.resolve(strict=True)
    out=args.output.absolute()
    report=args.report.absolute()
    if out.exists() or out.is_symlink() or report.exists() or report.is_symlink():
        raise ValueError('Restore output and report must be absent new exact paths')
    if out==report or out in report.parents or report in out.parents:
        raise ValueError('Report and output cannot overlap')
    if out==bundle or out==inherited or out in bundle.parents or out in inherited.parents:
        raise ValueError('Output may not overlap material inputs')
    out.parent.mkdir(parents=True,exist_ok=True)
    report.parent.mkdir(parents=True,exist_ok=True)
    stage=pathlib.Path(tempfile.mkdtemp(prefix='.cpg-newonly-stage-',dir=out.parent))
    try:
        manifest=prepare_files(bundle,inherited,stage)
        if out.exists() or out.is_symlink():raise ValueError('Restore output appeared during validation')
        os.rename(stage,out)
    except BaseException:
        shutil.rmtree(stage,ignore_errors=True)
        raise
    outcome={'format':'cpg-ccg-remccg-new-only-actual-restore-v1','success':True,
      'formal_baseline':'0.21.13','formal_resource_denominator':1862,'formal_resource_managed':1700,
      'dataset_card_candidates':2,'formal_dataset_cards_already':88,'formally_promoted':False,
      'new_only_bundle_sha256':sha_file(bundle),'new_only_bundle_bytes':bundle.stat().st_size,
      'inherited_ready_volume_sha256':EXPECTED_VOLUME_SHA,'inherited_ready_volume_bytes':EXPECTED_VOLUME_BYTES,
      'restored_new_files':len(manifest['new_entries']),'restored_inherited_original_files':len(manifest['inherited_entries']),
      'original_source_objects_in_new_bundle':0,'offline':True,'network_used':False,
      'new_binary_host_only':True,'generated_programs_executed':False,'full_original_repo_files_present':True,
      'expected_dataset_fingerprints':manifest['expected_dataset_fingerprints'],
      'output_dir':str(out)}
    with report.open('x') as f:json.dump(outcome,f,sort_keys=True,indent=2);f.write('\n')
    print(json.dumps(outcome,sort_keys=True,ensure_ascii=False))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print(f'CCG/RemCCG restore rejected: {type(e).__name__}: {e}',file=sys.stderr)
        sys.exit(1)
