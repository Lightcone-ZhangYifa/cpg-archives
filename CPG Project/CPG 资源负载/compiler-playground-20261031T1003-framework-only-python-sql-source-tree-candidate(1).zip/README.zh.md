# CompilerPlayground — 2026-10-31 独立、未合并增量

这是一份只在本轮独立工作目录内形成、确切基于正式 **0.21.13** 的候选交接，**不宣称已合入主线、0.21.14/15/16 正式发布，亦不覆盖其他活跃开发者**。原 1,862 个资源 ID 不变，仍为 **1700/1862（91.30%）**；本分支没有增加主线资源准入。Dataset 正式仍为 **88/195**，107 张待完成卡。四张独立候选 Dataset（ccg、remccg、join-order-benchmark、deepfuzz）确实生成并通过安装后真实 Python Dataset 加载/恢复，合计 **161 个不重复主样本**，但正式待办仍包含这四张卡，必须经主线审查合入后才更新账目。

## 新增包与继承边界

- `ccg-remccg-new-only-sha-objects.zip`：新增 30 个 SHA 对象，原 CCG/RemCCG 完整来源共 54 个普通文件**仅引用**历史已保存的 v0.21.4 ready 资源卷，无重复打包原字节。CCG 在此 Debian 13 x86-64 host 实际从原固定源码独立两次编译，独立的预编译安装前缀 A/B 均做实际运行、内容与隔离验证。RemCCG 原生完整生成器因精确宿主依赖和旧 API 缺口未取得完整执行资格；其 18 个本来真实存在的源单元是源码 Dataset，不是生成器成功运行。CCG 定种生成 24 个 C 源程序，仅编译语法验证；不执行程序，不承诺性能或 Ubuntu 目标。
- `job-deepfuzz-new-only-sha-objects.zip`：仅 4 个新增 CPG Dataset 元数据 SHA 对象；**113** 条原 JOB SQL 查询与 **6** 条原 DeepFuzz Python 源单元的实际 file/data context 由历史 124 个不可变普通文件恢复。JOB 原 IMDB 数据库和官方查询性能协议尚未加载；DeepFuzz 原训练数据、权重与生成模型未运行。全 178 个原来源普通文件都不在新包中重复打包。
- `framework-only-python-sql-source-tree-candidate.zip`：**单独的零资源负载框架补丁**，严格仅增加 `from_source_tree` 对 `.sql`、`.py` 后缀的语言识别，带原文件 SHA 锚定、可审阅 patch、测试。保留原 v0.21.13 核心其他源文件，不声称合入。
- `independent-restore-toolkit.zip`：四卡一键离线候选恢复入口及严格原 SHA 锁恢复、真实安装后验证程序；需要用户以前正式拥有的两个历史 ready 卷，不能以本轮新 ZIP 伪装“历史原料也已重发”。
- `independent-validation-evidence.zip`：真实 CMake 失败、两套原生构建、原语料、Dataset 负例、发布前回归、只用新增卷与旧卷原 SHA 的 A/B 实测恢复、未发布候选规则和原卡待办等全部事实证据。

## 原固定两卷（本轮只引用，不重发）

```
v0.21.4 原 ready 卷 compiler-playground-v0.21.4-objects-001.zip
SHA256 3cfa06d68223d45fef179b9e037eff2e5f49c4229d22b869a2aecbffac3148c9
Library libfile_20afc30d50908191b47f998ed2d2ce5c

v0.21.3 原 ready 卷 compiler-playground-v0.21.3-objects-003.zip
SHA256 c8bebf47cfaa51756a60f84a350df319384178244c7bc30bdea54e50a629ff1b
Library libfile_933ad889f51081919ab40eb29a6a10e4
```

先验证交付 SHA/大小/mode。解压 toolkit（为代码，**不自动部署**）后，对已安装 v0.21.13 包的 Python 运行：

```bash
python3 restore_four_independent_datasets_from_newsha.py \
  --ccg-remccg-new-zip /saved/ccg-remccg-new-only-sha-objects.zip \
  --job-deepfuzz-new-zip /saved/job-deepfuzz-new-only-sha-objects.zip \
  --inherited-v0214-objects-001 /saved/compiler-playground-v0.21.4-objects-001.zip \
  --inherited-v0213-objects-003 /saved/compiler-playground-v0.21.3-objects-003.zip \
  --python-with-installed-cpg02113 /path/to/venv/bin/python \
  --output /brand/new/directory/does-not-exist
```

不匹配的原 SHA、压缩包成员、额外对象、权限、路径穿越、重复目标或源码被篡改应直接失败，不“修复”用户原材料。恢复把原源码材料和真正新增的 CPG 元数据合成两个独立新目录，最后实际调用原正式 wheel 的四张 Dataset 消费者（含抽样/检查点恢复）；不会下载/训练/运行原 JOB/DeepFuzz 上游程序。程序所在 Python 实际验证为 Debian 13 amd64，**不把宿主验证写成 Ubuntu 24.04 OCI/硬件验证**。

## 本轮完整验证证据与失败记录

已执行原 v0.21.13 wheel 的10组正式 Dataset 测试，**144 passed、4 skipped**（还有60个子测试）；独立框架最小候选叠加后，**147 passed、4 skipped**。只用新增对象+继承旧卷两套全新 sibling 恢复、两组安装后四卡真实应用、19类负例均完成。另实际进行 heaptrack、AutoFDO、STP 三个精确原来源的 CMake native preflight，未越过真实缺依赖的失败。保留首次运行缺少官方 repo fixture 的失败日志以及补齐 fixture 后成功的完整记录；不篡改失败历史。

`complete-pending` 把 162 个原资源 ID 和107张 Dataset 卡原始来源、状态、失败证据保持在分母，主线后续分工应优先审核四张候选卡并处理剩余真正源码、OCI / Benchmark / 硬件结论。正式发布前须由主线出版所有新增卷并回读验 SHA，另做其环境的真实集成回归。
