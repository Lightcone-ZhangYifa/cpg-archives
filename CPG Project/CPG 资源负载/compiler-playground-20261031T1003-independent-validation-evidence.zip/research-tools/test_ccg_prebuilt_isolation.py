#!/usr/bin/env python3
"""Install an actual source-built CCG ELF into two clean, source-free prefixes and test isolation."""
from pathlib import Path
import hashlib,json,shutil,subprocess,os,time
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'dataset-lane/ccg'
source=BASE/'prefix-B/bin/ccg'
assert source.is_file()

def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def run(a):
 p=subprocess.run(list(map(str,a)),capture_output=True,timeout=20);return {'argv':list(map(str,a)),'status':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stdout_bytes':len(p.stdout),'stderr_excerpt':p.stderr.decode(errors='replace')[-300:]}
expected=sha(source)
checks=[]
for prefix in ('prefix-C-only-prebuilt','prefix-D-only-prebuilt'):
 path=BASE/prefix/'bin';path.mkdir(parents=True,exist_ok=False);dst=path/'ccg';shutil.copy2(source,dst);dst.chmod(0o755)
 assert sha(dst)==expected
 tests=[run([dst,'--version']),run([dst,'--seed','1000','--max-functions','3','--max-localvars','3','--max-function-parameters','3','--min-statements-per-block','1','--max-statements-per-block','3','--max-expression-nesting','3','--max-block-nesting','3','--max-pointer-depth','2','--no-omitted-operand-conditional'])]
 assert all(x['status']==0 for x in tests)
 checks.append({'prefix':str(path.parent),'executable':str(dst),'sha256':sha(dst),'mode':oct(dst.stat().st_mode&0o777),'check_results':tests,'source_build_tree_inside_prefix':False})
assert checks[0]['check_results']==[dict(t,argv=checks[0]['check_results'][i]['argv']) for i,t in enumerate(checks[0]['check_results'])] # check local
assert [x['stdout_sha256'] for x in checks[0]['check_results']]==[x['stdout_sha256'] for x in checks[1]['check_results']]
# Retire only newly created C prefix and test unaffected D prefix.
c=BASE/'prefix-C-only-prebuilt';d=BASE/'prefix-D-only-prebuilt'
assert c.resolve().parent==d.resolve().parent==BASE.resolve()
shutil.rmtree(c)
assert not c.exists() and d.exists()
third=run([d/'bin/ccg','--version']);assert third['status']==0 and third['stdout_sha256']==checks[0]['check_results'][0]['stdout_sha256']
ldd=run(['ldd',d/'bin/ccg'])
report={'format':'cpg-ccg-independent-prebuilt-isolation-v1','host':'Debian 13 Linux x86_64 (actual host)','new_prebuilt_sha256':expected,
'prebuilt_bytes':source.stat().st_size,'matched_source_compiled_binary':True,'two_independent_clean_prefixes_tested':True,
'prefixes':checks,'new_local_prefix_C_deleted_after_consumers':str(c),'cleaned_files':['bin/ccg'],
'remaining_prebuilt_D_still_functional_after_C_deletion':True,'remaining_prefix_sha256':sha(d/'bin/ccg'),
'ldd_status':ldd['status'],'ldd_stdout_sha256':ldd['stdout_sha256'],
'original_source_tar_not_copied_into_prebuilt_prefixes':True,'Ubuntu_24_04_binary_runtime_verified':False,
'OCI_qualified':False,'hardware_qualified':False,'new_resource_ID_qualification':0}
(BASE/'prebuilt-isolation-and-cleanup.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('new_prebuilt_sha256','prebuilt_bytes','two_independent_clean_prefixes_tested','remaining_prebuilt_D_still_functional_after_C_deletion')},indent=2))
