# CompilerPlayground 独立 Python 包消费验证候选 · 2026-10-28

这是**候选开发证据包，不是 Canonical 0.21.x 正式增量版本**。截至本轮已验证的最新不可变正式交付身份，仍为 `compiler-playground-v0.21.4-final-delivery.json`，SHA-256 `ae05c647aee40a672cb01b64e1e10c46a8de2b586ab7e0a0feb1d966caf210bd`。其他会话的 `r07` 正占用主体更新与发布所有权；本轮只在隔离目录进行原 ID 的机器实测与证据采集，不触碰它的目录或主状态。

## 本轮增加的实测材料

原始资源 ID 共七个：`py.isoduration`、`py.narwhals`、`py.pip`、`py.polars-runtime-32`、`py.soupsieve`、`py.urllib3`、`py.wheel`。均使用 v0.21.4 继承的、原源 URL 与 SHA-256 确切绑定的原始 wheel 对象，不使用 PyPI 当期版本、HEAD 或在线临时下载。每一个 ID 都在两个**不同安装前缀**离线安装并真实运行业务功能（含至少一种失败路径），删除 A 前缀后又确认 B 字节指纹不变，B 继续功能通过。`py.polars-runtime-32` 包含本机实际加载并执行的 x86_64 预编译 ABI3 扩展；**不是从源码构建**。`py.narwhals` 经由 Polars 实际执行 DataFrame 聚合，`py.urllib3` 连接本机真实 loopback HTTP 服务，`py.wheel` 真正生成 wheel，`py.pip` 真正执行离线安装/卸载，`py.soupsieve` 真正处理 CSS 选择器，`py.isoduration` 真正计算含月/年的日历时间差。

所有结果仅限当前执行环境 **Debian 13 / Python 3.13.5 / x86_64**。原始 Ubuntu 24.04 目标还未复测，无 OCI、远端硬件、官方 Benchmark、源码编译或新数据集接口资格。这七个候选并**不增加**原先已发布的覆盖计数。冻结基线严格保持 **1,493 / 1,862（80.182599%）**，仍待完成 **369** 个原始 ID。APT 1,247 个资源均为继承的受信薄 wrapper，未重新安装和验证。本轮 7 个候选均属于 369 个待办，不重复计数。

## 公开增量回放

增量 ZIP 只含这次新增的 Python 验证器、回执、覆盖表、完整原始待办队列和成员 SHA/大小/mode 清单；**不再重打包** v0.21.4 的完整主体或之前已存储的 wheel 原件。要运行复核，请先用原版交付文件中记录的精确 Library 身份恢复 v0.21.4 `resource-inputs/index.json` 以及原始 `resource-raw-inputs-{001,003,004,005,006,008}.zip`。在新 ZIP 解压得到的根下将这些原材料分别放在 `recovery/indexfiles/resource-inputs/index.json` 与 `input/`，然后运行：

```bash
python work/extract_locked_wheels.py
python work/run_disjoint_wheel_qa.py
python work/build_disjoint_reports.py
```

回放脚本仅在新目录内创建自己的 venv、测试 HTTP 服务与证据。它会校验**整个原始卷 SHA-256**、每个 wheel 对象 SHA-256/大小，然后检查 Python 包的模块加载真实来自安装前缀。`work/run_disjoint_wheel_qa.py` 拒绝覆盖同目录中已存在的 QA 前缀；重新复核须使用一个新解压目录。

`deliverables/coverage.json` 提供原始 provider、原始 kind、类别、上游来源 host/URL 等完整计数，`deliverables/full-pending-queue.json` 保存 369 个原始待办与历史证据，不删除失败项。任何尚未通过 Ubuntu 24.04 目标机器、严格源构建、预编译隔离或官方协议的工作不得因这个候选包直接宣称接入完成。
