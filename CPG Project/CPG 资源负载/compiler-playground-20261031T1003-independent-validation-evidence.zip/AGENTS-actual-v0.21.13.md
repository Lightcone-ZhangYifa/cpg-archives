# compiler-playground 工作规约（v0.21.13）

## 当前开发方向

本版以从完整分卷逐文件验证恢复的 v0.19.0 工作区为基线，推进统一资源包、查询、报告、下载/安装验证与硬件资源接入。后续只强化现有主线子系统的功能、资源整合下载与多容器部署、Dataset、官方 Benchmark，以及对应资源的验证接入。保留原有实验和训练器组织，每种实验范式使用相应训练器。SourceGrad v1/v2 两轮设计均已撤销，不得作为实现依据；不引入其训练循环拆分、操作键、Journal 或源码数据流重构方案。用户最新指令优先于历史设计文档。

本工程以 Python 库为主体。`Dataset`、独立官方 `Benchmark`、编译器源码 `CompilerModel`、`Environment`、optimizer、Trainer 和 evaluator 是可组合的对象。旧 playground 是一种可选环境配置。旧工作规约保存在 `AGENTS-v0.13.0.md` 供历史研究重放；其中模式决定镜像、语料可见性、自动删除参考材料的规定已被本版取代，不是当前工程约束。

## 对象与开发者控制权

- 先安装 Python 库。包自带可重复运行的交互式环境创建工具：`cpg environment create` / `cpg-environment create`。不存在整个工程必须先完成的一次性部署步骤；每个环境都有独立目录、内容配置和镜像身份。
- Python 选择 agent 容器镜像和环境。`Environment.from_image` 显式解析镜像身份，`Environment.create` 根据资源选择创建环境，`Environment.load` 重新载入定义，`fork` 为同一镜像建立独立实验工作目录。训练范式不推断镜像或内容。
- `model.to(env)` 复制完整受控 Git 与源码状态；`batch.to(env)` / `loader.to(env)` 将声明的文件闭包及 agent 可读 manifest 复制到环境。主机原对象、评价路径与内部副本分开，修改一个副本不得修改其他环境或主机源码。
- 只共享下载缓存。固定原始 payload 以 SHA-256 寻址和逐摘要进程锁去重；每次使用重新核验。不同环境独立复制、解包、安装、构建，不使用跨环境安装前缀、硬链接或自动回写。不要为了缩小镜像删除源码、数据、构建依赖或参考材料。
- 外部数据集具有 Python 统一接口；环境中的同名资源可以是独立的原始源码、测试、输入、参考答案、patch 与工具材料。两者不要求相互挂载，也不要求 agent 使用主机 Dataset 接口。环境创建器必须允许选择全部资源；未知内容身份、缺介质、许可证和平台要求应明确报告，不能被描述为数据泄漏禁令。
- 数据集来源众生平等。benchmark 的数据视图可作为普通程序参与训练、比例混合、打乱和随机划分；独立 Benchmark 对象则保持官方计时、验证与聚合协议。不要从套件名、参考答案或 train/test 标签推断可用性。
- 新实验默认 `data_policy="record"`：记录重叠事实，由开发者决定实验。显式 `"strict"` 保留可选隔离检查。旧 checkpoint 缺策略字段时按原 strict 合同恢复，不悄悄放宽历史实验。正确性、材料身份和实际执行完整性仍需校验。
- `Mode.SIMPLE` 和 `Mode.DATA_DRIVEN` 表示训练循环。三个旧模式标签仅为记录与旧入口兼容，不得控制 Environment 的内容权限。

## 测量、生命周期与恢复

- 目标是在声明的 CPU、语言、浮点、ABI 与输入分布上优化编译器。正确性、可复现构建和部署兼容性是明确合同；未知 token、成本、CPU、能耗、空间不得写成零。
- 正式测量仅在迭代边界同步执行；开发容器和训练 target 必须完成清理确认后才开始测量。保留原有可信构建、SSH 预构建产物协议、oracle 检查、性能计时、target 隔离与恢复能力。是否提供资源由开发者决定，与生命周期清理不是一件事。
- agent 环境可以联网；没有项目额外域名白名单或出站封锁。身份凭据只按变量名传递，不进入 argv、配置或公开日志。正式 controller 结果不能由 agent 文本伪造。
- 模型 checkpoint 保存 Git commit/ref 和研究状态。未测 checkpoint 不宣称通过；后测保留原创建成本、审计成本与测量时间，不倒填未来成绩、不把测试挑选伪装成在线最优。
- 运行时清理失败必须如实阻断正式测量；不得通过吞异常或模拟结果达到通过。保留失败、取消、pending、恢复与观察者投递证据。
- 核心执行后端当前为 Linux amd64；内置资源配方为 Ubuntu 24.04。自选已有镜像无强制资源闭包；对其再安装完整资源配方时须验证实际平台。非支持平台必须扩展相应适配，不根据镜像名字猜测。

## 保留的资源与研究能力

- 统一资源目录原有 1,860 项完整保留，新增后为 1,862 项；195 张 Dataset 卡、76 张编译器源码 Model 卡、18 张 Benchmark 协议卡全部保留。发现卡、已锁材料、已安装资源、smoke、真实 OCI 与工业资格分别记录。
- Dataset 的本地 SQLite、JSONL/Parquet/HF、原生套件 provider、生成器、混合/采样/变换/划分/恢复、MixtureEvaluator 路由不得回退。`load` 与 DataLoader 不隐式下载、编译或运行；`acquire_source` 是显式取得且使用公共下载缓存。
- `from_pretrained(name, version=...)` 显式准备整个编译器源码；自定义路径、普通 Git/子模块/worktree 导入、SHA-256 Git、独立导出和 provenance 均保留。Model 卡不代表该编译器已经构建或通过当前目标资格。
- 原生 QBE/cproc/libdivide、LLVM/GCC upstream workflow、split dev/target、profiling、训练 target gateway、日志看板和完整历史工作区继续可用。详细路径、版本与资格见对应版本资源文档，不能将旧路径当作新机器有效路径。
- `native-compiler-lab` 是真实历史研究案例；它的公开14内核与历史测量不得改写成新环境或未见数据上的效果。保留原始 Git、补丁、测量和失败日志。
- Benchmark 内置协议与自定义逐样本 evaluator 分开；官方有效分数必须保持官方 timer、检查、默认参数与汇总方式，不能用自定义均值冒充官方协议。

## 工程与交付

- Python、CLI、配置和示例使用英文，研究手册可用中文。默认入口和文档应体现库优先，不再引导用户先部署 playground。包内工具支持离开源码 checkout 使用；兼容旧命令不能成为新流程的前置要求。
- 每个实质性改动用有价值的回归验证；与真实 Docker、物理 PMU、SSH 或付费 agent 相关的未执行步骤明确标出，不以 mock 验证冒充实测。
- 完整工作区交付保留全部有用材料、历史 Git、证据与重放工具；wheel/source ZIP 只是子集。逐文件清单、资源 ID 对照、Git 与归档恢复分别校验。
- 本地研究和可逆修复可直接进行。向外部发送消息、PR、邮件、评论、实际支付或发布须遵从用户明确授权，不自动做上游贡献。

## v0.16.0 资源包维护

- 资源定义的活动权威为 `resources/packages/<id>/package.json` 与相邻 `recipe/`；`metadata.catalog` 完整保留原目录事实，flat resource catalog 和安装版 package index 是生成视图。不要用重新迁移覆盖独立细化的 dependency phase、checks 或 usage。
- Agent 从 `cpg packages list/search/info/paths/check` 获取环境信息。粗细粒度查询、英文部署报告、可选静态导出和短英文 Codex skill 使用同一份定义及实际收据；不维护第二份手写资源位置文档。
- APT/pip 等用无负载 wrapper 统一定义安装/卸载 hooks 和用法；底层管理器保留依赖解析和真实包数据库。wrapper 的小归档校验不代表其底层包字节已校验，必须分别记录。
- `source/binary/material/wrapper` 是显式制品安装方式。二进制默认固定prefix；可移动profile必须实际验证并记录具体范围。精确依赖锁包括artifact SHA；源码依赖不能由同名其他制品冒充。
- 只共享已锁下载字节，每个环境独立copy/unpack/build/install。保留源码、数据、原始输入、参考答案与许可证；不引入跨环境安装tree复用或以缩小镜像为目标的清理。
- `assets/package-selection.json` 冻结选中定义、完整recipe文件及执行helper。普通Python缓存不属于配方身份。新检查必须以真实运行和正确上下文为依据；版本检查、功能检查、硬件检查分别报告。
- APT/pip manager查询失败不能说成未安装；部分hook失败必须保留证据和当前观察，不伪造自动回滚。材料可查询、可投放，不以是否有可执行文件决定资源平等性。
- 完整LLVM/GCC旧构建能力仍保留。将其逐包转换为维护者预构建资源源时，必须保留原功能、source closure、target exports与实际验证，不因定义已迁移就宣称全量资源已完成真实部署。

## v0.17.0 可靠性合同

- 独立安装prefix只能有一个所有者，不能嵌套；`.cpg-prefix.json`是本地安装状态，不得进入资源制品。
- 同一实际APT/pip/Conda环境使用同一package state；不同state并不隔离底层数据库。
- 配方必须等待子进程完成，不启动脱离控制的后台daemon；活跃hook保有state锁。
- binary的所有run资源依赖必须有精确制品锁；system依赖仍使用固定底层manager身份。
- 依赖准入与完整文件校验分别进行；修改大型安装树后由开发者显式调用verify-installed及check。
- 原始失败、部分副作用、旧版资格和本版实测要分开记录。成熟包管理器审查及边界见docs/package-manager-review-v0.17.0.md。

## v0.18.0 既有资源接入

- 本轮不增加资源 ID；目录总数保持 1,862。按既有资源推进完整性、安装、真实功能与可重放打包，不以目录数量代替质量。
- 维护者批量工具仅调用逐资源配方和统一包管理器；活动定义仍为 resources/packages。候选与历史证据不是第二份活动目录。
- 原始 Python environment 分组与 extras 不合并；APT 合装模拟、实际隔离 Python 安装和各工具功能分别报告。
- 上游下载移址只能使用经确认的相同 SHA-256/字节数位置；保留原 URL、版本及 metadata.catalog，实际获取来源写入收据。
- 本地容量受限时可在记录完整清单与哈希后清除可重建部署副本；用户批量预构建默认保留产物，原始日志、失败和配方不得丢失。

## v0.19.0 验证与来源保留

- 不新增资源 ID；针对既有资源补齐实际安装、API/CLI、负例、独立副本和原始材料保留证据。
- 上游测试必须核对实际执行清单与输出；空清单、仅枚举测试、被 Makefile 忽略的失败均不能算通过。
- 构建副本补丁必须作为明确配方输入携带，绑定原始与结果摘要；原始源码材料保持不变。
- Python 功能资格使用每项资源自己的固定依赖闭包、选定解释器和实际模块位置，分别验证两份环境及卸载隔离。
- 精确运行时系统包不匹配时保留阻断。直接工具链探测可以单列，不能替代包管理器的部署资格。

## v0.20.0 并行接入与交付

- 1,862 个既有资源 ID、全部 metadata.catalog、原始 source locks 与 71 个历史 Git 仓库保持不变；原 v0.19.0 活动文档与被更新文件的原始字节另存。
- 当前维护者入口为 resource-integrations/v0200/maintainer/prebuild_resources.py；沿用已验证的 v0.18 批量引擎，清单仅包括逐项通过的配置。--all 表示该清单，不能表述为全目录部署。
- 输入完整性、原有五个环境中的安装、逐资源功能资格、OCI 和物理 PMU 各自列证据。依赖安装不会自动增加功能覆盖；失败尝试和未测试范围明确保留。
- Picire 的固定私有闭包属于配方输入，不新增资源 ID，不修改原始 catalog/sources；源码发行包含这些开放 wheel，含原生扩展的输入不能描述为纯源码。
- GoogleTest、libxml2 等上游测试在独立构建副本执行；原始源码材料不接受测试缓存或日志污染。配置选择及被禁用的可选后端写入资格范围。
- 维护者驱动和配方可迁移，历史日志中的原执行绝对路径保持真实；当前调用方通过 workspace、definitions、cache 和 output 指定新位置。
- 对可重建部署副本的清理先保留完整文件身份和原因。完整分卷交付复核所有选中文件、目录、链接与 Git，并在归档验证后再次核对源树，拒绝同步期间的身份变化。

## v0.21.0 分离交付与增量资源

- 工作区主体与资源负载分开交付；基线不在每轮重复打包，后续仅交付元数据差分和新增或改变的内容对象。完整累计清单保留为本地检查点。
- 资源对象及大对象块按 SHA-256 去重；相同字节的多个恢复路径仍得到独立普通文件，保留全部原目录模式与安全链接。
- 本地资源清理需要准确绑定清单、内容摘要和实际保存成功的回执；归档位置与功能资格状态分别记录，已清理不等于失去资格。
- 本轮仅增强原有资源：40 个 Python 资源的离线安装、实际功能、负例、可逆修改与卸载隔离均有原始证据。未声明的消费依赖（soupsieve/bs4）明确阻断，不用合装成功替代独立闭包资格。
- 维护者入口为 resource-integrations/v0210/maintainer/prebuild_resources.py。`--all` 当前表示 246 项已审配置，其中 145 项为直接功能资格、101 项为静态材料资格；不表示全目录部署。

## v0.21.1 本轮版本与交付要求

- 主、次版本保持 `0.21`；本轮补丁号更新为 `0.21.1`，以后每轮会话继续递增补丁号。已有 0.21.0 实测记录保留原版本、时间和摘要。
- 继续使用既有逐资源配方、包管理器和 v0.18 批量引擎，不创建第二套安装器。当前清单入口仍为 `resource-integrations/v0210/maintainer/prebuild_resources.py`。
- 直接功能、完整静态材料、Dataset 接口、输入完整性、OCI 与物理测量分别记账。数据卡的新增接口字段不改写原历史资格或来源；旧 Embench 资源不能替代当前卡的精确提交。
- 原 `metadata.catalog.kind`、原 URL 来源和当前 provider 分别统计；材料获得 source profile 时不改写原目录事实。
- 更新 wheel 后使用新的支持目录，保留旧支持状态。wheel 不携带资源负载；完整源码配方的补充输入从资源层恢复。
- 工具资源提供真实源码构建及预编译版本；官方 wheel/deb 的包装不冒称自行源码编译。脚本工具与机器码编译分别标记。静态资源提供在线下载配方和离线材料；过大静态资源可暂只提供在线版本，局部下载不计完整离线资格。
- 失败源码包仅在实际证明可逐字节重建后省略重复本体，保留旧配方、manifest、provenance、失败日志及证明。成功资源对象在保存回执确认后再记录清理。
- 根据用户本轮要求，仅此次重新汇总全部已完成资源制品及固定输入，覆盖之前本轮不得重交旧负载的限制；主体和资源仍分开。之后恢复增量；框架运行时代码变化时再次交付主体。
- 本轮完整依据见 `workspace-evidence/completion-v0210-r02/`；原失败和恢复链分别保留，刷新已有资格不重复增加覆盖数。

## v0.21.2 / r03 已完成交付状态

- 本轮补丁版本为 `0.21.2`，主次版本保持 `0.21`；之后每轮继续递增补丁号。资源实测版本仍记录为实际 `0.21.1`，不回写旧证据。
- 本次按最新用户要求一次性汇总全部已完成负载并移除旧 APT 制品；主体与负载分开，后续恢复增量交付。
- 全部 1247 个 APT 资源采用受信的单 manifest 薄 wrapper；不运行逐包安装/功能验证，不将受信资格冒充执行资格。非 APT 所需的私有 DEB 依赖按证据保留。
- 原 canonical `sources` 与 `metadata.catalog` 的一致性约束保持不变。固定提交原料的空 SHA/bytes 通过配方 acquisition lock 与输入审计解析，不回填原发现记录。
- 当前证据入口为 `workspace-evidence/completion-v0210-r03/`；资料恢复、输入完整性、材料、原生执行、Dataset 接口和安装包对象分别计数。

## v0.21.3 / r04 增量与续跑

- 本轮补丁号为 `0.21.3`，后续实际开发轮次继续递增，主次版本保持 `0.21`。
- 恢复增量交付，旧成功负载不重复打包；主体仅在代码/配置有变化时更新，资源负载独立。
- 受信 APT 1247 项继承原资格；源码生成的解释型工具与机器码编译分别统计，原始输入与私有预编译运行时分别留证。
- Dataset 原料、程序主样本、完整上下文、变体族和真实可执行资格分开。`compile_only` 接口不授予正确性 oracle 或官方 benchmark 分数。
- 原始归档集合容器、已展开源码树、占位文档材料与局部在线验证必须明确区分，不能把上游缺失链接修造成通过。
- 用户要求每 2 小时自动续跑，每轮尽量推进接近两小时；先读取最新持久检查点并确认没有活跃轮次。固定目录接入达到 100% 后停用周期任务，不缩小分母、不隐藏阻断。实际调度身份见最终交付记录。

## v0.21.4 / r05 增量交付

- 补丁号为 0.21.4；原目录、来源、历史证据与已完成负载身份保持继承。
- 本轮没有修改包引擎或 Dataset 算法；资源定义、发布工具与支持内容分别通过实际验证。
- 静态工具源码的材料可用性不等于该工具已编译运行；精确执行范围与未完成外部数据必须单列。
- 按用户最新要求，禁止主动查看或改动定时任务状态；继续项目并行开发与增量交付，不以发布校验为由访问或修改任务。

## 0.21.7 / recovery-20261028 最新约束

- 正式基线为 0.21.4；恢复的 0.21.5/0.21.6 只是未正式交付的候选。当前交付版本为 0.21.7，继续使用 0.21 系列并按实际交付递增补丁号。
- 不以发行版名称或版本相等作为安装门槛；检查实际 OS/架构、工具链、ELF/runtime 和确切依赖。不伪造 os-release，不用 LD_* 掩盖缺库。
- 不读取或修改 automation/定时任务状态。优先低成本来源和静态材料；大编译需要具体任务收益。继续多智能体并行，每轮报告分母不变、按原始 ID 去重的覆盖率。
- 当前 1496/1862 管理覆盖（含1247可信APT wrapper），非APT为249/615。功能151、材料104、交集6，不能直接相加。三项新增材料使待覆盖从369降到366；六项native只升级已有材料ID的功能资格。
- Dataset为32/195。本轮七接口仅有compile_only数据与独立生命周期证据；不等同数值oracle、官方Benchmark、OCI或物理硬件资格。
- 保留原始source锁、metadata.catalog、完整源码/数据/生成器/历史/失败证据。resolved_sources只补未知hash/bytes，不替换既有身份。baseline-v0.21.4/保存更新定义的完整旧字节。
- 同步维护当前定义、生成catalog和wheel的_support。共享仅限已验证下载字节，构建/安装/环境为独立副本。
- 新交付仅包含变化核心与新ready资源对象，旧104卷按原身份继承。全部历史归档可用，但历史重复payload逻辑路径按需展开；不得声称每个历史副本已物理展开。
- 本轮完整结果与后续队列位于 workspace-evidence/completion-v0210/recovery-20261028；恢复步骤与增量身份以0.21.7交付记录为准。继续保留单一Experiment/Trainer与原主架构，SourceGrad v1/v2保持撤回。

## 0.21.8 / continuation-20261029 当前交付约束

- 本轮正式基线为 0.21.7；资料中同名 0.21.8 支线文件是候选，只有最终增量索引确认的内容构成本次交付。保持 0.21 系列，按实际交付递增补丁号。
- 继续多智能体并行；不读取或修改定时任务。保持原 Experiment/Trainer 主架构与 SourceGrad v1/v2 撤回决定。
- 当前管理覆盖 1541/1862，非 APT 294/615；功能 198、材料 107、交集 11、仅材料 96。原 ID 去重后本轮新增管理 45、功能 47、材料 3。继承 APT 1247 仅为受信 wrapper。
- Dataset 为 35/195，共 231 主样本。EPCC OpenMP、Phoenix、miniGhost 三项是完整来源闭包与 compile_only 接口资格；不扩大到数值 oracle、官方 Benchmark、OCI 或物理硬件。
- 原 id/version/source/target/dependency/catalog 事实不改写。发行版名称不作为门槛；实际依赖不满足仍阻断。DejaGNU/rr 候选清空依赖的做法未准入，LLVM/GCC/lzbench 大构建未运行。
- 旧配方的 11 个 active 文件及 11 个 support 镜像文件迁至各自 baseline-v0.21.7 原样副本。迁移只能在完整身份前置检查后执行；本地修改不覆盖。wheel 支持目录须新建。
- Python pluggy 首次卸载观察异常、mbuild 首次探针协议错误、材料首轮 mode 比较失败、Quicksilver 旧目标失败及后续状态观察均保存；最终通过范围只依据对应冻结收据，不追改历史失败。
- 当前维护者入口仍为 resource-integrations/v0210/maintainer/prebuild_resources.py，沿用原 v0.18 引擎。--all 为 294 个已审非 APT ID，不能称为全目录真实部署。
- 交付仅增加变化核心与 63 个本轮 ready 对象；旧 40 个 ready 负载卷身份继承。完整历史 workspace 清单继承，不将局部恢复说成所有历史 payload 均已展开。
- 当前完整证据与后续队列见 workspace-evidence/completion-v0210/continuation-20261029；最终交付状态与可恢复文件以版本化增量索引为准。

## 0.21.9 / continuation-20261029-v0219 当前交付约束

- 正式基线为 0.21.8；本轮以实际保存成功的 0.21.9 增量和最终交付记录为准。继续 0.21 系列、多智能体并行和原始 ID 去重统计；不读取或修改定时任务。
- Python 库优先；保留原 Experiment/Trainer 主架构、Dataset 与官方 Benchmark 的独立接口及 SourceGrad v1/v2 撤回决定。
- 当前管理覆盖 1574/1862，非 APT 327/615；功能 228、材料 110、交集 11、仅材料 99。Python 功能 175/285。继承 APT 1247 为受信 wrapper。
- Dataset 为 38/195，共 236 个主样本；新增 ligra, quicksilver, snap 均限定于完整原始来源和 compile_only 接口资格。
- 核心只准入全新并列目录恢复，保留原工作区。0.21.8 原地迁移及路径再现问题仍为 blocked，原因未定。本轮无历史路径删除；旧迁移工具仅保留诊断用途。
- 继续保留原 source/target/dependency/catalog 事实；真实依赖未满足仍阻断。不使用发行版名/版本相等作为门槛，不伪造 os-release 或 LD_*。
- 新增源码材料是 Intel PCM 的固定 GoogleTest、Intel PMT、simdjson 配套原料；材料资格不等于 PCM 或组件编译、PMU、OCI 或官方分数。
- 来源归档中的相邻目录链接只在原归档受限根内解析；复制后是普通独立文件。越界、循环、缺失和错误类型必须拒绝。全部原链接和来源证据保留。
- 当前统一维护者入口为 resource-integrations/v0210/maintainer/prebuild_resources.py；--all 为 327 个已审非 APT ID，沿用原 v0.18 批量引擎。
- 本轮证据位于 workspace-evidence/completion-v0210/continuation-20261029-v0219。只运输新增或变化核心、新 ready 对象与证据；完整历史清单继承，历史重复部署路径按需恢复。

## 0.21.10 / continuation-20261029-v02110 当前交付约束

- 正式基线 0.21.9；本轮实际保存成功的增量与外部交付记录是交付依据，不读取或修改定时任务。
- 固定 1862 个原始资源 ID、195 Dataset、76 Model、18 Benchmark；Python 库优先、原 Experiment/Trainer、SourceGrad v1/v2 撤回决定均保留。
- 管理覆盖 1636/1862，非 APT 389/615，功能 290、材料 112、交集 13、仅材料 99；Python 234/285。
- Dataset 46/195，主样本 605。原始生成器真实生成不等于生成程序执行；全部新增接口限定 compile_only。
- 保留 id/version/sources/target/dependencies/provider/catalog 原始事实；未填原 SHA/bytes 只能用明确补充锁，不能改写原 canonical 字段。真实依赖、许可或字节冲突继续阻断。
- 依赖仅辅助安装的 frozen wrapper 不授予资格；本轮 Python 使用 dependency-index-v02110.json，以兼容历史同 key 不同 provenance 字节。不要改旧 index 的身份。
- 源码与安装副本普通且独立，只有已验证原下载字节可共享。记录完整源码/二进制实际制品身份；历史文件保留重封装不是新的源码构建。
- 新目录恢复准入；原地迁移 blocked，旧路径再现原因未定。不能凭即时删除成功宣称再现问题已修复。
- 递归 APT 观察当前发现135个继承非APT profile有依赖阻断，不自动删除旧资格，也不得把继承资格说成当前宿主已运行。
- 维护者仍使用 resource-integrations/v0210/maintainer/prebuild_resources.py 和原 v0.18 批量引擎；--all 为 389 个已审非APT ID，非全目录。
- 原始失败、原始许可证、Gitlink固定版本与全部历史交付保留。LLVM/GCC/lzbench昂贵构建继续延期，APT不新增实际安装验证。

## 0.21.11 / continuation-20261030-v02111 当前交付约束

- 正式基线为 0.21.10；以本轮实际保存并读回验证的增量和最终交付记录为依据。保持 0.21 系列，下一实际交付递增补丁号。
- 固定 1862 个原始资源 ID、195 Dataset、76 Model、18 Benchmark；Python 库优先、原 Experiment/Trainer 与 SourceGrad v1/v2 撤回决定不变。
- 管理覆盖 1672/1862，非 APT 425/615；功能 327、材料 112、交集 14、仅材料 98；Python 269/285。
- Dataset 55/195，主样本 1608。接口/完整来源/compile_only 与真实编译运行、语义 oracle、官方分数、OCI 和物理硬件资格分别记账。
- id/version/sources/target/dependencies/provider/catalog 原始事实保持。补充构建工具、Gitlink、未知原 SHA/bytes 的实证锁分开记录，不改 canonical 发现事实，不新增资源 ID。
- 原批量引擎和 PackageManager/Repository 保持；当前 --all 为 425 个已审非 APT ID，不能表述为全目录执行。
- 新 Python 依赖索引为 dependency-index-v02111.json，旧索引身份保留。仅支持安装的对象不给功能、材料或管理覆盖。
- 仅共享已核原下载字节；源码、构建、安装和 Environment 副本均为独立普通文件。不使用发行版名称/版本相等门槛、伪造 os-release 或未声明 LD_*。
- 新宿主只读观察有 135 个继承 profile 存在精确系统依赖的结构性不匹配路径；实际准入按方法判断，历史资格保留。APT 不新增安装资格。
- 核心仅新并列目录恢复；原地迁移仍 blocked，文件回退/额外路径观察保留原始失败且不臆定原因。历史来源、许可证、Git、失败和所有已交付卷身份保持。
- 继续多智能体并行与固定分母逐轮覆盖报告，不读取或修改定时任务。昂贵 LLVM/GCC/lzbench 构建保持延期，除非有具体有界收益。

## 0.21.12 / continuation-20261030-v02112 当前交付约束

- 正式基线为 0.21.11；以本轮实际保存并读回验证的增量和最终交付记录为依据。保持 0.21 系列，下一实际交付递增补丁号。
- 固定 1862 个原始资源 ID、195 Dataset、76 Model、18 Benchmark；Python 库优先、原 Experiment/Trainer 与 SourceGrad v1/v2 撤回决定不变。
- 管理覆盖 1687/1862，非 APT 440/615；功能 335、材料 119、交集 14、仅材料 105；Python 277/285。
- Dataset 76/195，主样本 1924。接口/完整来源/compile_only 与真实编译运行、语义 oracle、官方分数、OCI 和物理硬件资格分别记账。
- id/version/sources/target/dependencies/provider/catalog 原始事实保持。补充构建工具、Gitlink、未知原 SHA/bytes 的实证锁分开记录，不改 canonical 发现事实，不新增资源 ID。
- 原批量引擎和 PackageManager/Repository 保持；当前 --all 为 440 个已审非 APT ID，不能表述为全目录执行。
- 新 Python 依赖索引为 dependency-index-v02112.json，旧索引身份保留。仅支持安装的对象不给功能、材料或管理覆盖。
- 仅共享已核原下载字节；源码、构建、安装和 Environment 副本均为独立普通文件。不使用发行版名称/版本相等门槛、伪造 os-release 或未声明 LD_*。
- 新宿主只读观察有 135 个继承 profile 存在精确系统依赖的结构性不匹配路径；实际准入按方法判断，历史资格保留。APT 不新增安装资格。
- 核心仅新并列目录恢复；原地迁移仍 blocked，文件回退/额外路径观察保留原始失败且不臆定原因。历史来源、许可证、Git、失败和所有已交付卷身份保持。
- 继续多智能体并行与固定分母逐轮覆盖报告，不读取或修改定时任务。昂贵 LLVM/GCC/lzbench 构建保持延期，除非有具体有界收益。

## 0.21.13 / continuation-20261031-v02113 当前交付约束

- 正式基线为 0.21.12；以本轮实际保存并读回验证的增量和最终交付记录为依据。保持 0.21 系列，下一实际交付递增补丁号。
- 固定 1862 个原始资源 ID、195 Dataset、76 Model、18 Benchmark；Python 库优先、原 Experiment/Trainer 与 SourceGrad v1/v2 撤回决定不变。
- 管理覆盖 1700/1862，非 APT 453/615；功能 343、材料 124、交集 14、仅材料 110；Python 285/285。
- Dataset 88/195，主样本 2238。接口/完整来源/compile_only 与真实编译运行、语义 oracle、官方分数、OCI 和物理硬件资格分别记账。
- id/version/sources/target/dependencies/provider/catalog 原始事实保持。补充构建工具、Gitlink、未知原 SHA/bytes 的实证锁分开记录，不改 canonical 发现事实，不新增资源 ID。
- 原批量引擎和 PackageManager/Repository 保持；当前 --all 为 453 个已审非 APT ID，不能表述为全目录执行。
- 新 Python 依赖目录为 dependency-index-v02113.json；每个目标使用该目录绑定的 dependency-index-v02113.<target>.json，旧索引身份保留。仅支持安装的对象不给功能、材料或管理覆盖。
- 仅共享已核原下载字节；源码、构建、安装和 Environment 副本均为独立普通文件。不使用发行版名称/版本相等门槛、伪造 os-release 或未声明 LD_*。
- 继承 0.21.12 宿主只读观察有 135 个 profile 存在精确系统依赖的结构性不匹配路径；实际准入按方法判断，历史资格保留。APT 不新增安装资格。
- 核心仅新并列目录恢复；原地迁移仍 blocked，文件回退/额外路径观察保留原始失败且不臆定原因。历史来源、许可证、Git、失败和所有已交付卷身份保持。
- 继续多智能体并行与固定分母逐轮覆盖报告，不读取或修改定时任务。昂贵 LLVM/GCC/lzbench 构建保持延期，除非有具体有界收益。
