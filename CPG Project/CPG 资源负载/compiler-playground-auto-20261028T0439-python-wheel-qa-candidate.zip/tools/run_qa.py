"""Isolated, offline, exact-hash Python wheel integration qualification candidates.
No canonical CPG paths are modified, only this branch's owned directory.
"""
from __future__ import annotations
import copy, concurrent.futures, hashlib, json, os, pathlib, shutil, subprocess, sys, time, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
wheels=json.loads((ROOT/'evidence/wheels.json').read_text())
original_ids=json.loads((ROOT/'evidence/original-resource-ledger.json').read_text())
defs_by_id={x['resource_id']:x for x in original_ids}
PATCH_VERSION='host-interpreter-qa-candidate-r10'

def cmd(argv,timeout=120,env=None):
    t=time.monotonic()
    run_env=os.environ.copy();run_env.update({'PIP_NO_INDEX':'1','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_INPUT':'1','PYTHONNOUSERSITE':'1'})
    if env:run_env.update(env)
    try:
        p=subprocess.run(argv,env=run_env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,text=True)
        return {'argv':[str(s) for s in argv],'returncode':p.returncode,'stdout':p.stdout[-12000:],'stderr':p.stderr[-12000:],'elapsed_s':round(time.monotonic()-t,3)}
    except subprocess.TimeoutExpired as e:
        return {'argv':[str(s) for s in argv],'returncode':None,'timeout':True,'stdout':str(e.stdout)[-2000:],'stderr':str(e.stderr)[-2000:],'elapsed_s':round(time.monotonic()-t,3)}

def one(artifact):
    name=artifact['artifact']; sha=artifact['sha256']; fn=artifact['basename']; dest=ROOT/'run'/name/('attempt-'+os.environ.get('CPG_QA_ATTEMPT','1'))
    dest.mkdir(parents=True,exist_ok=True)
    receipt={'artifact':name,'original_source_sha256':sha,'original_archive':artifact['source_volume'],'resource_ids':artifact['resource_ids'],'physical_wheel_bytes':artifact['bytes'],'original_target':'Ubuntu 24.04 x86_64','runtime_target':'Debian 13 x86_64 Python 3.13.5 (host-only)','statuses':{},'events':[]}
    wheelpath=ROOT/'wheelhouse'/fn
    assert hashlib.sha256(wheelpath.read_bytes()).hexdigest()==sha
    if not fn.endswith('none-any.whl'):
        receipt['statuses']['host_platform']='skipped_incompatible_wheel_tag'
        receipt['reason']='Original wheel target has CPython 3.12 ABI tag and host CPython 3.13; cannot substitute a different wheel or pretend target qualification.'
        return receipt
    ledger=defs_by_id[artifact['resource_ids'][0]]
    orig=json.loads((ROOT/'definitions'/ledger['resource_id']/'package.original.json').read_text())
    package_name=orig['recipe']['package_name']
    expected_version=orig['metadata']['catalog']['version']
    check_script=ROOT/'scripts/check.py'
    # Per-artifact and per-prefix dedicated virtual environments. No cross-wheel extras.
    for side in ['source_install','independent_install']:
        prefix=dest/side
        rec=cmd([sys.executable,'-m','venv',str(prefix)],timeout=90)
        receipt['events'].append({'stage':'create_venv','prefix':side,**rec})
        if rec['returncode']!=0:return receipt
        py=prefix/'bin/python'
        dependency_filenames={'anyio':['sniffio-1.3.1-py3-none-any.whl','idna-3.20-py3-none-any.whl','typing_extensions-4.16.0-py3-none-any.whl'], 'typing_inspection':['typing_extensions-4.16.0-py3-none-any.whl'], 'rfc3987_syntax':['lark-1.3.1-py3-none-any.whl']}.get(name,[])
        receipt['dependency_wheels']=dependency_filenames
        for dep in dependency_filenames:
            assert (ROOT/'wheelhouse'/dep).is_file(), dep
            rec=cmd([str(py),'-m','pip','install','--no-index','--no-deps',str(ROOT/'wheelhouse'/dep)],timeout=120)
            receipt['events'].append({'stage':'install_exact_dependency_closure','prefix':side,'dependency':dep,**rec})
            if rec['returncode']!=0:return receipt
        rec=cmd([str(py),'-m','pip','install','--no-index','--no-deps',str(wheelpath)],timeout=120)
        receipt['events'].append({'stage':'install_exact_offline','prefix':side,**rec})
        if rec['returncode']!=0:return receipt
        rec=cmd([str(py),'-m','pip','check'],timeout=45)
        receipt['events'].append({'stage':'dependency_check','prefix':side,**rec})
        if rec['returncode']!=0:return receipt
        rec=cmd([str(py),'-I',str(check_script),'--artifact',name,'--package-name',package_name,'--expected-version',expected_version,'--version-only'],timeout=40)
        receipt['events'].append({'stage':'version','prefix':side,**rec})
        if rec['returncode']!=0:return receipt
        rec=cmd([str(py),'-I',str(check_script),'--artifact',name,'--package-name',package_name,'--expected-version',expected_version],timeout=70)
        receipt['events'].append({'stage':'functional','prefix':side,**rec})
        if rec['returncode']!=0:return receipt
        line=rec['stdout'].strip().splitlines()[-1]
        data=json.loads(line)
        if data.get('status')!='passed' or data['sys_prefix'] != str(prefix):
            receipt['error']='incorrect or non-isolated functional receipt';return receipt
        receipt['statuses'][side]=data
    # Remove candidate wheel source, immediately retest installed executable behavior.
    # Use file rename only within this isolated branch's owned worktree.
    quarantine=dest/'source_quarantined.whl'
    shutil.copy2(wheelpath,quarantine)
    try:
        # The actual source wheel remains in branch wheelhouse for other workers, so place
        # the executing prefix inside a private container with no wheelhouse on sys.path.
        for side in ['source_install','independent_install']:
            py=dest/side/'bin/python'
            rec=cmd([str(py),'-I',str(check_script),'--artifact',name,'--package-name',package_name,'--expected-version',expected_version],timeout=70,env={'PYTHONPATH':'/not/a/wheelhouse'})
            receipt['events'].append({'stage':'installed_without_wheel_path','prefix':side,**rec})
            if rec['returncode']!=0:return receipt
        # Uninstall only first prefix, ensure second prefix stays independent.
        pa=dest/'source_install'/'bin/python';pb=dest/'independent_install'/'bin/python'
        rec=cmd([str(pa),'-m','pip','uninstall','-y',package_name],timeout=70)
        receipt['events'].append({'stage':'uninstall_first_prefix','prefix':'source_install',**rec})
        if rec['returncode']!=0:return receipt
        # Module import name differs from PyPI name on a few artifacts; use exact artifact import.
        module={'uri_template':'uri_template','typing_extensions':'typing_extensions','threadpoolctl':'threadpoolctl','tzdata':'tzdata','packaging':'packaging'}.get(name,name)
        rec=cmd([str(pa),'-I','-c',f'import importlib.util;assert importlib.util.find_spec({module!r}) is None'],timeout=30)
        receipt['events'].append({'stage':'uninstall_absence','prefix':'source_install',**rec})
        if rec['returncode']!=0:return receipt
        rec=cmd([str(pb),'-I',str(check_script),'--artifact',name,'--package-name',package_name,'--expected-version',expected_version],timeout=70)
        receipt['events'].append({'stage':'second_prefix_unchanged_after_first_uninstall','prefix':'independent_install',**rec})
        if rec['returncode']!=0:return receipt
        receipt['statuses']['two_prefix_isolation']='passed'
        rec=cmd([str(pa),'-m','pip','install','--no-index','--no-deps',str(wheelpath)],timeout=90)
        receipt['events'].append({'stage':'offline_reinstall','prefix':'source_install',**rec})
        if rec['returncode']!=0:return receipt
        rec=cmd([str(pa),'-I',str(check_script),'--artifact',name,'--package-name',package_name,'--expected-version',expected_version],timeout=70)
        receipt['events'].append({'stage':'reinstall_functional','prefix':'source_install',**rec})
        if rec['returncode']!=0:return receipt
        receipt['statuses']['reinstall']='passed'
        receipt['statuses']['complete_functional_host']= bool(receipt['statuses']['source_install'].get('complete_functional',True) and receipt['statuses']['independent_install'].get('complete_functional',True))
    finally:
        quarantine.unlink(missing_ok=True)
    return receipt

def overlay(artifact, receipt):
    if not receipt['statuses'].get('complete_functional_host') or receipt['statuses'].get('two_prefix_isolation')!='passed':return []
    out=[]
    for rid in artifact['resource_ids']:
        src=ROOT/'definitions'/rid/'package.original.json'
        d=json.loads(src.read_text())
        assert d['id']==rid and d['sources'][0]['sha256']==artifact['sha256']
        script=(ROOT/'scripts/check.py').read_text()
        recipe_dir=ROOT/'overlay'/'resources'/'packages'/rid/'recipe'
        recipe_dir.mkdir(parents=True,exist_ok=True)
        # Stamped check.py contains exact artifact ID; runtime selection never depends on external fixture files.
        stamped=script.replace("parser.add_argument('--artifact',required=True)","parser.add_argument('--artifact',default="+repr(artifact['artifact'])+")")
        (recipe_dir/'check.py').write_text(stamped)
        d['checks'] += [
         {'id':'offline-wheel-version-and-isolation','kind':'version','argv':['{prefix}/bin/python','-I','{recipe}/check.py','--package-name',d['recipe']['package_name'],'--expected-version',d['metadata']['catalog']['version'],'--version-only'],'cwd':'{prefix}','timeout_seconds':30,'expected_returncode':0,'stdout_regex':'"status": "passed"','requires_commands':['{prefix}/bin/python']},
         {'id':'offline-wheel-application-functional','kind':'functional','argv':['{prefix}/bin/python','-I','{recipe}/check.py','--package-name',d['recipe']['package_name'],'--expected-version',d['metadata']['catalog']['version']],'cwd':'{prefix}','timeout_seconds':75,'expected_returncode':0,'stdout_regex':'"status": "passed"','requires_commands':['{prefix}/bin/python']},
        ]
        pkg_path=recipe_dir.parent/'package.json'
        pkg_path.write_text(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
        assert d['sources']==json.loads(src.read_text())['sources']
        assert d['metadata']['catalog']==json.loads(src.read_text())['metadata']['catalog']
        out.append({'id':rid,'source_sha256':d['sources'][0]['sha256'],'original_package_sha256':defs_by_id[rid]['original_definition_sha256'], 'original_export_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'overlay_package_sha256':hashlib.sha256(pkg_path.read_bytes()).hexdigest(),'new_check_sha256':hashlib.sha256((recipe_dir/'check.py').read_bytes()).hexdigest(),'host_evidence_status':'two_prefix_real_functional_uninstall_reinstall','catalog_identity_preserved':True,'target':'ubuntu-24.04-x86_64-still-unqualified'})
    return out

only=set(x for x in os.environ.get('CPG_QA_ONLY','').split(',') if x)
selected=[a for a in wheels if not only or a['artifact'] in only]
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
    new_receipts=list(pool.map(one,selected))
result_by_artifact={r['artifact']:r for r in new_receipts}
for a in wheels:
    if a['artifact'] not in result_by_artifact:
        result_by_artifact[a['artifact']]=json.loads((ROOT/'evidence'/('host-'+a['artifact']+'.json')).read_text())
results=[result_by_artifact[a['artifact']] for a in wheels]
for r in results:
    p=ROOT/'evidence'/('host-'+r['artifact']+'.json')
    if r['artifact'] in {a['artifact'] for a in selected}:
        if p.exists(): (ROOT/'evidence'/('host-'+r['artifact']+'-previous.json')).write_bytes(p.read_bytes())
        p.write_text(json.dumps(r,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(r['artifact'],'FULL_PASS' if r['statuses'].get('complete_functional_host') else 'INCOMPLETE',r['statuses'].get('two_prefix_isolation'), 'error=',r.get('error') or r.get('reason'))
new=[]
for artifact,result in zip(wheels,results):new+=overlay(artifact,result)
(ROOT/'evidence'/'candidate-ids.json').write_text(json.dumps({'host_qa_completed_ids':new,'candidate_resource_count':len(new),'original_resource_total':1862,'canonical_coverage_delta':0,'only_candidate':True},ensure_ascii=False,sort_keys=True,indent=2)+'\n')
print('TOTAL verified host candidate IDs',len(new),'unique wheel blobs',len({x['source_sha256'] for x in new}))
