"""Per-resource offline functional probes; called through package manager's check.argv.

The first positional artifact argument is stamped into each package's own recipe/check.py.
Nothing here downloads resources, reads another installed prefix or mocks a backend.
"""
from __future__ import annotations
import argparse, importlib, importlib.metadata, json, ssl, sys
from pathlib import Path


def verify(artifact: str) -> dict:
    if artifact == 'attrs':
        import attrs
        @attrs.define(frozen=True)
        class Task:
            cost: int = attrs.field(validator=attrs.validators.instance_of(int))
            name: str = attrs.field(validator=attrs.validators.instance_of(str))
        t = Task(4, 'compile')
        assert attrs.asdict(t) == {'cost': 4, 'name': 'compile'}
        try: Task('invalid', 'compile')
        except TypeError: pass
        else: raise AssertionError('attrs validator unexpectedly accepted invalid data')
        try: t.cost = 5
        except attrs.exceptions.FrozenInstanceError: pass
        else: raise AssertionError('frozen attrs instance mutated')
        return {'workflow': 'validated frozen model serialization and invalid input rejection'}
    if artifact == 'idna':
        import idna
        fqdn = 'bücher.example'
        ascii_name = idna.encode(fqdn).decode('ascii')
        assert ascii_name == 'xn--bcher-kva.example'
        assert idna.decode(ascii_name) == fqdn
        try: idna.encode('bad..example')
        except idna.IDNAError: pass
        else: raise AssertionError('IDNA accepted invalid label separator')
        return {'workflow': 'IDNA encode/decode of Unicode hostname; malformed label rejection'}
    if artifact == 'h11':
        import h11
        client = h11.Connection(h11.CLIENT)
        payload = client.send(h11.Request(method='GET', target='/status', headers=[('host','example.test')]))
        payload += client.send(h11.EndOfMessage())
        server = h11.Connection(h11.SERVER)
        server.receive_data(payload)
        request = server.next_event()
        assert isinstance(request, h11.Request) and request.method == b'GET' and request.target == b'/status'
        assert isinstance(server.next_event(), h11.EndOfMessage)
        response = server.send(h11.Response(status_code=200, headers=[('content-length','2')]))
        response += server.send(h11.Data(data=b'OK'))
        response += server.send(h11.EndOfMessage())
        client.receive_data(response)
        assert isinstance(client.next_event(), h11.Response)
        assert client.next_event().data == b'OK'
        assert isinstance(client.next_event(), h11.EndOfMessage)
        bad = h11.Connection(h11.SERVER)
        bad.receive_data(b'GET / HTTP/1.1\r\nHost invalid\r\n\r\n')
        try: bad.next_event()
        except h11.RemoteProtocolError: pass
        else: raise AssertionError('malformed protocol accepted')
        return {'workflow': 'in-memory two-sided HTTP/1.1 request+response protocol with malformed-message rejection'}
    if artifact == 'six':
        import six
        class Meta(type):
            def __new__(mcs, name, bases, namespace):
                namespace['from_metaclass'] = True
                return super().__new__(mcs,name,bases,namespace)
        class Config(six.with_metaclass(Meta,object)): pass
        assert Config.from_metaclass
        assert six.ensure_binary('café') == 'café'.encode('utf8')
        assert six.ensure_text('café'.encode()) == 'café'
        try: six.ensure_binary(42)
        except TypeError: pass
        else: raise AssertionError('non-string not rejected by ensure_binary')
        return {'workflow': 'cross-version metaclass construction + Unicode/bytes conversion and invalid type rejection'}
    if artifact == 'typing_extensions':
        import typing_extensions as te
        Config = te.TypedDict('Config', {'path': te.Required[str], 'retries': te.NotRequired[int]})
        assert Config.__required_keys__ == frozenset({'path'})
        assert Config.__optional_keys__ == frozenset({'retries'})
        P = te.ParamSpec('P')
        assert P.args is not None and P.kwargs is not None
        return {'workflow': 'TypedDict required/optional runtime introspection + ParamSpec semantics'}
    if artifact == 'certifi':
        import certifi
        ca = Path(certifi.where())
        assert ca.is_file() and ca.stat().st_size > 10000
        context = ssl.create_default_context(cafile=str(ca))
        certs = context.get_ca_certs()
        assert len(certs) >= 20, len(certs)
        try: ssl.create_default_context(cafile='/definitely/not/a/real/cert.pem')
        except OSError: pass
        else: raise AssertionError('nonexistent bundle accepted')
        return {'workflow': 'actual SSLContext loads real wheel CA bundle and rejects nonexistent bundle','ca_count':len(certs)}
    if artifact == 'iniconfig':
        import iniconfig
        config = iniconfig.IniConfig('inmemory.ini', data='[build]\noptimize = 3\narch = x86_64\n[verify]\nmode = strict\n')
        assert config['build']['optimize'] == '3' and config['verify']['mode'] == 'strict'
        try: iniconfig.IniConfig('inmemory.ini', data='invalid-without-header=value')
        except iniconfig.ParseError: pass
        else: raise AssertionError('invalid INI section accepted')
        return {'workflow': 'parse multiple real INI sections and reject invalid syntax'}
    if artifact == 'pluggy':
        import pluggy
        hookspec = pluggy.HookspecMarker('cpgqa')
        hookimpl = pluggy.HookimplMarker('cpgqa')
        class Specs:
            @hookspec(firstresult=True)
            def select(self, key): pass
        class First:
            @hookimpl(tryfirst=True)
            def select(self, key): return 'fast:'+key
        class Last:
            @hookimpl
            def select(self, key): return 'slow:'+key
        pm = pluggy.PluginManager('cpgqa')
        pm.add_hookspecs(Specs)
        pm.register(Last())
        pm.register(First())
        assert pm.hook.select(key='kernel') == 'fast:kernel'
        assert len(pm.get_plugins()) == 2
        class Wrong:
            @hookimpl
            def nonexistent(self): pass
        pm.register(Wrong())
        try: pm.check_pending()
        except pluggy.PluginValidationError: pass
        else: raise AssertionError('unknown hookspec not rejected')
        return {'workflow': 'real ordered plug dispatch and unknown hookspec validation'}
    if artifact == 'threadpoolctl':
        import ctypes, ctypes.util, threadpoolctl
        gomp_path = ctypes.util.find_library('gomp')
        assert gomp_path, 'A native OpenMP runtime is needed to qualify actual thread control'
        gomp = ctypes.CDLL(gomp_path)
        gomp.omp_get_max_threads.restype = ctypes.c_int
        before = gomp.omp_get_max_threads()
        assert before >= 1
        detected = threadpoolctl.threadpool_info()
        assert any(d['user_api']=='openmp' for d in detected), detected
        with threadpoolctl.threadpool_limits(limits=1, user_api='openmp') as ctl:
            assert ctl is not None
            assert gomp.omp_get_max_threads() == 1
            limited=threadpoolctl.threadpool_info()
            assert all(x['num_threads']==1 for x in limited if x['user_api']=='openmp')
        restored = gomp.omp_get_max_threads()
        assert restored == before, (restored, before)
        return {'workflow': 'actual loaded native libgomp OpenMP runtime; set 1 thread, inspect live count, restore original count','detected_libraries':len(detected),'limits_enforced_on_live_library':True,'openmp_threads_before':before,'openmp_threads_restored':restored}
    if artifact == 'uri_template':
        import uri_template
        template = uri_template.URITemplate('https://example.test/items{/path*}{?page,filter}')
        expanded = template.expand(path=['a','b c'],page=2,filter='active')
        assert expanded.startswith('https://example.test/items/a/b%20c?'), expanded
        assert 'page=2' in expanded and 'filter=active' in expanded
        assert uri_template.expand('https://example.test/{key}',key='hello world') == 'https://example.test/hello%20world'
        return {'workflow': 'RFC6570 URI path expansion, percent escaping and query substitution','expanded':expanded}
    if artifact == 'tzdata':
        import zoneinfo, datetime, tzdata
        # Clear host TZPATH to force the installed tzdata Python distribution.
        original = zoneinfo.TZPATH
        try:
            zoneinfo.reset_tzpath([])
            zoneinfo.ZoneInfo.clear_cache()
            eastern = zoneinfo.ZoneInfo('America/New_York')
            jan = datetime.datetime(2026,1,1,12,tzinfo=eastern)
            july = datetime.datetime(2026,7,1,12,tzinfo=eastern)
            assert jan.utcoffset().total_seconds() == -18000
            assert july.utcoffset().total_seconds() == -14400
            try: zoneinfo.ZoneInfo('Mars/Phobos')
            except zoneinfo.ZoneInfoNotFoundError: pass
            else: raise AssertionError('unknown IANA timezone accepted')
        finally:
            zoneinfo.reset_tzpath(original)
            zoneinfo.ZoneInfo.clear_cache()
        return {'workflow': 'force installed tzdata package fallback; verify IANA DST and unknown zone rejection'}
    if artifact == 'packaging':
        from packaging.version import Version, InvalidVersion
        from packaging.requirements import Requirement
        from packaging.specifiers import SpecifierSet
        assert Version('1.2.0rc1') < Version('1.2.0')
        assert Version('1.2.0') in SpecifierSet('>=1.0,<2.0')
        assert Version('2.0.0') not in SpecifierSet('>=1.0,<2.0')
        requirement = Requirement('compiler-playground[qa]>=0.21; python_version >= "3.9"')
        assert requirement.name == 'compiler-playground' and requirement.marker.evaluate({'python_version':'3.13'})
        try: Version('not-a-version')
        except InvalidVersion: pass
        else: raise AssertionError('invalid PEP440 version accepted')
        return {'workflow': 'PEP440 version/specifier, requirement marker, invalid version rejection'}
    if artifact == 'narwhals':
        import narwhals as nw
        import narwhals.selectors as ns
        # A backend-free expression cannot establish DataFrame execution qualification.
        assert callable(nw.from_native)
        assert callable(ns.numeric)
        # Verify rejecting unsupported native objects, but report incomplete without real backend.
        try: nw.from_native({'x':[1,2]})
        except (TypeError, ValueError): pass
        else: raise AssertionError('unsupported native object unexpectedly passed')
        return {'workflow': 'API/negative type smoke only; no pandas/polars/Arrow backend executed','complete_functional':False}
    if artifact == 'pycparser':
        from pycparser import CParser, c_ast
        from pycparser.c_parser import ParseError
        c = 'int scale(int *x, int n) { int acc = 0; for(int i=0; i<n; ++i) { acc += x[i] * 2; } return acc; }'
        ast = CParser().parse(c, filename='cpg_qa.c')
        functions = [node for node in ast.ext if isinstance(node, c_ast.FuncDef)]
        assert len(functions) == 1 and functions[0].decl.name == 'scale'
        assert any(isinstance(node, c_ast.For) for _,node in functions[0].body.children())
        try: CParser().parse('int bad( {', filename='bad.c')
        except ParseError: pass
        else: raise AssertionError('malformed C syntax accepted')
        return {'workflow':'actual C parser with pointers, For AST node and invalid syntax rejection'}
    if artifact == 'setuptools':
        import os,subprocess,tempfile, setuptools
        with tempfile.TemporaryDirectory(prefix='cpg-setuptools-') as tmp:
            root=Path(tmp)
            package=root/'src'/'cpg_qa_pkg';package.mkdir(parents=True)
            (package/'__init__.py').write_text('ANSWER = 42\n')
            (root/'setup.py').write_text("from setuptools import setup,find_packages\nsetup(name='cpg-qa-build',version='0.1.0',packages=find_packages(where='src'),package_dir={'':'src'})\n")
            proc=subprocess.run([sys.executable,'-I',str(root/'setup.py'),'build_py','--build-lib',str(root/'build')],cwd=root,capture_output=True,text=True,timeout=45)
            assert proc.returncode==0,(proc.stdout,proc.stderr)
            artifact_file=root/'build'/'cpg_qa_pkg'/'__init__.py'
            assert artifact_file.exists() and 'ANSWER = 42' in artifact_file.read_text()
            assert setuptools.find_packages(where=str(root/'src'))==['cpg_qa_pkg']
            assert setuptools.find_packages(where=str(root/'missing'))==[]
        return {'workflow':'real setuptools build_py of synthetic source distribution in temporary private directory; export verification'}
    if artifact == 'anyio':
        import anyio
        async def workflow():
            out=[]
            send,receive=anyio.create_memory_object_stream(1)
            async def producer():
                async with send:
                    for item in [3,5,8]:await send.send(item)
            async def consumer():
                async with receive:
                    async for item in receive:out.append(item)
            async with anyio.create_task_group() as tg:
                tg.start_soon(producer)
                tg.start_soon(consumer)
            return out
        assert anyio.run(workflow,backend='asyncio')==[3,5,8]
        try: anyio.create_memory_object_stream(-2)
        except (ValueError,TypeError): pass
        else: raise AssertionError('invalid memory object stream size accepted')
        return {'workflow':'actual asyncio scheduler/taskgroup, ordered producer-consumer memory stream; invalid buffer rejection'}
    if artifact == 'typing_inspection':
        import typing,typing_extensions as te
        from typing_inspection import typing_objects, introspection
        assert typing_objects.is_any(typing.Any)
        assert typing_objects.is_union(typing.Union)
        assert list(introspection.get_literal_values(typing.Literal[1,2,3])) == [1,2,3]
        assert list(introspection.get_literal_values(te.Literal['red','blue'])) == ['red','blue']
        return {'workflow':'actual annotation classification and literal value extraction with pinned typing-extensions runtime'}
    if artifact == 'rfc3987_syntax':
        import rfc3987_syntax
        import inspect
        assert hasattr(rfc3987_syntax,'parse'),dir(rfc3987_syntax)
        parsed=rfc3987_syntax.parse('iri','https://example.test/path?q=hello')
        assert parsed is not None
        assert rfc3987_syntax.is_valid_syntax_iri('https://example.test/path?q=hello')
        assert not rfc3987_syntax.is_valid_syntax_iri('https://bad host/path')
        return {'workflow':'RFC3987 IRI syntax parser actual invocation with pinned Lark backend','result_type':type(parsed).__name__}
    if artifact == 'charset_normalizer':
        import charset_normalizer
        sample = 'café — étude'.encode('utf-8')
        match = charset_normalizer.from_bytes(sample).best()
        assert match is not None and str(match) == 'café — étude'
        return {'workflow':'actual encoding detection; application-level UTF8 decode'}
    raise AssertionError(f'unknown artifact: {artifact}')


def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument('--artifact',default='typing_extensions')
    parser.add_argument('--package-name',required=True)
    parser.add_argument('--expected-version',required=True)
    parser.add_argument('--version-only',action='store_true')
    args=parser.parse_args()
    actual=importlib.metadata.version(args.package_name)
    assert actual==args.expected_version, (actual,args.expected_version)
    result={'status':'passed','artifact':args.artifact,'version':actual,'sys_prefix':sys.prefix,'sys_base_prefix':sys.base_prefix,'isolated':bool(sys.flags.isolated)}
    assert sys.prefix != sys.base_prefix and sys.flags.isolated
    if not args.version_only:result.update(verify(args.artifact))
    print(json.dumps(result,sort_keys=True))
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        import traceback
        traceback.print_exc()
        print(json.dumps({'status':'failed','exception_type':type(exc).__name__,'error':str(exc)}))
        raise
