#!/usr/bin/env python3
"""Independent original-catalog crosswalk for a non-promoted CCG/RemCCG candidate."""
from __future__ import annotations
import collections,hashlib,json,pathlib,zipfile,datetime,os
ROOT=pathlib.Path(__file__).resolve().parent;OUT=ROOT/'release';OUT.mkdir(exist_ok=True)
ZIP=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.13-cpg-continuation-20261030.zip')
FINAL=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.13-final-delivery-receipt.json')
FINAL_SHA=''; CAND=OUT/'compiler-playground-20261031T1003-independent-ccg-remccg-new-only-manifest.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(ZIP) as z:
 content_status=z.read('reports/resource-status.json');status=json.loads(content_status)
 content_coverage=z.read('reports/coverage.json');cov=json.loads(content_coverage)
 pending=json.loads(z.read('reports/pending-resources.json'))
 dataset_pending=json.loads(z.read('metadata/dataset-pending-queue-v02113-final.json'))
 ready=json.loads(z.read('resources/compiler-playground-v0.21.13-resources-manifest.json'))
 import io
 with zipfile.ZipFile(io.BytesIO(z.read('wheel/compiler_playground-0.21.13-py3-none-any.whl'))) as wheel:
  member='compiler_playground/_support/AGENTS.md'
  ab=wheel.read(member)
  main_agents=[{'path':'wheel/'+member,'sha256':sha(ab),'bytes':len(ab),'read_and_applied':True}]
footer=json.loads(FINAL.read_bytes());assert footer['formally_published'] and footer['version']=='0.21.13'
original=status['resources'];idlist=[r['id'] for r in original];idset=set(idlist)
assert len(idlist)==len(idset)==1862
fixed=cov['id_sets'];assert set(fixed['original_resource_ids'])==idset
managed=set(fixed['managed_ids']);apt=set(fixed['trusted_apt_ids']);functional=set(fixed['functional_ids']);material=set(fixed['material_ids']);overlap=set(fixed['functional_material_overlap_ids']);integrity=set(x['id'] for x in original if x['stages']['exact_input_integrity']['status']=='verified')
assert len(apt)==1247 and len(managed)==1700 and len(functional)==343 and len(material)==124 and len(overlap)==14 and len(integrity)==1721
assert managed==apt | functional | material
assert overlap==functional & material and not (apt & functional) and not (apt & material)
assert len(idset-managed)==162
pending_ids=set(pending['pending_resource_ids']);assert pending_ids==idset-managed
assert len(fixed['dataset_card_ids'])==195 and len(fixed['dataset_verified_ids'])==88
pending_dataset=set(pending['dataset_pending_card_ids']);all_dataset=set(fixed['dataset_card_ids']);verified_dataset=set(fixed['dataset_verified_ids']);assert len(pending_dataset)==107 and pending_dataset==(all_dataset-verified_dataset)
assert {'ccg','remccg','join-order-benchmark','deepfuzz'}<=pending_dataset
assert {'dataset-ref.ccg','dataset-ref.remccg','dataset-ref.join-order-benchmark','dataset-ref.deepfuzz'}<=material
assert set(fixed['static_only_ids'])==material-functional and len(fixed['static_only_ids'])==110
assert len(fixed['non_apt_managed_ids'])==453 and managed-apt==set(fixed['non_apt_managed_ids'])
assert status['resource_count']==len(idlist)
assert all(id in idset for id in pending_ids)
by_cat={};by_prov={};by_original_source={};by_kind={};by_category={};by_urlhost={}
def group_stats(key):
 return {'group':key,'total_original_ids':0,'managed_original_ids':0,'trusted_apt_wrapper_ids':0,'functional_ids':0,'material_ids':0,'static_only_ids':0,'integrity_verified_ids':0,'pending_original_ids':0}
def enrich(table,key,rid):
 d=table.setdefault(key,group_stats(key));d['total_original_ids']+=1
 d['managed_original_ids']+=rid in managed;d['trusted_apt_wrapper_ids']+=rid in apt
 d['functional_ids']+=rid in functional;d['material_ids']+=rid in material;d['static_only_ids']+=rid in material-functional
 d['integrity_verified_ids']+=rid in integrity;d['pending_original_ids']+=rid not in managed
for r in original:
 rid=r['id']
 enrich(by_prov,r['baseline_provider'],rid);enrich(by_cat,r['catalog_kind'],rid)
 enrich(by_original_source,r['source_origin'].get('group','unknown'),rid)
 enrich(by_category,r['resource_category_primary'],rid)
 urls=r['source_origin'].get('urls') or []
 # Attribute a resource only to one URL-host category to avoid multiplying the fixed denominator.
 host=((urls[0].split('/')[2]) if (urls and isinstance(urls[0],str) and urls[0].startswith(('https://','http://'))) else ('local-or-none'))
 enrich(by_urlhost,host,rid)
for grouping,table_name in [(by_prov,'by_baseline_provider'),(by_cat,'by_catalog_kind'),(by_category,'by_resource_category_primary'),(by_original_source,'by_source_origin')]:
 official={r['category']:r for r in cov['tables'][table_name]}
 assert set(grouping)==set(official),(table_name,set(grouping)^set(official))
 for key,v in grouping.items():
  o=official[key]
  assert (v['total_original_ids'],v['managed_original_ids'],v['pending_original_ids'],v['trusted_apt_wrapper_ids'],v['functional_ids'],v['material_ids'],v['static_only_ids'],v['integrity_verified_ids']) == (o['resources'],o['managed_resources_union'],o['pending_managed_resource_ids'],o['trusted_apt_wrappers'],o['functional_passed'],o['material_available_current'],o['static_material_only'],o['exact_input_verified']),(table_name,key)
assert ready['version']=='0.21.13'
manifest=json.loads(CAND.read_bytes());assert manifest['formal_baseline']=='0.21.13'
manifest_other=json.loads((OUT/'compiler-playground-20261031T1003-independent-job-deepfuzz-new-only-manifest.json').read_bytes());assert manifest_other['formal_baseline']=='0.21.13'
new=manifest['new_entries']+manifest_other['new_entries'];inherited=manifest['inherited_entries']+manifest_other['inherited_entries'];assert len(new)==34 and len(inherited)==178
all_newsha={x['sha256'] for x in new};all_oldsha={x['sha256'] for x in inherited};assert not all_newsha.intersection(all_oldsha)
for source_name,part in [('ccg-remccg',manifest),('job-deepfuzz',manifest_other)]:
 with zipfile.ZipFile(OUT/f'compiler-playground-20261031T1003-independent-{source_name}-new-only-sha-objects.zip') as bundle:
  assert len([x for x in bundle.namelist() if x.startswith('objects/')])==len(part['new_entries'])
  for entry in part['new_entries']:
   b=bundle.read('objects/'+entry['sha256']);assert len(b)==entry['bytes'] and sha(b)==entry['sha256']
verified_archive_new_objects=34
index_snapshot={'original_pending_resource_count':len(pending_ids),'original_pending_dataset_count':len(pending_dataset),
                'original_pending_resource_ids':sorted(pending_ids),'original_pending_dataset_card_ids':sorted(pending_dataset),
                'dataset_next_queue_full_cards':dataset_pending.get('cards',[]),
                'original_resource_pending_records':pending['resources'],
                'counts_do_not_include_independent_candidates':True,
                'independent_candidate_dataset_ids':['ccg','remccg','join-order-benchmark','deepfuzz'],
                'independent_candidate_ccg_generated_programs':24,'independent_candidate_remccg_original_source_units':18,
                'independent_candidate_join_order_SQL_query_units':113,
                'independent_candidate_deepfuzz_python_source_units':6}
(OUT/'compiler-playground-20261031T1003-independent-exact-pending-and-next-queue.json').write_text(json.dumps(index_snapshot,sort_keys=True,indent=2)+'\n')
report={'format':'compiler-playground-original-1862-independent-audit-v1','scope':'strict_crosswalk_against_formally_delivered_0.21.13; not_promotion_of_independent_candidates',
 'baseline_final_receipt':{'sha256':sha(FINAL.read_bytes()),'bytes':FINAL.stat().st_size,'formally_published':True,'version':'0.21.13'},
 'source_status':{'sha256':sha(content_status),'bytes':len(content_status),'original_resource_ids_unique':len(idset)},
 'source_coverage':{'sha256':sha(content_coverage),'bytes':len(content_coverage)},
 'raw_fixed_original_total':len(idset),'formal_managed_unique':len(managed),'formal_pending_unique':len(pending_ids),
 'formal_managed_percent':round(len(managed)/len(idset)*100,6),'trusted_apt_wrapper_unique':len(apt),
 'formal_non_apt_managed_unique':len(managed-apt),'formal_non_apt_total':len(idset-apt),
 'formal_functional_unique':len(functional),'formal_material_unique':len(material),'formal_overlap_unique':len(overlap),
 'formal_static_only_unique':len(material-functional),'exact_source_input_verified_unique':len(integrity),
 'formal_dataset_covered_cards':len(verified_dataset),'formal_dataset_total_cards':len(all_dataset),
 'formal_dataset_pending_cards':len(pending_dataset),'dataset_candidate_ids_pending':['ccg','remccg','join-order-benchmark','deepfuzz'],
 'candidate_dataset_samples_original_unique':161,'candidate_new_derived_SHA_objects':34,'inherited_exact_original_source_files_not_repacked':178,
 'native_compiled_on_current_Debian13_host_CCG_binary_only':True,
 'full_original_RemCCG_generator_qualified':False,'native_Ubuntu24_04_target_qualified':False,
 'official_benchmarks_performed':0,'OCI_deployments_performed':0,'physical_hardware_trials_performed':0,
 'updated_formal_resource_count_increment_this_branch':0,'formal_dataset_card_count_increment_this_branch':0,
 'grouped_counts':{
  'by_original_provider':sorted(by_prov.values(),key=lambda r:r['group']),
  'by_original_catalog_kind':sorted(by_cat.values(),key=lambda r:r['group']),
  'by_original_category':sorted(by_category.values(),key=lambda r:r['group']),
  'by_original_source_group':sorted(by_original_source.values(),key=lambda r:r['group']),
  'by_primary_original_URL_host':sorted(by_urlhost.values(),key=lambda r:r['group'])},
 'grouping_independent_sum_validation':True,'source_dataAGENTS':main_agents,
 'new_sha_validation':{'new_objects':verified_archive_new_objects,'new_objects_disjoint_from_inherited_source_files':True,'new_payload_is_not_a_repack_of_original_sources':True},
 'type_and_scope_disclaimer':'APT wrapper trust is NOT installed/runtime functionality. Source Git material and CCG host native build do not grant whole dataset completeness, Ubuntu machine-code, official benchmark, OCI, hardware, or other resource functional profiles.'}
for table in report['grouped_counts'].values():
 assert sum(x['total_original_ids'] for x in table)==1862
 assert sum(x['managed_original_ids'] for x in table)==1700
 assert sum(x['pending_original_ids'] for x in table)==162
(OUT/'compiler-playground-20261031T1003-independent-fixed-1862-coverage-audit.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['raw_fixed_original_total','formal_managed_unique','formal_pending_unique','formal_managed_percent','formal_dataset_covered_cards','candidate_new_derived_SHA_objects','updated_formal_resource_count_increment_this_branch']},indent=2))
