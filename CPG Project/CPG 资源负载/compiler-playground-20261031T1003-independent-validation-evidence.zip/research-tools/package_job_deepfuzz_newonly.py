#!/usr/bin/env python3
"""Two source-only Dataset cards; new metadata SHA only, all upstream material inherited."""
import hashlib,json,pathlib,stat,zipfile
R=pathlib.Path(__file__).resolve().parent;OUT=R/'release'
PRE=R/'dataset-lane'
STAMP='compiler-playground-20261031T1003-independent-job-deepfuzz'
ZIP=OUT/(STAMP+'-new-only-sha-objects.zip');M=OUT/(STAMP+'-new-only-manifest.json')
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
new=[];inherited=[]
for card,count in [('join-order-benchmark',116),('deepfuzz',8)]:
 p=PRE/card/'dataset-candidate/prepared'
 rows=[]
 for src in sorted(p.iterdir()):
  if not src.is_file():continue
  target=f'{card}/{src.name}'
  rec={'path':target,'sha256':sha(src),'bytes':src.stat().st_size,'mode':stat.S_IMODE(src.stat().st_mode),
       'source':('new_Dataset_metadata_SHA' if src.name in ('dataset.json','prepared.json') else 'inherited_upstream_source_original'),
       'source_card':card}
  if src.name in ('dataset.json','prepared.json'):new.append((rec,src))
  else:inherited.append(rec)
 assert len([r for r in inherited if r['source_card']==card])==count
assert len(new)==4 and len(inherited)==124
assert len({r['sha256'] for r,p in new})==4
assert not {r['sha256'] for r,p in new}&{r['sha256'] for r in inherited}
report_job=json.loads((PRE/'join-order-benchmark/dataset-candidate/dataset-card-validation.json').read_text())
report_deep=json.loads((PRE/'deepfuzz/dataset-candidate/dataset-card-validation.json').read_text())
vols={
 'join-order-benchmark':{'filename':'compiler-playground-v0.21.3-objects-003.zip','library_file_id':'libfile_933ad889f51081919ab40eb29a6a10e4','sha256':'c8bebf47cfaa51756a60f84a350df319384178244c7bc30bdea54e50a629ff1b','bytes':116259475,
   'source_tar_sha256':'6a57357a67950dbd507f8a7cebdbed1d0a3806b3de445b8dd20f82f0d4aa7593','source_tar_bytes':12313,'source_tree_root':'join-order-benchmark-a39603662e023e449cb2121997a5034df9e02ebf'},
 'deepfuzz':{'filename':'compiler-playground-v0.21.4-objects-001.zip','library_file_id':'libfile_20afc30d50908191b47f998ed2d2ce5c','sha256':'3cfa06d68223d45fef179b9e037eff2e5f49c4229d22b869a2aecbffac3148c9','bytes':258168292,
   'source_tar_sha256':'1b051cf91e31f15a5415a7e377a6f8047f920fa9a9939fa71baed181babb5f25','source_tar_bytes':4762,'source_tree_root':'DeepFuzz-6079bef655b471b82c70e51024d3d4824092f396'}}
for k,v in vols.items():
 p=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs')/v['filename']
 assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256']
 with zipfile.ZipFile(p) as z:
  body=z.read('objects/'+v['source_tar_sha256'])
  assert hashlib.sha256(body).hexdigest()==v['source_tar_sha256'] and len(body)==v['source_tar_bytes']
manifest={'format':'cpg-job-deepfuzz-original-source-only-newSHA-v1','formal_baseline':'0.21.13','formally_published':False,
 'owner_round':'20261031T1003Z-native-and-Dataset-independent-handoff','actual_input_volumes':vols,
 'original_source_card_bindings':{'join-order-benchmark':{'resource_id':'dataset-ref.join-order-benchmark','original_card_id':'join-order-benchmark',
   'revision':'a39603662e023e449cb2121997a5034df9e02ebf','original_source_url':'https://codeload.github.com/gregrahn/join-order-benchmark/tar.gz/a39603662e023e449cb2121997a5034df9e02ebf',
   'source_original_regular_files':116,'original_query_source_samples':113,'original_2013_IMDB_data_available':False,'official_benchmark_qualified':False,
   'license_expression':'NOASSERTION'},
  'deepfuzz':{'resource_id':'dataset-ref.deepfuzz','original_card_id':'deepfuzz',
   'revision':'6079bef655b471b82c70e51024d3d4824092f396','original_source_url':'https://codeload.github.com/s3team/DeepFuzz/tar.gz/6079bef655b471b82c70e51024d3d4824092f396',
   'source_original_regular_files':8,'original_python_source_samples':6,'trained_model_available':False,'generated_source_programs':0,
   'license_expression':'NOASSERTION'}},
 'new_entries':[r for r,p in new],'inherited_entries':inherited,
 'dataset_fingerprints':{'join-order-benchmark':report_job['dataset_fingerprint'],'deepfuzz':report_deep['dataset_fingerprint']},
 'independent_candidate_counts':{'new_derived_SHA_objects':4,'inherited_original_regular_files':124,'distinct_primary_source_samples':119,'candidate_dataset_cards':2},
 'fixed_original_resource_ids':1862,'fixed_original_dataset_cards':195,
 'formal_managed_resources_before_and_after':1700,'formal_verified_Dataset_cards_before_and_after':88,
 'new_original_resources_qualified':0,'new_formal_dataset_cards_qualified':0,
 'host_only':'Debian13/Python3.13 candidate; no official workload execution',
 'historical_source_archives_repacked':0}
M.write_text(json.dumps(manifest,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
with zipfile.ZipFile(ZIP,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def store(name,data):
  info=zipfile.ZipInfo(name,(2026,10,31,2,0,0));info.external_attr=(0o100644<<16)
  info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=6)
 store('manifest.json',M.read_bytes())
 for r,p in sorted(new,key=lambda pair:pair[0]['sha256']):store('objects/'+r['sha256'],p.read_bytes())
with zipfile.ZipFile(ZIP) as z:
 assert len(z.namelist())==5 and z.testzip() is None
 for r,p in new:assert z.read('objects/'+r['sha256'])==p.read_bytes()
record={'artifact':ZIP.name,'sha256':sha(ZIP),'bytes':ZIP.stat().st_size,'manifest_name':M.name,'manifest_sha256':sha(M),'new_unique_SHA_objects':4,'inherited_original_source_files':124,'historical_repacked_objects':0,'formal_qualification_increment':0}
(OUT/(STAMP+'-bundle-construction-report.json')).write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,indent=2))
