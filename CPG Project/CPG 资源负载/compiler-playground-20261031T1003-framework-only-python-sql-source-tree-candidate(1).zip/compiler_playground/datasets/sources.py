"""Explicit local-source importers; raw code never invents a runtime oracle."""
from __future__ import annotations

import importlib
from pathlib import Path
from typing import Mapping

from ..data import Dataset, Sample, _copy, _integer, _text, source_digest
from ._common import build_sample, file_record
from .storage import _sha, _stat, create_index


def _unchanged(stamps, message):
    try:
        if any(_stat(path) != stamp for path, stamp in stamps.items()):
            raise ValueError(message)
    except OSError as exc:
        raise ValueError(message) from exc


def _local_files(root):
    files = []
    for path in root.rglob("*"):
        if path.is_symlink():
            raise ValueError("Local Hugging Face snapshots must not contain symlinks")
        if path.is_file():
            files.append(path)
        elif not path.is_dir():
            raise ValueError("Local Hugging Face snapshots must contain ordinary files and directories")
    return sorted(files)


def from_records(records, *, dataset_id="records", purpose="demo", metadata=None):
    return Dataset(records, dataset_id=dataset_id, purpose=purpose, metadata=metadata)


def from_source_tree(root, *, revision, url, license_file, license_expression,
                     adapter_file, dataset_id="source-tree", suite="source-tree",
                     patterns=("**/*.c", "**/*.cc", "**/*.cpp", "**/*.ll"),
                     group_by=None, group_policy_id=None, extra_files=(), output_dir=None):
    """Import individual source units for compile-only research.

    With no audited family mapping the whole source tree is one family. A
    callable group_by(relative_path) requires a named policy and must preserve
    repository/problem/clone ancestry. Header closure and linkability are not
    inferred from filenames, so this importer never admits runtime performance.
    """
    root = Path(root).resolve(strict=True)
    _text(revision, "revision")
    if isinstance(patterns, (str, bytes)) or not patterns:
        raise ValueError("patterns must be a nonempty sequence")
    if group_by is not None and (not callable(group_by) or not isinstance(group_policy_id, str) or not group_policy_id.strip()):
        raise ValueError("A custom source-family function requires group_policy_id")
    if isinstance(extra_files, (str, bytes, Path)):
        raise ValueError("extra_files must be an iterable of file paths")
    extra_files = tuple(extra_files)
    paths = set()
    for pattern in patterns:
        if not isinstance(pattern, str) or Path(pattern).is_absolute() or ".." in Path(pattern).parts:
            raise ValueError("Source patterns must be relative without traversal")
        for path in root.glob(pattern):
            if not path.is_file():
                continue
            resolved = path.resolve(strict=True)
            if root not in resolved.parents:
                raise ValueError("Source path escapes the prepared root")
            paths.add(resolved)
    if not paths:
        raise ValueError("The source import selected no files")
    paths = sorted(paths)
    languages = {".c": "c", ".cc": "c++", ".cpp": "c++", ".cxx": "c++", ".ll": "llvm-ir", ".bc": "llvm-bitcode",
                 ".f": "fortran", ".f90": "fortran", ".rs": "rust", ".go": "go",
                 ".py": "python", ".sql": "sql"}

    shared_paths = [license_file, adapter_file, *extra_files]
    shared_paths = [(Path(path) if Path(path).is_absolute() else root / path).resolve(strict=True)
                    for path in shared_paths]
    stamps = {path: _stat(path) for path in {*paths, *shared_paths}}
    # License, adapter and header bytes are common to every unit. Hash them
    # once, while retaining a stamp check until the complete import is ready.
    template = build_sample(root=root, id="source-template", group="source-template", suite=suite,
                            sources=[paths[0]], language="unknown", revision=revision, url=url,
                            license_file=license_file, license_expression=license_expression,
                            adapter_file=adapter_file, extra_files=extra_files,
                            execution_config={"kind": "source_unit", "compile_qualified": False,
                                              "runtime_qualified": False},
                            payload={"admission": "compile_only_unqualified_source_unit"})

    def samples():
        for index, path in enumerate(paths):
            relative = path.relative_to(root).as_posix()
            group = group_by(relative) if group_by is not None else f"{suite}/unpartitioned-origin"
            _text(group, "source family")
            details = _copy(template.payload)
            details["sources"] = details["sources"] if index == 0 else [file_record(root, path)]
            details["language"] = languages.get(path.suffix.lower(), "unknown")
            details["execution"]["config"]["entry"] = relative
            yield Sample(id=f"{suite}/{relative}", group=group, suite=suite,
                         source_digest=source_digest(details["sources"]), payload=details)
        _unchanged(stamps, "Source-tree materials changed during preparation")
    metadata = {"provider": "source_tree", "revision": revision,
                "group_policy_id": group_policy_id or "entire_origin_v1",
                "header_closure_inferred": False, "runtime_oracle_available": False}
    if output_dir is not None:
        return create_index(samples(), output_dir, dataset_id=dataset_id, purpose="compile_only",
                            metadata=metadata, material_root=root)
    return Dataset(samples(), dataset_id=dataset_id, purpose="compile_only", metadata=metadata,
                   material_root=root)


def from_huggingface(path, *, output_dir, to_sample, transform_id,
                     dataset_id="huggingface-local", purpose="compile_only", split=None,
                     material_root=None):
    """Convert an already prepared local HF Dataset; never contact the Hub.

    Source-column conversion is explicit because code text alone cannot supply
    files, licenses, provenance, a build closure or a correctness oracle.
    """
    _text(transform_id, "transform_id")
    if not callable(to_sample):
        raise TypeError("to_sample must convert one record into a Sample")
    local = Path(path).resolve(strict=True)
    if not local.is_dir():
        raise ValueError("A local Hugging Face save_to_disk directory is required")
    destination = Path(output_dir).resolve()
    if destination == local or local in destination.parents:
        raise ValueError("The converted index must be outside the Hugging Face source snapshot")
    files = _local_files(local)
    stamps = {path: _stat(path) for path in files}
    identities = [{"path": path.relative_to(local).as_posix(), "bytes": path.stat().st_size,
                   "sha256": _sha(path)} for path in files]
    _unchanged(stamps, "Hugging Face input changed while hashing")
    try:
        hf = importlib.import_module("datasets")
    except ImportError as exc:
        raise ImportError("Install the pinned Hugging Face datasets dependency during environment preparation") from exc
    value = hf.load_from_disk(str(local))
    if isinstance(value, Mapping):
        if split is None or split not in value:
            raise ValueError("Select an explicit split from the local Hugging Face DatasetDict")
        value = value[split]
    elif split is not None:
        raise ValueError("A single local Hugging Face Dataset has no named split")
    def records():
        for record in value:
            yield to_sample(record)
        if _local_files(local) != files:
            raise ValueError("Hugging Face snapshot file inventory changed during preparation")
        _unchanged(stamps, "Hugging Face input changed during preparation")

    return create_index(records(), output_dir,
                        dataset_id=dataset_id, purpose=purpose, material_root=material_root,
                        metadata={"provider": "huggingface_local", "transform_id": transform_id,
                                  "upstream_fingerprint": getattr(value, "_fingerprint", None),
                                  "upstream_split": split, "package_version": getattr(hf, "__version__", None),
                                  "source_files": identities})


def from_parquet(paths, *, output_dir, to_sample, transform_id,
                 dataset_id="parquet-local", purpose="compile_only", batch_size=1024,
                 material_root=None):
    """Read local Parquet record batches into a frozen index with explicit conversion."""
    _integer(batch_size, "batch_size", 1)
    _text(transform_id, "transform_id")
    if not callable(to_sample):
        raise TypeError("to_sample must be callable")
    if isinstance(paths, (str, Path)):
        paths = [paths]
    files = [Path(path).resolve(strict=True) for path in paths]
    if not files or len(set(files)) != len(files) or any(not path.is_file() for path in files):
        raise ValueError("Select one or more distinct regular local Parquet files")
    try:
        parquet = importlib.import_module("pyarrow.parquet")
    except ImportError as exc:
        raise ImportError("Install pinned pyarrow during environment preparation") from exc
    identities = []
    stamps = {}
    for path in files:
        stamps[path] = _stat(path)
        identities.append({"name": path.name, "bytes": path.stat().st_size, "sha256": _sha(path)})
    _unchanged(stamps, "Parquet input changed while hashing")

    def records():
        for path in files:
            with parquet.ParquetFile(path) as reader:
                for batch in reader.iter_batches(batch_size=batch_size):
                    for record in batch.to_pylist():
                        yield to_sample(record)
        _unchanged(stamps, "Parquet input changed during preparation")
    return create_index(records(), output_dir, dataset_id=dataset_id, purpose=purpose,
                        material_root=material_root,
                        metadata={"provider": "parquet_local", "transform_id": transform_id, "files": identities})
