#!/usr/bin/env python3
"""Adversarial original-material source delta and post-install double restoration."""
from pathlib import Path
import hashlib,json,subprocess,sys,zipfile,shutil
R=Path(__file__).resolve().parent
IN=Path('/mnt/data/cpg-automation-20261031T1003-inputs')
REL=R/'release'
ZIP=REL/'compiler-playground-20261031T1003-independent-job-deepfuzz-new-only-sha-objects.zip'
TOOL=R/'release-tools/restore_job_deepfuzz_newonly.py'
J=IN/'compiler-playground-v0.21.3-objects-003.zip';D=IN/'compiler-playground-v0.21.4-objects-001.zip'
NEG=R/'validation-job-deepfuzz-negatives';NEG.mkdir(exist_ok=False)
records=[]
def invoke(label,zip=ZIP,job=J,deep=D,already_dir=False,already_report=False):
 out=NEG/('target-'+label);report=NEG/(label+'-report.json')
 if already_dir:out.mkdir(exist_ok=False)
 if already_report:report.write_text('original sentinel\n')
 p=subprocess.run([sys.executable,str(TOOL),'--new-only-zip',str(zip),'--inherited-job-volume',str(job),
  '--inherited-deepfuzz-volume',str(deep),'--output',str(out),'--report',str(report)],
  capture_output=True,text=True,timeout=70)
 assert p.returncode!=0,('Invalid restoration unexpectedly succeeded',label)
 assert (not out.exists() or already_dir)
 assert (not report.exists() or already_report)
 records.append({'label':label,'returncode':p.returncode,'rejected':True,'no_partial_materials_published':not out.exists() or already_dir,
   'error':p.stderr[-350:]})
def mutated(label,func):
 target=NEG/('mutation-'+label+'.zip')
 with zipfile.ZipFile(ZIP) as z,zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as f:
  for n in z.namelist():
   b=z.read(n);result=func(n,b)
   if result is None:continue
   name,new=result;f.writestr(name,new,compress_type=zipfile.ZIP_DEFLATED)
 invoke(label,zip=target);target.unlink()
blank=NEG/'unrelated-volume.bin';blank.write_bytes(b'Not the original historical saved volume')
invoke('wrong-original-job-volume',job=blank)
invoke('wrong-original-deepfuzz-volume',deep=blank)
invoke('reject-existing-output',already_dir=True)
invoke('reject-existing-report',already_report=True)
mutated('corrupted-source-metadata-object',lambda n,b:(n,b+b'EXTRA') if n.startswith('objects/') else (n,b))
mutated('missing-published-object',lambda n,b:None if n.startswith('objects/') else (n,b))
def patch(label,mutator):
 def fn(n,b):
  if n=='manifest.json':
   obj=json.loads(b);mutator(obj);return n,json.dumps(obj,sort_keys=True).encode()
  return n,b
 mutated(label,fn)
patch('path-traversal-refused',lambda j:j['new_entries'][0].__setitem__('path','../outside/dataset.json'))
patch('bad-file-mode-refused',lambda j:j['new_entries'][0].__setitem__('mode',0o777))
patch('identity-mismatch-refused',lambda j:j['inherited_entries'][0].__setitem__('sha256','0'*64))
patch('original-source-volume-rebinding-refused',lambda j:j['actual_input_volumes']['join-order-benchmark'].__setitem__('sha256','0'*64))
extra=NEG/'unexpected-extra-payload.zip'
with zipfile.ZipFile(ZIP) as inp,zipfile.ZipFile(extra,'x',compression=zipfile.ZIP_DEFLATED) as out:
 for n in inp.namelist():out.writestr(n,inp.read(n))
 out.writestr('objects/'+'d'*64,b'unlisted object')
invoke('extra-undeclared-object-refused',zip=extra);extra.unlink()
assert len(records)==11
# Second genuinely absent restoration destination, no reading first restoration directory.
B=R/'restore-job-deepfuzz-newonly-B'
OUT=REL/'job-deepfuzz-restore-B.json'
p=subprocess.run([sys.executable,str(TOOL),'--new-only-zip',str(ZIP),'--inherited-job-volume',str(J),
 '--inherited-deepfuzz-volume',str(D),'--output',str(B),'--report',str(OUT)],capture_output=True,text=True,timeout=90)
assert p.returncode==0,p.stderr
A=R/'restore-job-deepfuzz-newonly-A'
def inventory(root):
 return {p.relative_to(root).as_posix():(hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size,p.stat().st_mode&0o777)
         for p in root.rglob('*') if p.is_file()}
a=inventory(A);b=inventory(B)
assert len(a)==len(b)==128 and a==b
# Actual installed CPG v0.21.13 must cold-load BOTH independently restored candidate sets.
install=R/'venv/bin/python';consumer=R/'release-tools/verify_four_source_datasets_installed.py'
p2=subprocess.run([str(install),str(consumer),'--ccg-remccg-root',str(R/'restore-native-source-newonly-B'),
  '--job-deepfuzz-root',str(B),'--report',str(REL/'four-card-real-installed-app-B.json')],
  capture_output=True,text=True,timeout=120)
assert p2.returncode==0,p2.stderr
record={'format':'job-deepfuzz-newSHA-only-strict-negative-independent-restoration-v1',
 'negative_cases_rejected':len(records),'negative_case_details':records,
 'second_independent_historical_volume_restore_pass':True,'all_128_files_SHA_size_mode_identical':True,
 'restoration_a_and_b_independent':True,'saved_historical_original_source_files_duplicated_in_new_ZIP':0,
 'installed_CPG_0_21_13_four_card_actual_consumer_B_passed':True,
 'original_resource_ID_increment':0,'formally_merged_card_increment':0,
 'fresh_restored_job_deepfuzz_source_files':124,'fresh_restored_new_metadata_files':4,
 'original_2013_IMDB_corpus_available':False,'DeepFuzz_trained_model_available':False}
(REL/'job-deepfuzz-negative-and-twice-restored-regression.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:record[k] for k in ('negative_cases_rejected','second_independent_historical_volume_restore_pass','all_128_files_SHA_size_mode_identical','installed_CPG_0_21_13_four_card_actual_consumer_B_passed')},indent=2))
