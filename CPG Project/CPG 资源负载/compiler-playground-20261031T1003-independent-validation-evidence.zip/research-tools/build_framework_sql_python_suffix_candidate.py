#!/usr/bin/env python3
"""Build non-published framework-only narrow language-binding patch for CPG 0.21.13."""
import pathlib,hashlib,shutil,difflib,json,re
R=pathlib.Path(__file__).resolve().parent
SRC=R/'venv/lib/python3.13/site-packages/compiler_playground'
OVER=R/'framework-lane/runtime-overlay/compiler_playground'
PATCH=R/'framework-lane/patch'
PATCH.mkdir(parents=True,exist_ok=False);OVER.parent.mkdir(parents=True,exist_ok=True)
shutil.copytree(SRC,OVER,symlinks=False,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.pyo'))
base=(SRC/'datasets/sources.py').read_bytes();text=base.decode('utf-8')
needle='".f": "fortran", ".f90": "fortran", ".rs": "rust", ".go": "go"}'
assert text.count(needle)==1
changed=text.replace(needle,'".f": "fortran", ".f90": "fortran", ".rs": "rust", ".go": "go",\n                 ".py": "python", ".sql": "sql"}')
changedb=changed.encode('utf-8');target=OVER/'datasets/sources.py';target.write_bytes(changedb)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha((SRC/'datasets/sources.py').read_bytes())==sha(base)
assert changed.count('".sql": "sql"')==1 and changed.count('".py": "python"')==1
assert len(changedb)>len(base)
patch=''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),
 fromfile='a/compiler_playground/datasets/sources.py',tofile='b/compiler_playground/datasets/sources.py',n=5))
(PATCH/'sources.py.patch').write_text(patch)
(PATCH/'sources.py').write_bytes(changedb)
report={'format':'cpg-framework-only-minimal-v02113-overlay-candidate-v1','formally_published':False,
 'formal_baseline':'0.21.13','target_path':'compiler_playground/datasets/sources.py',
 'base_size':len(base),'base_sha256':sha(base),'candidate_size':len(changedb),'candidate_sha256':sha(changedb),
 'resource_load_added':0,'new_original_resources':0,'source_files_republished_in_release':1,
 'source_suffix_bindings_added':{'.py':'python','.sql':'sql'},
 'new_behavior':'from_source_tree reports correct language for ordinary Python and SQL source units; compile_only contract unchanged',
 'not_changed':['existing language suffixes','source provenance','license policy','group family policy','official Benchmark','Dataset execution/compile qualification']}
(PATCH/'framework-only-candidate-manifest.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2))
