#!/usr/bin/env python3
"""Evidence-only regression: framework overlay from official wheel, not publisher workspace."""
import hashlib,json,os,pathlib,subprocess,sys
r=pathlib.Path(__file__).resolve().parent
cand=r/'framework-lane/runtime-overlay'
base=r/'venv/lib/python3.13/site-packages'
pre=r/'release'
tests=r/'framework-lane/test/test_python_sql_source_tree_languages.py'
assert (cand/'compiler_playground/datasets/sources.py').exists() and tests.exists()
sel=r/'regression-isolated-official-tests'
include=['test_dataset_registry_materials.py','test_dataset_loader_extended.py','test_dataset_mixtures.py','test_dataset_operations.py','test_dataset_storage_sources.py','test_dataset_training.py','test_dataset_composition_pipeline.py','test_dataset_generators.py','test_dataset_catalog_api.py','test_dataset_admission.py']
env=dict(os.environ,PYTHONPATH=str(cand)+os.pathsep+str(base),PYTHONNOUSERSITE='1')
command=[sys.executable,'-m','pytest','-q','-ra','--disable-warnings',str(tests),*[str(sel/x) for x in include]]
p=subprocess.run(command,capture_output=True,text=True,env=env,cwd=str(sel),timeout=200)
report={'format':'cpg-framework-python-sql-language-candidate-focused-suite-v1',
 'unchanged_official_wheel':'0.21.13','framework_changed_path':'compiler_playground/datasets/sources.py',
 'candidate_lang_bindings':['.py => python','.sql => sql'],'test_command':command,
 'source_overlay_pythonpath_first':str(cand),'real_0_21_13_runtime_module_and_support_otherwise_preserved':True,
 'pass':p.returncode==0,'returncode':p.returncode,'stdout':p.stdout[-11000:],'stderr':p.stderr[-9000:],
 'resource_IDs_admitted':0,'new_original_resource_payloads':0,'formally_published':False}
(pre/'framework-only-candidate-focused-regression.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
(pre/'framework-only-candidate-focused-regression.log').write_text(p.stdout+'\n---- STDERR ----\n'+p.stderr)
print('returncode',p.returncode,'\n',p.stdout[-2500:],'\n',p.stderr[-2000:]);sys.exit(p.returncode)
