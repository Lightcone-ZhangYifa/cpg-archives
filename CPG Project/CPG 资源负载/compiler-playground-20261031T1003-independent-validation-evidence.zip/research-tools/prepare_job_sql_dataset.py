#!/usr/bin/env python3
"""Original JOB SQL queries as ordinary compile-only SQL-source Dataset candidates.

No IMDB data or PostgreSQL execution; never a benchmark qualification.
"""
from __future__ import annotations
import collections,hashlib,json,pathlib,re,shutil
from compiler_playground import datasets
from compiler_playground.datasets.sources import build_sample
R=pathlib.Path(__file__).resolve().parent
B=R/'dataset-lane/join-order-benchmark'
ORIGIN=next((B/'source').iterdir());DEST=B/'dataset-candidate'
MAT=DEST/'material-root';PREP=DEST/'prepared';INDEX=DEST/'index'
REV='a39603662e023e449cb2121997a5034df9e02ebf'
URL=f'https://codeload.github.com/gregrahn/join-order-benchmark/tar.gz/{REV}'
EXPECTED_ORIG_SHA='6a57357a67950dbd507f8a7cebdbed1d0a3806b3de445b8dd20f82f0d4aa7593'
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def main():
 assert ORIGIN.name.endswith(REV)
 assert EXPECTED_ORIG_SHA in (B/'original-archive.meta').read_text()
 DEST.mkdir(exist_ok=False);shutil.copytree(ORIGIN,MAT)
 files=sorted(x.relative_to(MAT).as_posix() for x in MAT.rglob('*') if x.is_file())
 assert len(files)==116 and set(['schema.sql','fkindexes.sql','README.md'])<=set(files)
 assert all(digest(ORIGIN/f)==digest(MAT/f) for f in files)
 cases=sorted(f for f in files if re.fullmatch(r'([1-9]|[12][0-9]|3[0-3])[a-z]\.sql',f))
 assert len(cases)==113,len(cases)
 query_num=lambda path:int(re.match(r'\d+',path).group(0))
 families=sorted({query_num(x) for x in cases});assert families==list(range(1,34)),families
 # Real original source identities: each query has original schema, optional foreign-key indexes and readme context.
 # All 116 original Git files are included in the prepared content closure; no external DB data fabricated.
 samples=[]
 for f in cases:
  companions=[x for x in files if x!=f]
  sample=build_sample(root=MAT,id=f'join-order-benchmark/{f}',group=f'join-order-benchmark/query-{query_num(f):02d}',suite='join-order-benchmark',
   sources=[f],language='sql',revision=REV,url=URL,license_file='README.md',license_expression='NOASSERTION',
   adapter_file='schema.sql',extra_files=companions,
   execution_config={'kind':'postgresql_query_text','compile_qualified':False,'runtime_qualified':False,
                     'db_schema_only':True,'original_IMDB_2013_data_available':False,'query_execution_authorized':False},
   payload={'admission':'compile_only_sql_text_unqualified','original_workload_id':f[:-4],
            'unresolved_license_notice':'No LICENSE in upstream repo; README is context only, not an asserted license grant'})
  samples.append(sample)
 ds=datasets.Dataset(samples,dataset_id='join-order-benchmark',purpose='compile_only',material_root=MAT,
   metadata={'provider':'original_postgresql_sql_source_archive','git_revision':REV,'source_url':URL,
     'original_source_input_sha256':EXPECTED_ORIG_SHA,'query_ancestry_group_policy':'numeric_query_template_family_v1',
     'external_db_data_required_for_official_job':True,'official_benchmark_score_not_claimed':True})
 assert len(ds)==113 and len({s.group for s in ds})==33
 assert all(s.payload['language']=='sql' for s in ds)
 assert all(len(s.payload['files'])==115 for s in ds)
 assert len({s.id for s in ds})==113
 # Validate non-leaking query families in group split, not sample-level random leakage.
 triplet=datasets.split(ds,fractions=(0.65,0.2,0.15),seed=1701,unit='group')
 split_groups={key:{s.group for s in v} for key,v in triplet.items()}
 names=list(split_groups)
 assert len(names)==3,names
 assert not set.intersection(*(split_groups[x] for x in names))
 assert set.union(*(split_groups[x] for x in names))=={s.group for s in ds}
 assert sum(len(d) for d in triplet.values())==len(ds)
 prepared=datasets.prepare('join-order-benchmark',ds,material_root=MAT,output_dir=PREP)
 receipt=json.loads((PREP/'prepared.json').read_text());assert len(receipt['files'])==116
 loaded=datasets.load('join-order-benchmark',root=PREP,verify=True)
 assert len(loaded)==113 and loaded.fingerprint==ds.fingerprint
 assert {s.group for s in loaded}=={s.group for s in ds}
 idx=datasets.save_to_disk(loaded,INDEX,material_root=PREP);idx.close()
 with datasets.load_from_disk(INDEX,verify_files=True) as cold:
  assert cold.fingerprint==ds.fingerprint
  def loader():return datasets.DataLoader(cold,batch_size=17,seed=1931,sampler=datasets.RandomSampler())
  left=loader();left.next_batch();state=left.state_dict();right=loader();right.load_state_dict(state)
  epochs=[]
  for n in range(12):
   a=[s.id for s in left.next_batch()];b=[s.id for s in right.next_batch()];assert a==b and left.state_dict()==right.state_dict()
   epochs.append(left.epoch)
  assert max(epochs)>state['epoch']
 bad=DEST/'tamper-negative';shutil.copytree(PREP,bad)
 original=bad/'1a.sql';original.chmod(0o644);original.write_bytes(original.read_bytes()+b'\n-- tamper!\n')
 tamper_error=None
 try:datasets.load('join-order-benchmark',root=bad,verify=True)
 except Exception as exc:tamper_error=f'{type(exc).__name__}: {exc}'
 assert tamper_error
 report={'format':'cpg-independent-join-order-benchmark-sql-source-dataset-v1','original_card_id':'join-order-benchmark',
  'original_resource_id':'dataset-ref.join-order-benchmark','source_archive_sha256':EXPECTED_ORIG_SHA,
  'original_version':REV,'original_url':URL,'original_repo_complete_regular_files':116,
  'original_sql_files':115,'canonical_113_job_query_source_samples':113,'non_query_SQL_files':['schema.sql','fkindexes.sql'],
  'original_non_SQL_metadata_files':['README.md'],'full_source_context_copied':True,
  'query_template_families':33,'query_family_policy':'numeric_query_template_family_v1',
  'group_split_seed':1701,'group_split_sizes':{k:len(v) for k,v in triplet.items()},
  'group_split_families':{k:sorted(v) for k,v in split_groups.items()},
  'group_split_no_ancestry_leak':True,'source_checksum_validation_all_116':True,
  'dataset_fingerprint':ds.fingerprint,'prepared_files':len(receipt['files']),'prepared_bytes':receipt['material_bytes'],
  'prepared_manifest_sha256':digest(PREP/'dataset.json'),'prepared_receipt_sha256':digest(PREP/'prepared.json'),
  'SQL_text_language_recorded':True,'actual_SQL_query_execution_count':0,'external_original_IMDB_2013_data_available':False,
  'DB_schema_and_queries_not_official_benchmark':True,'official_benchmark_protocol_score':None,
  'source_license_expression':'NOASSERTION','license_review_required':True,'source_REAME_not_an_actual_licence':True,
  'restore_fingerprint_verified':True,'cold_index_verified':True,'loader_resume_across_epoch':True,'tamper_rejected':True,
  'tamper_error':tamper_error,'formal_resource_id_increment':0,'formal_dataset_cards_increment':0,
  'sample_paths_and_SHA':[{'path':f,'sha256':digest(MAT/f),'bytes':(MAT/f).stat().st_size} for f in cases]}
 (DEST/'dataset-card-validation.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:report[k] for k in ['canonical_113_job_query_source_samples','query_template_families','prepared_files','dataset_fingerprint','group_split_no_ancestry_leak','tamper_rejected']},indent=2))
if __name__=='__main__':main()
