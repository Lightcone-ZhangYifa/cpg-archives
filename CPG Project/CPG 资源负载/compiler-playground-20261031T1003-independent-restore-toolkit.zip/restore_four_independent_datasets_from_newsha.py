#!/usr/bin/env python3
"""Public offline original-SHA-volume + two NEW-SHA-delta four-card restore.

Two completely disjoint source-archive importers, two independent restores, one
installed v0.21.13 real Dataset consumer; commits only a complete new directory.
"""
from __future__ import annotations
import argparse,hashlib,json,os,pathlib,shutil,subprocess,sys,tempfile
HERE=pathlib.Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--ccg-remccg-new-zip',required=True,type=pathlib.Path)
 p.add_argument('--job-deepfuzz-new-zip',required=True,type=pathlib.Path)
 p.add_argument('--inherited-v0214-objects-001',required=True,type=pathlib.Path)
 p.add_argument('--inherited-v0213-objects-003',required=True,type=pathlib.Path)
 p.add_argument('--python-with-installed-cpg02113',required=True,type=pathlib.Path)
 p.add_argument('--output',required=True,type=pathlib.Path)
 args=p.parse_args()
 out=args.output.absolute()
 if out.exists() or out.is_symlink():raise ValueError('Output must be a new nonexistent directory')
 inputs=[args.ccg_remccg_new_zip,args.job_deepfuzz_new_zip,args.inherited_v0214_objects_001,args.inherited_v0213_objects_003]
 pinned=[x.resolve(strict=True) for x in inputs]
 py=args.python_with_installed_cpg02113.resolve(strict=True)
 if any(out==p or out in p.parents for p in pinned+[py]):raise ValueError('Output may not contain immutable input')
 out.parent.mkdir(parents=True,exist_ok=True)
 stage=pathlib.Path(tempfile.mkdtemp(prefix='.cpg-four-dataset-newSHA-stage-',dir=out.parent))
 commands=[]
 try:
  for cmd in [
   [sys.executable,str(HERE/'restore_ccg_remccg_newonly.py'),
    '--new-only-zip',str(pinned[0]),'--inherited-ready-volume',str(pinned[2]),
    '--output',str(stage/'restored-ccg-remccg'),'--report',str(stage/'restore-ccg-remccg.json')],
   [sys.executable,str(HERE/'restore_job_deepfuzz_newonly.py'),
    '--new-only-zip',str(pinned[1]),'--inherited-job-volume',str(pinned[3]),
    '--inherited-deepfuzz-volume',str(pinned[2]),
    '--output',str(stage/'restored-job-deepfuzz'),'--report',str(stage/'restore-job-deepfuzz.json')],
   [str(py),str(HERE/'verify_four_source_datasets_installed.py'),
    '--ccg-remccg-root',str(stage/'restored-ccg-remccg'),
    '--job-deepfuzz-root',str(stage/'restored-job-deepfuzz'),
    '--report',str(stage/'installed-postrestore-four-dataset-app.json')]]:
   p=subprocess.run(cmd,capture_output=True,text=True,timeout=170)
   commands.append({'cmd':[str(x) for x in cmd], 'exit_code':p.returncode,'stdout_tail':p.stdout[-1800:],'stderr_tail':p.stderr[-1800:]})
   if p.returncode!=0:raise RuntimeError(f'Staged restoration step rejected: {p.returncode}, {p.stderr[-800:]}')
  report={'format':'cpg-four-original-datasets-public-all-new-SHA-restore-v1',
   'candidate_only':True,'former_main_release':'0.21.13','formal_resource_coverage_unchanged':'1700/1862',
   'formal_Dataset_interfaces_unchanged':'88/195','four_independent_candidate_cards':['ccg','remccg','join-order-benchmark','deepfuzz'],
   'unique_candidate_primary_samples':161,'distinct_original_source_regular_files_reused':178,'distinct_new_SHA_object_files':34,
   'new_delta_zips_SHA256':{pinned[0].name:hashlib.sha256(pinned[0].read_bytes()).hexdigest(),pinned[1].name:hashlib.sha256(pinned[1].read_bytes()).hexdigest()},
   'legacy_volumes_reused':[{ 'name':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in pinned[2:]],
   'all_three_actual_steps_executed_and_passed':True,'commands':commands,
   'generated_programs_executed':False,'external_DB_data_loaded':False,'licensed_for_all_uses':False,
   'host':'Linux amd64 Debian 13 Python 3.13 only; original Ubuntu 24.04 OCI and hardware untested'}
  (stage/'public-offline-restore-result.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
  if out.exists() or out.is_symlink():raise ValueError('Output appeared during public restoration')
  os.rename(stage,out)
  print(json.dumps({'all_three_actual_steps_executed_and_passed':True,'output':str(out),'new_SHA_objects':34,'inherited_original_source_files':178,'primary_samples':161},indent=2))
 except BaseException:
  shutil.rmtree(stage,ignore_errors=True)
  raise
if __name__=='__main__':
 try:main()
 except Exception as e:print(f'Independent four-card restore failed: {type(e).__name__}: {e}',file=sys.stderr);sys.exit(1)
