#!/usr/bin/env python3
"""Test data-driven mix, group leak protection, portable reload, and resume with real CCG+RemCCG interfaces."""
from pathlib import Path
import json,hashlib
from compiler_playground import datasets
ROOT=Path(__file__).resolve().parent
A=ROOT/'dataset-lane/ccg/dataset-candidate/prepared'
B=ROOT/'dataset-lane/remccg/dataset-candidate/prepared'
OUT=ROOT/'dataset-lane/ccg-remccg-mixture'
A0=datasets.load('ccg',root=A,verify=True);B0=datasets.load('remccg',root=B,verify=True)
assert len(A0)==24 and len(B0)==18
samples=list(A0)+list(B0)
assert len({s.id for s in samples})==42
assert len({s.group for s in samples})==1, 'CCG and RemCCG ancestry incorrectly split'
M=datasets.mix({'ccg':A0,'remccg':B0}, {'ccg':.5,'remccg':.5},size=60,seed=17,replacement=True,dataset_id='ccg-remccg-mixture-60')
assert len(M)==60 and M.purpose=='compile_only'
assert M.allocation=={'ccg':30,'remccg':30},M.allocation
families={s.group for s in M}
assert len(families)==1,families
prepared=M.prepare(material_roots={'ccg':A,'remccg':B},output_dir=OUT) if not OUT.exists() else datasets.PreparedMixture.load(OUT,verify_files=True)
assert len(prepared)==60 and prepared.fingerprint==M.fingerprint
with datasets.PreparedMixture.load(OUT,verify_files=True) as cold:
 assert cold.fingerprint==M.fingerprint and len(cold)==60
 split_rejected=False
 split_error=None
 try:
  s=datasets.split(cold,(.7,.15,.15),seed=43,unit='group')
 except ValueError as ex:
  split_rejected=True
  split_error=str(ex)
 assert split_rejected and 'three independent program groups' in split_error
 counts={'train':0,'val':0,'test':0}
 def loader():return datasets.DataLoader(cold,batch_size=13,seed=879,sampler=datasets.RandomSampler())
 l1=loader();l1.next_batch();state=l1.state_dict()
 l2=loader();l2.load_state_dict(state)
 for i in range(12):
  assert [x.id for x in l1.next_batch()]==[x.id for x in l2.next_batch()]
  assert l1.state_dict()==l2.state_dict()
 assert l1.epoch>state['epoch']
 report={'format':'cpg-ccg-remccg-independent-mixture-v1','version':'0.21.13-installed',
 'source_dataset_ids':['ccg','remccg'],'source_original_samples':[24,18],
 'original_unique_source_sample_ids':42,'composition_draws':60,'composition_draws_are_not_new_original_samples':True,
 'distribution':M.allocation,'replacement':True,'shared_family_count':len(families),
 'all_ccg_remccg_same_family':True,'train_val_test_by_group':'rejected_insufficient_independent_families',
 'split_rejected':split_rejected,'split_error':split_error,
 'training_and_test_cannot_both_be_populated_without_family_leakage':True,
 'mixture_fingerprint':cold.fingerprint,'mixture_manifest_sha256':hashlib.sha256((OUT/'mixture.json').read_bytes()).hexdigest(),
 'cold_load_verified':True,'twelve_resume_steps_across_epoch':True,
 'download':False,'generated_program_execution':False,'official_benchmark':False,'OCI':False,'hardware_execution':False,
 'new_formal_dataset_cards':0,'new_formal_resources':0}
 (ROOT/'dataset-lane/ccg-remccg-mixture-report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps(report,indent=2))
