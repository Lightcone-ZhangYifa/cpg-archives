#!/usr/bin/env python3
"""One independent RemCCG compile-only source-interface candidate; NO generator runtime claim."""
import hashlib,json,pathlib,shutil
from compiler_playground import datasets
ROOT=pathlib.Path(__file__).resolve().parent
BASE=ROOT/'dataset-lane/remccg'
ORIGIN=next((BASE/'source').iterdir())
DEST=BASE/'dataset-candidate'
MATERIAL=DEST/'material-root';READY=DEST/'prepared';INDEX=DEST/'index'

def digest(path):
 with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def write(path,obj):
 with path.open('x') as f:json.dump(obj,f,sort_keys=True,ensure_ascii=False,indent=2);f.write('\n')

def main():
 DEST.mkdir(exist_ok=False)
 shutil.copytree(ORIGIN,MATERIAL)
 all_files=sorted(p.relative_to(MATERIAL).as_posix() for p in MATERIAL.rglob('*') if p.is_file())
 assert len(all_files)==35,len(all_files)
 assert all(digest(ORIGIN/p)==digest(MATERIAL/p) for p in all_files)
 patterns=('lib/ccg/*.c','src/*.cc')
 selected=sorted({p.relative_to(MATERIAL).as_posix() for pattern in patterns for p in MATERIAL.glob(pattern) if p.is_file()})
 print('selected',len(selected),selected)
 assert len(selected)==18,len(selected)
 ds=datasets.from_source_tree(MATERIAL,revision='e181f6525ef83ff332130deacf5e8df062c44ee3',
   url='https://codeload.github.com/haoxintu/RemCCG/tar.gz/e181f6525ef83ff332130deacf5e8df062c44ee3',
   license_file='lib/ccg/ccg.c',license_expression='NOASSERTION',adapter_file='CMakeLists.txt',
   dataset_id='remccg',suite='remccg',patterns=patterns,
   group_by=lambda _: 'ccg-remccg/shared-generator-family-v1',group_policy_id='ccg-remccg-shared-ancestry-v1',
   extra_files=all_files)
 assert ds.purpose=='compile_only' and len(ds)==18
 assert len({x.group for x in ds})==1
 prepared=datasets.prepare('remccg',ds,material_root=MATERIAL,output_dir=READY)
 loaded=datasets.load('remccg',root=READY,verify=True)
 assert loaded.fingerprint==ds.fingerprint and len(loaded)==18
 receipt=json.loads((READY/'prepared.json').read_text());assert len(receipt['files'])==35
 idx=datasets.save_to_disk(loaded,INDEX,material_root=READY);idx.close()
 with datasets.load_from_disk(INDEX,verify_files=True) as indexed:
  assert len(indexed)==len(loaded) and indexed.fingerprint==loaded.fingerprint
  a=datasets.DataLoader(indexed,batch_size=5,seed=1337,sampler=datasets.RandomSampler())
  a.next_batch();checkpoint=a.state_dict()
  b=datasets.DataLoader(indexed,batch_size=5,seed=1337,sampler=datasets.RandomSampler())
  b.load_state_dict(checkpoint)
  for i in range(11):
   assert [s.id for s in a.next_batch()]==[s.id for s in b.next_batch()]
   assert a.state_dict()==b.state_dict()
  assert a.epoch>checkpoint['epoch']
 bad=DEST/'tamper-negative';shutil.copytree(READY,bad)
 victim=bad/'src/remccg.cc';victim.chmod(0o644)
 victim.write_bytes(victim.read_bytes()+b'\n//tamper')
 rejected=False;err=''
 try:datasets.load('remccg',root=bad,verify=True)
 except Exception as ex:rejected=True;err=type(ex).__name__+': '+str(ex)
 assert rejected
 host=json.loads((BASE/'remccg-source-preflight.json').read_text())
 report={'format':'cpg-independent-remccg-source-only-dataset-v1','original_card_id':'remccg',
  'original_resource_id':'dataset-ref.remccg','original_archive_sha256':'6c57247dde51b1ea24fc5433f57b11cbb6e8cd6bb065515496a98a9c28a824ca',
  'original_archive_bytes':137841,'original_revision':'e181f6525ef83ff332130deacf5e8df062c44ee3',
  'original_source_files_all_included':35,'source_unit_samples':18,'source_unit_languages':{'c':15,'c++':3},
  'sample_identities':[s.id for s in ds],'all_samples_one_ccg_family':True,
  'generated_programs':0,'main_remccg_generator_executed':False,'embedded_ccg_a_out_executed':False,
  'full_remccg_cmake_configure_exit_code':host['complete_source_configure']['returncode'],
  'embedded_lib_ccg_build_exit_codes':[host['embedded_ccg_independent_A']['returncode'],host['embedded_ccg_independent_B']['returncode']],
  'historical_build_and_runtime_dependencies_unresolved':True,
  'license_expression':'NOASSERTION','upstream_license_review_required':True,
  'purpose':'compile_only','compiler_execution_validity_claimed':False,'native_ubuntu2404_qualified':False,'official_benchmark_qualified':False,
  'new_formal_resource_admission':0,'new_formal_dataset_admission':0,'independent_dataset_card_candidate':1,
  'dataset_fingerprint':ds.fingerprint,'prepared_material_files':len(receipt['files']),
  'prepared_material_bytes':receipt['material_bytes'],'prepared_manifest_sha256':digest(READY/'dataset.json'),
  'prepared_receipt_sha256':digest(READY/'prepared.json'),'index_sha256':digest(INDEX/'index.json'),
  'loader_resume_cross_epoch_verified':True,'tamper_rejected':True,'tamper_reason':err,
  'split_warning':'CCG and RemCCG share generator ancestry; do not split their source variants into separate train/test families.'}
 write(DEST/'dataset-card-validation.json',report)
 print(json.dumps({k:report[k] for k in ('original_card_id','source_unit_samples','original_source_files_all_included','dataset_fingerprint','tamper_rejected')},indent=2))

if __name__=='__main__':main()
