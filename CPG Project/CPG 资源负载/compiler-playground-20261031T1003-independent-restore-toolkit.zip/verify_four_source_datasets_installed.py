#!/usr/bin/env python3
"""Actual post-install 0.21.13 CPG Dataset load/mix/split, all four restored sources."""
from __future__ import annotations
import argparse,hashlib,json,pathlib,sys
from compiler_playground import __version__,datasets
EXPECT={'ccg':('5bdcbc33e40f16ccbe537efc39f50adc1815715d69eb742d62ed8bb028d1e9ad',24),
 'remccg':('dc1418cf151eebbfb4c3d5eb4d42ee8693f06b9040bc1182a5462e42599721e5',18),
 'join-order-benchmark':('5ae17e160c77187ff82a70bd0f8bfcf286463a9e984aa5ffece3e1107337f06b',113),
 'deepfuzz':('84ae7de6adb1f8ab258872a8206c2d05156eb4f159b8f9a81727e717eb100b5c',6)}
def main():
 p=argparse.ArgumentParser();p.add_argument('--ccg-remccg-root',type=pathlib.Path,required=True)
 p.add_argument('--job-deepfuzz-root',type=pathlib.Path,required=True)
 p.add_argument('--report',type=pathlib.Path,required=True)
 a=p.parse_args()
 assert __version__=='0.21.13',(__version__,sys.executable)
 assert not a.report.exists()
 roots={'ccg':a.ccg_remccg_root,'remccg':a.ccg_remccg_root,
        'join-order-benchmark':a.job_deepfuzz_root,'deepfuzz':a.job_deepfuzz_root}
 datasets4={}
 for key in EXPECT:
  ds=datasets.load(key,root=roots[key],verify=True)
  assert len(ds)==EXPECT[key][1] and ds.fingerprint==EXPECT[key][0],key
  assert ds.purpose=='compile_only'
  assert len({x.id for x in ds})==len(ds)
  datasets4[key]=ds
 assert {s.payload['language'] for s in datasets4['join-order-benchmark']}=={'sql'}
 assert {s.payload['language'] for s in datasets4['deepfuzz']}=={'python'}
 all_samples=datasets.concat(datasets4.values(),dataset_id='four-candidate-source-union',namespace_ids=True,merge_families=True)
 assert len(all_samples)==161,len(all_samples)
 lineage={s.group for s in all_samples}
 assert len(lineage)==35,len(lineage)
 # Preserve lineage: CCG and RemCCG must share a family; SQL templates grouped by query number.
 ccg={s.group for s in datasets4['ccg']};rem={s.group for s in datasets4['remccg']};assert ccg==rem
 grp=datasets.split(all_samples,fractions=(0.7,0.15,0.15),seed=20261031,unit='group')
 groups={k:{s.group for s in v} for k,v in grp.items()};assert len(groups)==3
 names=list(groups)
 for i in range(3):
  for j in range(i+1,3):assert not groups[names[i]]&groups[names[j]]
 assert sum(len(ds) for ds in grp.values())==161
 assert set.union(*groups.values())==lineage
 mix=datasets.MixtureDataset(datasets4,proportions={k:0.25 for k in datasets4},size=96,seed=805,replacement=True,
   dataset_id='four-source-equal-proportion-with-replacement')
 assert len(mix)==96
 def loader():return datasets.DataLoader(mix,batch_size=11,seed=1901,sampler=datasets.RandomSampler())
 x=loader();x.next_batch();state=x.state_dict();y=loader();y.load_state_dict(state)
 traces=[]
 for idx in range(13):
  first=[(s.id,s.group) for s in x.next_batch()];second=[(s.id,s.group) for s in y.next_batch()]
  assert first==second and x.state_dict()==y.state_dict()
  traces.append({'step':idx,'item_count':len(first),'epoch':x.epoch})
 assert x.epoch>state['epoch']
 # Every sampled representation references a real source; replacement repeats do not create new original primary IDs.
 rows={'format':'cpg-four-source-postinstall-real-application-v1','actual_compiler_playground_version':__version__,
  'card_sample_counts':{k:len(v) for k,v in datasets4.items()},'card_fingerprints':{k:v.fingerprint for k,v in datasets4.items()},
  'total_distinct_primary_samples':161,'all_samples_compile_only':True,
  'SQL_query_text_source_language_supported_without_code_change':True,
  'original_query_SQL_official_benchmark_verified':False,'DeepFuzz_model_or_generated_programs_executed':False,
  'original_dataset_primary_lineage_group_count':len(lineage),'CCG_RemCCG_shared_source_ancestry_preserved':True,
  'group_split_set_disjoint':True,'group_split_sizes':{k:len(v) for k,v in grp.items()},
  'group_split_family_counts':{k:len(v) for k,v in groups.items()},
  'mixture_distribution_requested':{k:0.25 for k in datasets4},
  'mixture_draws_with_replacement_not_original_samples':96,
  'data_loader_resume_steps_verified':len(traces),'cross_epoch_resume_verified':True,'resume_trace':traces,
  'original_dataset_cards_promoted_by_this_independent_candidate':0,
  'formal_resource_IDs_promoted':0,'installed_CPG_real_consumer_passed':True,'network_accessed':False,
  'backend':'Python 3.13 amd64 Debian 13; not Ubuntu 24.04 runtime qualification'}
 a.report.parent.mkdir(parents=True,exist_ok=True)
 a.report.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:rows[k] for k in ['actual_compiler_playground_version','card_sample_counts','total_distinct_primary_samples','original_dataset_primary_lineage_group_count','group_split_set_disjoint','data_loader_resume_steps_verified']},indent=2))
if __name__=='__main__':main()
