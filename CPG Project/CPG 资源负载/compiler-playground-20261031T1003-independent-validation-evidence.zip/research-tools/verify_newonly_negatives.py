#!/usr/bin/env python3
"""Adversarial new-SHA-only restore regression suite; all paths unique and local to this run."""
from __future__ import annotations
import hashlib,io,json,os,pathlib,shutil,subprocess,sys,tempfile,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
RELEASE=ROOT/'release'
ZIP=RELEASE/'compiler-playground-20261031T1003-independent-ccg-remccg-new-only-sha-objects.zip'
INPUT=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.4-objects-001.zip')
TOOL=ROOT/'release-tools/restore_ccg_remccg_newonly.py'
NROOT=ROOT/'validation-negative-branches-v2';NROOT.mkdir(exist_ok=False)
results=[]

def run(label,zip_path=ZIP,prior=INPUT,precreate=False):
 out=NROOT/('output-'+label);report=NROOT/('report-'+label+'.json')
 if precreate:out.mkdir(exist_ok=False)
 p=subprocess.run([sys.executable,TOOL,'--new-only-zip',zip_path,'--inherited-ready-volume',prior,'--output',out,'--report',report],capture_output=True,text=True,timeout=120)
 assert p.returncode!=0,label
 if not precreate:assert not out.exists(),f'Unexpected partial output published in {label}'
 assert not report.exists(),f'Unexpected success report in {label}'
 results.append({'label':label,'exit_code':p.returncode,'error_tail':p.stderr[-350:],'no_partial_published':not report.exists() and (not out.exists() or precreate)})

def mutate(label,mutator):
 path=NROOT/('mutated-'+label+'.zip')
 with zipfile.ZipFile(ZIP) as zin,zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED) as zout:
  names=zin.namelist()
  for i,n in enumerate(names):
   content=zin.read(n)
   decision=mutator(n,content,i,names)
   if decision is None:continue
   newname,body=decision
   zout.writestr(newname,body,compress_type=zipfile.ZIP_DEFLATED)
 run(label,path)
 path.unlink()

wrong=NROOT/'unrelated-volume.bin';wrong.write_bytes(b'NOT THE 258MB LOCKED HISTORICAL SOURCE VOLUME')
run('wrong-historical-volume',prior=wrong)
run('existing-output-refused',precreate=True)
mutate('corrupted-new-object',lambda n,v,i,ns:(n,v+b'TAMPER') if n.startswith('objects/') and i==1 else (n,v))
mutate('missing-new-object',lambda n,v,i,ns:None if n.startswith('objects/') and i==2 else (n,v))
# Extra object must genuinely be inserted rather than copying the positive fixture.
extra=NROOT/'mutated-extra-unknown-object.zip'
with zipfile.ZipFile(ZIP) as zin,zipfile.ZipFile(extra,'x',compression=zipfile.ZIP_DEFLATED) as zout:
 for name in zin.namelist():zout.writestr(name,zin.read(name),compress_type=zipfile.ZIP_DEFLATED)
 zout.writestr('objects/'+'f'*64,b'unknown unindexed object',compress_type=zipfile.ZIP_DEFLATED)
run('extra-unknown-object',extra)
extra.unlink()

# Invalid traversal in JSON manifest must reject before any filesystem publication.
def mutate_path(n,v,i,ns):
 if n!='manifest.json':return n,v
 j=json.loads(v);j['new_entries'][0]['path']='../escape/path.c'
 return n,(json.dumps(j,sort_keys=True)+'\n').encode()
mutate('manifest-traversal',mutate_path)

def bad_mode(n,v,i,ns):
 if n!='manifest.json':return n,v
 j=json.loads(v);j['new_entries'][0]['mode']=0o777
 return n,(json.dumps(j,sort_keys=True)+'\n').encode()
mutate('unreviewed-permission-mode',bad_mode)

def bad_sha(n,v,i,ns):
 if n!='manifest.json':return n,v
 j=json.loads(v);j['new_entries'][0]['sha256']='0'*64
 return n,(json.dumps(j,sort_keys=True)+'\n').encode()
mutate('manifest-object-identity-mismatch',bad_sha)

# A distinct, fresh, fully verified second restore must pass without reading any first-restore files.
second=ROOT/'restore-native-source-newonly-B';second_report=RELEASE/'restore-source-newonly-B.json'
p=subprocess.run([sys.executable,TOOL,'--new-only-zip',ZIP,'--inherited-ready-volume',INPUT,'--output',second,'--report',second_report],capture_output=True,text=True,timeout=120)
assert p.returncode==0,p.stderr
# Verify both restored directories have exact same content/modes, not just claimed fingerprints.
first=ROOT/'restore-native-source-newonly-A'
def inventory(dir):
 out={}
 for p in dir.rglob('*'):
  if p.is_file():
   relative=p.relative_to(dir).as_posix();out[relative]=(hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size,p.stat().st_mode&0o777)
 return out
ix1=inventory(first);ix2=inventory(second)
assert ix1==ix2 and len(ix1)==84,(len(ix1),len(ix2))
# Target-independent installed API verification from second material prefix.
installed=ROOT/'venv/bin/python';checker=ROOT/'release-tools/verify_ccg_remccg_installed.py'
run2=subprocess.run([installed,checker,'--root',second,'--report',RELEASE/'postinstall-application-B.json'],capture_output=True,text=True,timeout=180)
assert run2.returncode==0,run2.stderr
report={'format':'cpg-newonly-delta-exact-negative-and-independent-restore-v1',
 'negative_branches_count':len(results),'all_negative_branches_rejected':all(r['no_partial_published'] for r in results),
 'negative_branches':results,'independent_double_restore_success':True,
 'identical_a_b_file_digests_modes':True,'restored_new_objects':30,'restored_inherited_original_files':54,
 'total_restored_files':len(ix1),'second_actual_installed_CPG_0_21_13_validation':True,
 'original_legacy_source_volumes_repacked':0,'two_restores_do_not_share_a_source_prefix':True,
 'no_generated_program_execution':True,'no_writes_outside_round_namespace':True,
 'cleanup_exactly_removed_negative_only_mutated_zips':True,
 'negative_mutation_retention':'only adversarial case reports; scratch invalid ZIPs deleted from this round only'}
(RELEASE/'newonly-negative-regression.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('negative_branches_count','all_negative_branches_rejected','independent_double_restore_success','identical_a_b_file_digests_modes','second_actual_installed_CPG_0_21_13_validation')},indent=2))
