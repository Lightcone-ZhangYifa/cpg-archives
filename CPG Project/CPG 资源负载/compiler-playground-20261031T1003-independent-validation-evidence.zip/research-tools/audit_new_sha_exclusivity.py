#!/usr/bin/env python3
import json,zipfile,hashlib,pathlib
p=pathlib.Path('/mnt/data/cpg-automation-20261031T1003-inputs/compiler-playground-v0.21.13-cpg-continuation-20261030.zip')
out=pathlib.Path('/mnt/data/cpg-auto-20261031T1003/release')
cards=['ccg-remccg','job-deepfuzz']
new=[];source_old=[]
for card in cards:
 m=json.loads((out/f'compiler-playground-20261031T1003-independent-{card}-new-only-manifest.json').read_bytes())
 new.extend(m['new_entries']);source_old.extend(m['inherited_entries'])
 zpath=out/f'compiler-playground-20261031T1003-independent-{card}-new-only-sha-objects.zip'
 with zipfile.ZipFile(zpath) as bundle:
  assert set(bundle.namelist())=={'manifest.json'} | {'objects/'+x['sha256'] for x in m['new_entries']}
  for x in m['new_entries']:
   content=bundle.read('objects/'+x['sha256'])
   assert len(content)==x['bytes'] and hashlib.sha256(content).hexdigest()==x['sha256']
newids={x['sha256'] for x in new}
assert len(newids)==len(new)==34
assert not newids.intersection({x['sha256'] for x in source_old}) and len(source_old)==178
assert len({x['path'] for x in new+source_old})==len(new+source_old)
w=[]
with zipfile.ZipFile(p) as z:
 for name in ['baseline/compiler-playground-v0.21.12-resources-manifest.json','resources/compiler-playground-v0.21.13-resources-manifest.json']:
  data=json.loads(z.read(name));sha=set()
  for vol in data['volumes']:
   for member in vol.get('members',[]):
    sha.add(member['sha256'])
  intersect=sha&newids;assert not intersect,('Duplicate historical ready SHA',name,intersect)
  w.append({'ready_version':data['version'],'historical_volume_count':len(data['volumes']),'historical_declared_Sha_objects':len(sha),'new_object_reuse_or_repacked_count':0,'new_unique_sha_count':len(newids),'ready_manifest_path':name})
report={'format':'cpg-new-only-inherited-0.21.12-0.21.13-resource-sha-audit-v1','formal_ready_history_scanned':w,'all_34_new_objects_different_from_history':True,'original_Git_source_tree_files_not_packed':178,'independent_four_cards':cards,'new_derived_SHA_objects':34,'note':'Historical resource/ready manifests scanned; does not pretend to verify arbitrary bytes in all unrelated historical workspaces.'}
(out/'compiler-playground-20261031T1003-independent-new-SHA-exclusivity.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2))
